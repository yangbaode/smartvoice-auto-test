#grep -E ^CV robotcases/*.robot|awk -F: '{print $2}'|awk '{print $1}' > tags.txt
#for i in `cat tags.txt`;do A=${A},$i ;done;echo $A
export PYTHONPATH=$PYTHONPATH:$(pwd)

export SV_USER="pepper@cloudminds.com"
export SV_PWD="pepper1113"
export SERVER="http://10.155.0.135:30280"
export SERVER="http://172.16.13.110:30280"

export CYCLE_NAME="sv_auto_demo"
export TEST_VERSION="V2.0.5.1P2"

export JIRA_USER='beller.chu'
export JIRA_PASSWORD='$RFV5tgb'
TAG=$1

if [[ $TAG == rerun ]];then
    echo robot --pythonpath . -d Reports -R Reports/output.xml robotcases
    robot --pythonpath . -d Reports -R Reports/output.xml robotcases
    exit
fi

if [ -z "$TAG" ];then
    robot --pythonpath . -d Reports robotcases
else
    robot --pythonpath . -i DEBUGOR$TAG -d Reports -L TRACE robotcases
fi
