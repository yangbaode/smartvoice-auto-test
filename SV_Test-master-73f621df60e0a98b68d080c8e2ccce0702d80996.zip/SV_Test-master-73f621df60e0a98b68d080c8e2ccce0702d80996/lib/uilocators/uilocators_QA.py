import os
from lib.utils import constant


application_default = "//span[@class='agent-text']"
application_list = "//a[@class='agent-list-tab selected ng-star-inserted']"
loading = "//span[@class='ant-spin-dot']"
# applicationName = "//div[@class='agent-list-wrapper']/a[text()='automation_test_dian']"
# applicationName = "//div[@class='agent-list-wrapper']/a[text()='wbjtest_ENG']"
applicationName = "//div[@class='agent-list-wrapper']/a[text()='{}']".format(constant.agent_id_name)
answer_button ="//a[@class='ant-dropdown-link ant-dropdown-trigger'][contains(.,'问答')]"
answer_type_button = "//div[@class='cdk-overlay-container']//li[contains(.,'问答分类')]"
user_defined_qa = "//span[@class='classifyName'][contains(.,'自定义问答')]"
lots_move = "//button[@class='ant-btn ant-btn-primary ng-star-inserted'][contains(.,'批量移动')]"
lots_del = "//button[@class='ant-btn ant-btn-primary'][contains(.,'批量删除')]"
choose_type = "//body//nz-modal//div[3]"
choose_parent = "//div[@class='cdk-overlay-pane']/div/ul/li[contains(.,'根目录')]"
cancel_button = "//button[@class='ant-btn ant-btn-default']"

