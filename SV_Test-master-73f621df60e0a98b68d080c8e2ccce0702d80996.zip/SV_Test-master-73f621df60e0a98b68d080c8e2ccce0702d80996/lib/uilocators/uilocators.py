import os

#登录页面
login_page_lang = "//div[@class='language-wrap']//p"
login_page_lang_select = "(//ul/li)"
login_page_user = "//nz-input[@formcontrolname='userName']/input"
login_page_password = "//nz-input/input[@type='password']"
login_page_login_btn = "//button[contains(@class, 'login-form-button')]"
login_page_forgot_password = "//a[@class='login-form-forgot']"
login_page_forgot_code = "//nz-input[@formcontrolname='code']/input"
wrong_code = '验证码错误'

#firt page;
menu_user = "//button[contains(@class, 'email-btn')]"
menu_language = "//app-navbar/div/div/ul/li/nz-dropdown//p"
menu_select = "(//div[contains(@class, 'ant-dropdown')]//ul/li)"

nav_information_center = "//span[text()='消息中心']"
information_center_new_task_str = "新建任务"

#SV_信息总览
info_summary_total_agent_num = "//div[@class='h2 mt0']"
info_summary_chart = "//nz-card[@class='ant-card']"
#info_summary_day_pujing_hittimes = "//*[@class='pie-sub-title ng-star-inserted'][text()='pujing-VPN-SV']/../div"
# info_summary_day_pujing_hittimes = "//*[@class='pie-sub-title ng-star-inserted'][text()='automation_test_dian']/../div"
info_summary_day_pujing_hittimes = "//*[@class='pie-sub-title ng-star-inserted'][text()='新接口测试']/../div"
info_summary_day_btn = "(//div[@class='ant-card-head-wrapper']//button)[1]"
info_summary_month_btn = "(//div[@class='ant-card-head-wrapper']//button)[2]"

# 应用
nav_application = "//img[contains(@src,'agent_init.png')]"
# nav_application = "//span[contains(., '应用 : System')]"
# nav_application = "//span[contains(., '应用 : default')]"
nav_application_list_str = '应用列表'
nav_applicaiton_tab_intent = "(//ul/li/nz-dropdown)[2]"
# nav_applicaiton_tab_intent = "//a[contains(., '                  意图 ')]"
nav_applicaiton_tab_faq = "(//ul/li/nz-dropdown)[3]"
# nav_applicaiton_tab_faq = "//li[contains(., '实体')]"


nav_message_center = "//img[contains(@src,'notice_init.png')]"
nav_application_tag = "//img[contains(@src,'agent_active.png')]"
nav_industry_library = ""
nav_application_logs = "//ul/li[@class='selected ng-star-inserted']"
application_logs_content = "//tr/td[@nz-td]"
application_new_app_from_nav = "//a/span[text()='新建应用']"

# 新建应用
new_app_name = "//nz-input[@formcontrolname='agentname']/input"
new_app_lon = "//nz-input[@formcontrolname='longitude']/input"
new_app_lat = "//nz-input[@formcontrolname='latitude']/input"
new_app_getway = "//nz-input[@formcontrolname='gatewayurl']/input"
new_app_description = "//textarea[@formcontrolname='description']"
new_app_save_btn = "//app-add-form//button[@class='ant-btn ant-btn-primary']"
new_msg_btn = "//form//button[contains(@class, 'btn-primary')]"


#应用列表
application_list_new = "//form//button[contains(@class, 'btn-primary')]"
app_search_input = "//input[@type='search']"
app_search_icon = "//i[contains(@class, 'search')]"
app_list_table_agentid = "//tbody/tr/td[1]"
app_list_table_appname = "//tbody/tr/td[2]"
app_list_table_language = "//tbody/tr/td[3]"
app_list_table_timezone = "//tbody/tr/td[4]"
app_list_table_edit = "//tbody/tr/td[6]/button"
app_list_table_status = "//tbody/tr/td[6]/div/button"

#账号管理
nav_account_management = "//img[contains(@src,'account')]"

# 应用-日志
app_logs_export_btn = "//div[contains(@class,'float-right')]/button"
app_logs_export_btn_confirm = "//app-export-logs//button[contains(@class, 'primary')]"
app_logs_hit_type = "//nz-select[@formcontrolname='classify']"
app_logs_hit_menu_items = "(//ul/li[contains(@class, 'menu-item')])"
app_logs_start_datepicker = "//nz-datepicker[@formcontrolname='startTime']"
app_logs_end_datepicker = "//nz-datepicker[@formcontrolname='endTime']"
app_logs_datepicker_today = "//a[@class='ant-calendar-today-btn']"
app_logs_datepicker_prev_month = "//a[@class='ant-calendar-prev-month-btn']"
app_logs_datepicker_input = "//input[@class='ant-calendar-input']"
app_logs_datepicker_selecttime = "//a[contains(@class, 'ant-calendar-time-picker-btn')]"
app_logs_datepicker_ok_btn = "//a[contains(@class, 'ant-calendar-ok-btn')]"
app_logs_search = "//div[@nz-form-label]/button[contains(@class, 'primary')]"
app_logs_reset = "//div[@nz-form-label]/button[contains(@class, 'default')]"

# 平台管理
nav_platform_management = '//span[contains(.,"平台管理")]'
top_bar_skill_management = "//app-navbar/div[1]/ul/li[1]"
top_bar_statistics = "//app-navbar/div[1]/ul/li[2]/nz-dropdown/div/a"
# dropdown_hit_counts = "//ul[contains(@class=,'ant-menu-dropdown-vertical']/li[contains(@class,'ant-dropdown-menu-item-selected')]"
# dropdown_hit_counts = "//li[contains(@class,'ng-star-inserted ant-dropdown-menu-item')][1]"
dropdown_hit_counts = "//li[contains(., ' 命中次数')]"
# dropdown_response_time = "//li[contains(@class,'ng-star-inserted ant-dropdown-menu-item')][2]"
dropdown_response_time = "//li[contains(., ' 响应时间')]"
loading_spin = "//nz-spin[@class='ant-spin-nested-loading']//span[@class='ant-spin-dot']"
top_bar_sensitive_words = "//app-navbar/div[1]/ul/li[3]"

# 平台管理-技能管理
skillname_input = '//input[@placeholder="技能名称"]'
skill_search_area = "//app-skills//form/div/div[1]/form/div"
skill_search_button = "//app-skills//button[1]"
skill_search_reset = "//app-skills//button[2]"
skill_thead = "//table/thead/tr"             #/th[1-7]
skill_name = "//app-skills//form/div/div[1]//label"
data_resource = "//app-skills//form/div/div[2]//label"
skill_status = "//app-skills//form/div/div[3]//label"
online_start_time = "//app-skills//form/div/div[4]//label"
online_end_time = "//app-skills//form/div/div[5]//label"
# data_resource_selector = '//nz-select[@formcontrolname="skillType"]/div/div/div[1]'
data_resource_selector = "//nz-select//div/div/div[1]"
dropdown_selection = '//ul[contains(@class,"select-dropdown-menu")]/li'   #[1-3]
# data_resource_all = '//ul[contains(@class,"select-dropdown-menu")]/li[1]'
# data_resource_self = '//ul[contains(@class,"select-dropdown-menu")]/li[2]'
# data_resource_thridparty = '//ul[contains(@class,"select-dropdown-menu")]/li[3]'
skill_status_selector = '//nz-select[@formcontrolname="skillStatus"]/div/div/div[1]'
start_time_control = "//nz-datepicker[@formcontrolname='onlineTimeStart']/span/input"
end_time_control = "//nz-datepicker[@formcontrolname='onlineTimeEnd']/span/input"
# start_time_input = '//input[@placeholder="起始时间"]'    #格式:2019-08-08 11:38:31
time_input = '//div[@class="ant-calendar-date-input-wrap"]/input'
# time_input = '//input[@placeholder="结束时间"]'
time_confirm = "//span[@class='ant-calendar-footer-btn']/a[3]"
# search_results_row = "//tbody/tr"   #[n] 第n行      加/td[n] 第几项
total_num = "//nz-pagination/ul/span"
details_skill_name = '//div[contains(@class,"form-item")][1]/div[2]/div/span'
details_data_resource = '//div[contains(@class,"form-item")][2]/div[2]/div/span'
details_skill_status = '//div[contains(@class,"form-item")][2]/div[4]/div/span'
details_online_time = '//div[contains(@class,"form-item")][3]/div[2]/div'
details_skill_description = '//div[contains(@class,"form-item")][4]/div[2]/div'
details_subscp_app_num = '//div[contains(@class,"form-item")][3]/div[4]//span'
details_service = '//div[contains(@class,"form-item")][5]/div[2]/div'
details_radio = '//nz-radio-group/label/span[1]'
details_review = '//nz-radio-group/label/span[3]'
review_skill_name = '//app-skill-detail//tbody/tr/td[1]'
review_service = '//app-skill-detail//tbody/tr/td[2]'
review_response_time = '//app-skill-detail//tbody/tr/td[3]'
review_response_results = '//app-skill-detail//tbody/tr/td[4]'


# 平台管理-命中次数
hits_skill_name = "//app-statistics/div[1]/form/div[1]/div[1]/div/div[1]/label"
hits_data_resource = "//app-statistics//form/div/div[2]//label"
hits_service = "//app-statistics//form/div/div[3]//label"
hits_user_name = "//app-statistics//form/div/div[4]/div[1]/div/div[1]/label"
hits_agent_id = "//app-statistics//form/div/div[4]/div[2]/div/div[1]/label"
hits_agent_name = "//app-statistics//form/div/div[4]/div[3]/div/div[1]/label"
hits_start_time = "//app-statistics//form/div/div[4]/div[4]/div/div[1]/label"
hits_end_time = "//app-statistics//form/div/div[4]/div[5]/div/div[1]/label"
group_username = "//label[1]/span[2]"
group_agent_id = "//label[2]/span[2]"
group_agent_name = "//label[3]/span[2]"
#
# hits_data_resource_selector = '//nz-select[@formcontrolname="suppliertype"]/div/div/div[1]'
hits_search_button = "//app-statistics/div[1]/form/div[2]/div[2]/button[2]"
hits_search_reset = "//app-statistics/div[1]/form/div[2]/div[2]/button[3]"
hits_service_input = '//input[@placeholder="供应商"]'
hits_username_input = '//nz-input[@formcontrolname="username"]/input'
hits_agent_id_input = '//nz-input[@formcontrolname="agentid"]/input'
hits_agent_name_input = '//nz-input[@formcontrolname="agentname"]/input'
hits_username_checkbox = '//label[@formcontrolname="isRequiredUserName"]/span'
hits_agent_id_checkbox = '//label[@formcontrolname="isRequiredAgentID"]/span'
hits_agent_name_checkbox = '//label[@formcontrolname="isRequiredAgentName"]/span'
hits_export_button = "//app-statistics/div[1]/form/div[2]/div[2]/button[1]"
export_dialog_title = "//app-export-list/div[1]/div"
export_cancel_button = "//app-export-list/div[3]/button[1]"
export_export_button = "//app-export-list/div[3]/button[2]"


# 平台管理-敏感词
sensitive_search_input = "//app-sensitive-words//nz-input/input"
sensitive_search_button = "//app-sensitive-words//nz-input/span/i"
sensitive_create_button = "//button[text()='新建']"
sensitive_create_label = "//app-sensitive-words-detail/form/div[1]/div[1]/label"
sensitive_cancel_button = "//app-sensitive-words-detail/form/div[2]/button[1]"
sensitive_save_button = "//app-sensitive-words-detail/form/div[2]/button[2]"
sensitive_words_input = "//app-sensitive-words-detail/form//nz-input/input"
sensitive_words_delete_cancel = "//app-sensitive-delete/div[3]/button[1]"
sensitive_words_delete_confirm = "//app-sensitive-delete/div[3]/button[2]"


# 响应时间
response_time_start_time = "//app-response-time//form/div[1]/div/div/nz-datepicker/span/input"
response_time_end_time = "//app-response-time//form/div[2]/div/div/nz-datepicker/span/input"
response_time_min = "//nz-button-group/div/button[1]"
response_time_hour = "//nz-button-group/div/button[2]"
response_time_day = "//nz-button-group/div/button[3]"
response_time_chart = "//app-response-time/div/div[2]"
app_qa_tag = '//div[@class="cdk-overlay-pane"]//ul/li[3]'
app_industry_library = '//div[@class="cdk-overlay-pane"]//ul/li[2]'
app_entity = "//li[contains(@class,'ant-dropdown-menu-item')][3]"
new_app_tag = '//div[@class="operate-area"]//button'
new_entity_btn = '//div[@class="operate-area"]//div[4]/button'
entity_name_input = '//nz-input[@formcontrolname="entityname"]/input'
tag_name_input = '//nz-input[@formcontrolname="tagname"]/input'
new_tag_save_btn = "//button[contains(@class, 'modal-sure-btn')]"
tag_search_input = '//input[@type="search"]'
tag_search_btn = '//nz-input/span'
del_tag_btn = "//button[contains(@class, 'modal-detele-btn')]"
close_edit_tag_btn = "//button[contains(@class, 'modal-close-btn')]"
new_entity_save_btn = "//form//button[2]"
go_back_btn = '//div[@class="d-inline-block"]/span[1]'
close_entity_btn = "//form//button[1]"
del_entity_btn = '//div[@class="modal-delete"]//button[2]'
import_entity_btn = '//div[@class="operate-area"]//div[2]/button'
export_entity_btn = '//div[@class="operate-area"]//div[3]/button'
msg_name_input = '//nz-input[@formcontrolname="name"]/input'
msg_content_input = '//nz-input[@formcontrolname="content"]/input'
msg_edit_name_input = '//nz-input[@formcontrolname="taskname"]/input'
msg_edit_content_input = '//nz-input[@formcontrolname="taskcontent"]/input'
msg_assigned_button = '//app-assign//button[1]'
msg_assigned_cancel_button = '//app-assign//button[2]'
new_msg_save_btn = "//button[contains(@class, 'modal-sure-btn')]"
del_msg_btn = "//button[contains(@class, 'modal-detele-btn')]"
msg_message_text = '//nz-message/div/div/div/span'
close_edit_msg_btn = "//button[contains(@class, 'modal-close-btn')]"

#导航
nav_applicaiton_info = "//span[contains(text(),'信息总览')]"
nav_applicaiton = "//span[contains(text(),'应用 : ')]"
nav_applicaiton_beller ="//a[contains(text(),'%s')]"
nav_applicaiton_intention = "//a[contains(text(),'意图')]"
nav_applicaiton_intention_service_management = "//div[@class='cdk-overlay-container']//li[2]"
nav_applicaiton_intention_service_management_selfdefine_service = "//span[contains(text(),'自定义服务')]"
nav_applicaiton_intention_service_management_system_service = "//span[contains(text(),'系统服务')]"
nav_applicaiton_intention_entity = "//li[text()='实体']"
selfdefine_service_details_btn = "//div[@class='domain-wrap']//div[2]//div//div//h6[text()='autotest']/../div[2]/span[contains(text(),'查看详情')]"
selfdefine_service_open_btn = "//div[@class='domain-wrap']//div[2]//div//div//h6[contains(text(),'auto')]/../div/div/button/span[contains(text(),'启用')]"
selfdefine_service_close_btn = "//div[@class='domain-wrap']//div[2]//div//div//h6[contains(text(),'auto')]/../div/div/button/span[contains(text(),'停用')]"
selfdefine_service_description_info = "//div[contains(text(),'This is for auto test')]"
selfdefine_service_details_cancel_btn = "//span[@class='ant-modal-close-x']"
system_service_detail_btn = "//div[@class='domain-wrap']//div[2]//div//div//h6[text()='%s']/../div[2]/span[contains(text(),'查看详情')]"
system_service_detail_weather_info = "//div[@class='ant-modal']//div[contains(text(),'天气服务')]"
system_service_weather = "//div[contains(text(),'天气服务')]"
system_service_search_input = "//input[@placeholder='搜索...']"
system_service_search_input_search_icon = "//i[@class='anticon anticon-search ant-input-search-icon ng-star-inserted']"
crosstalk_title = "//a[contains(text(),'crosstalk_title')]"
crosstalk_performer = "//a[contains(text(),'crosstalk_performer')]"
industry_qa_span_button = '//tree-node-children//tree-node[1]/div/span[2]/span/nz-switch/span'
industry_qa_span = '//tree-node-children//tree-node[1]/div/span[2]/span/span'
industry_question_text = '//tr[1]/td[2]'

#自定义服务
domain_icon = "//i[@class='anticon anticon-ellipsis domain-list-dropdow-icon']"
domain_service_create = "//div[@class='cdk-overlay-container']//li[1]//p[1]"
new_domain_name = "//input[@id='domainname']"
lab_domain_createname = "//div[@class='ant-form-explain ng-star-inserted']"
new_domaininfo = "//textarea[@id='domaininfo']"
lab_domaininfo_createname = "//div[@class='ant-modal-wrap']//div[2]//div[2]//div[1]//div[1]"
