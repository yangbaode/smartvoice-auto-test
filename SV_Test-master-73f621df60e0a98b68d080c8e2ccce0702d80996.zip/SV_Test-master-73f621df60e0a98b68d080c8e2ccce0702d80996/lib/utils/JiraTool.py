import requests
import  time
import re
import jsonpath
import urllib3
import os
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
#requests.packages.urllib3.util.ssl_.DEFAULT_CIPHERS += 'HIGH:!DH:!aNULL'
urllib3.util.ssl_.DEFAULT_CIPHERS += 'HIGH:!DH:!aNULL'
try:
  requests.packages.urllib3.contrib.pyopenssl.DEFAULT_SSL_CIPHER_LIST += 'HIGH:!DH:!aNULL'
except AttributeError:
  pass

class JiraTool(object):
    def __init__(self, user, password, base_url="http://jira.cloudminds.com"):
        self.session = requests.session()
        self.user = user
        self.password = password
        self.base_url = base_url
        self.token = ""

    def login(self):
        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
               'Connection': 'keep-alive', 'Content-Type': 'application/x-www-form-urlencoded',
               'Accept-Encoding': 'gzip, deflate'}
        data = 'os_username={}&os_password={}&login=登录'.format(self.user, self.password)
        url = '/login.jsp'
        response = self.session.post(self.base_url + url, headers=headers, params=data, verify=False)
        reg = re.findall(r'zEncKeyVal\s+=\s+\"(.*?)\";', response.text)
        if response.status_code == 200:
            self.token = reg[0]
        else:
            print("jira系统登录  失败  返回值是  " + response.text)

    def set_execution_status(self, issue_key, status, version, cycle_name):
        """设置case执行状态
        :param  issue_key   索要执行的case的key, 如CV-2324
        :param  status  执行的状态: PASS, FAIL,(还支持WIP,BLOCK,NotExecution)
        :param  version  版本号
        :param  cycle_name  测试循环名称
        :return   bool 是否成功.
        """
        print("set issue:'{}' to status {}".format(issue_key, status))
        execute_state = {'PASS': "1", 'FAIL': '2', 'WIP':'3', 'BLOCK': '4', 'NotExecution':'5'}
        self.login()
        if self.token:
            print("jira系统登录成功")
        else:
            print("jira系统登录失败")
            return False

        timestamp_13 = int(round(time.time() * 1000))
        headers = {'AO-7DEABF': self.token, 'Content-Type': 'application/json',
                   'Accept': 'application/json, text/javascript, */*; q=0.01', 'Connection': 'keep-alive',
                   'X-Requested-With': 'XMLHttpRequest', 'Host': 'jira.cloudminds.com',
                   'Accept-Encoding': 'gzip, deflate'}
        url = '/rest/api/2/issue/{}'.format(issue_key)
        response = self.session.get(self.base_url + url, headers=headers, verify=False)
        issue_id = jsonpath.jsonpath(response.json(), '$.id')
        print('issue_id', issue_id)
        if issue_id:
            print('当前jira返回的bug issueId:', issue_id[0])
            issue_id = issue_id[0]
            print('issueId:', issue_id)
            url = '/rest/zephyr/latest/execution?issueId={}&_={}'.format(issue_id, timestamp_13)
            response = self.session.get(self.base_url + url, headers=headers, verify=False)
            version_pattern = '$.executions.[?(@.versionName ==\'{}\' && @.cycleName ==\'{}\')].id'.format(version, cycle_name)
            version_id = jsonpath.jsonpath(response.json(), version_pattern)
            print('versionid:', version_id)
            if version_id:
                print('获取需要的参数versionNameID成功:  ', version_id[0])
                url = '/rest/zephyr/latest/execution/{}/execute'.format(version_id[0])
                data = {"status": '{}'.format(execute_state[status]), "changeAssignee": False}
                response = self.session.put(self.base_url + url, headers=headers, json=data, verify=False)
                if response.status_code != 200:
                    print('FAiled to execute test execution')
                    return False
                json_executionStatus = '$.executionStatus'
                json_issueId = '$.issueId'
                json_executedBy = '$.executedBy'  ###被谁执行
                json_executedOn = '$.executedOn'  ###被执行修改的时间
                executionStatus = jsonpath.jsonpath(response.json(), json_executionStatus)
                issueId = jsonpath.jsonpath(response.json(), json_issueId)
                executedBy = jsonpath.jsonpath(response.json(), json_executedBy)
                executedOn = jsonpath.jsonpath(response.json(), json_executedOn)
                print('修改后的状态 ', executionStatus[0], '  当前的issueId:', issueId[0], '  被  ' + executedBy[0], ' 执行',
                      '  执行修改操作时间是  ', executedOn[0])
                return True
            else:
                print('获取需要的参数 versionNameID cycleId  executionID 失败,错误返回值', response.text)
                return False
        else:#if issue_id:
            print('获取Jira的bug issueId  错误   ', response.text)

if __name__ == '__main__':
    pass
