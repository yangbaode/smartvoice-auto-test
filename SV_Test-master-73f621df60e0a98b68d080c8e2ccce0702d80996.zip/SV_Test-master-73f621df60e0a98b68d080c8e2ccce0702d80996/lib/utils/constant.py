import os
import random
#SERVER=os.getenv('SERVER', 'http://10.155.0.135:30280')   #  http://10.155.0.135:30280
SERVER=os.getenv('SERVER', 'http://10.155.254.135:20007')   #  http://10.155.0.135:30280
# 客户账号
SV_USER = os.getenv('SV_USER', 'pepper@cloudminds.com')     #'pepper@cloudminds.com'
SV_PWD = os.getenv('SV_PWD', 'pepper1113')       #'pepper1113'

# Slave账号, 这个账号绑定agent 544；  # 注意这是SLAVE账号，
SV_SLAVE = os.getenv('SV_SLAVE', 'dian@cloudminds.com')     #'pepper@cloudminds.com'
SV_SLAVE_PWD = os.getenv('SV_SLAVE_PWD', 'Pepper1113')       #'pepper1113'
# 这个账号绑定是 544 agent


#admin账号
SV_ADMIN = os.getenv('SV_ADMIN', 'admin@cloudminds')
SV_ADMIN_PWD = os.getenv('SV_ADMIN_PWD', 'Smartvoice1506')

#operator账号
SV_OPERATOR = os.getenv('SV_OPERATOR', 'oper@cloudminds.com')
SV_OPERATOR_PWD = os.getenv('SV_OPERATOR_PWD', 'Smartvoice1506')

# jira回填所需要的环境变量, 可由jenkins传入或export变量获得
jira_user = os.getenv("JIRA_USER")
jira_pwd = os.getenv('JIRA_PASSWORD')
test_version = os.getenv('TEST_VERSION')
testcycle_name = os.getenv('CYCLE_NAME')

#CMS地址
CMS_SERVER = os.getenv('CMS_SERVER', "http://10.155.0.135:32170")    # 135CMS
#CMS_SERVER = os.getenv('CMS_SERVER', "http://10.155.254.135:20005")    # 135CMS
#CMS_SERVER = os.getenv('CMS_SERVER', "http://10.128.0.5:30981")    # 134CMS
# CMS_SERVER = os.getenv('CMS_SERVER', "http://10.155.0.136:32170")    # 136CMS
CMS_USER = os.getenv('CMS_USER', "admin")
CMS_PWD = os.getenv('CMS_PWD', "123456")
#agent_id
ADMIN_AGENT_ID = os.getenv('ADMIN_AGENT_ID', 1)         #管理员账号的agent id


# 需要修改数据的agent和名称
agent_id = os.getenv('AgentId', 483)
agent_id_name = os.getenv('AgentIdName', "wbjtest_ENG")

agent_id1 = os.getenv('AgentId1', 318)
#agent_name = os.getenv('AgentName',"英文测试")
agent_name = os.getenv('AgentName',"新接口测试")

agent_name_beller = os.getenv('AgentNameBeller',"beller")
# agent_id = os.getenv('AgentId', 544)
# agent_id1 = os.getenv('AgentId1', 545)
# agent_name = os.getenv('AgentName', "automation")


# 仅用于数据查看,不要制造垃圾数据以及改变里面的配置.
dont_modify_agent_id = os.getenv('NoModAgentId', 318)
#dont_modify_agent_name = os.getenv('NoModAgentName', 'FunHillDev') #FunHillDev不存在这个应用
dont_modify_agent_name = os.getenv('NoModAgentName', '新接口测试')

# dont_modify_agent_id = os.getenv('NoModAgentId', 318)
# dont_modify_agent_name = os.getenv('NoModAgentName', '新接口测试')


randomcmsint = os.getenv("randomcmsint",random.randint(10,100000))

#baldwinEdit  account_management 测试，agent未做分离，添加分离
account_management_agent = os.getenv('AccountAgentName', "automation")
application_default_agent = os.getenv('AccountAgentName', "automation-test")

#笑话数据初始化，
ServiceManage_joke_id = os.getenv('JokeId', '4365')

#组名
GroupName = os.getenv('GroupName', 'diangroup')
#子账号
GroupUsername = os.getenv('GroupUserame', 'dian@cloudminds.com')
#子账号ID
GroupUsernameID = os.getenv('GroupUserameID', 272)


#FAQ 测试条目创建 autotest  typeid
FaqTypeId = os.getenv('FaqTypeId', '102')