#!/usr/bin/env python
# coding=utf-8

from lib.modules.Application import Application
from lib.modules.Base import Base
from lib.uilocators import uilocators
from lib.utils import constant
import logging as logger
import os
import time

class TestApplicationEntity(Application):
    def test_open_app_entity(self):
        self.open_application_default()
        # assert self.wait_element_visible(uilocators.nav_message_center, 10)
        self.select_app_entity()
    def select_app_entity(self):
        self.wait_element_visible(uilocators.nav_applicaiton_tab_intent, 10)
        self.selib.click_element(uilocators.nav_applicaiton_tab_intent)
        self.wait_element_visible(uilocators.app_entity, 10)
        self.selib.click_element(uilocators.app_entity)
    def new_entity(self,name):
        self.open_new_entity()
        self.entity_name_input(name)
        self.confirm_save_entity()
        text = self.selib.get_text(uilocators.msg_message_text)
        if(text == 'entity name is already exist.'):
            self.close_new_entity()
            self.del_entity(name)
            self.open_new_entity()
            self.entity_name_input(name)
            self.confirm_save_entity()
    def edit_entity(self,name_old,name_new):
        self.open_edit_entity(name_old)
        self.entity_name_input(name_new)
        self.confirm_save_entity()
    def entity_name_input(self,name):
        self.selib.input_text(uilocators.entity_name_input, name)
    def open_new_entity(self):
        self.selib.click_element(uilocators.new_entity_btn)
    def close_new_entity(self):
        self.selib.click_element(uilocators.close_entity_btn)
    def confirm_save_entity(self):
        self.selib.click_element(uilocators.new_entity_save_btn)
    def del_entity(self,tagname):
        self.open_del_entity(tagname)
        self.confirm_del_entity()
    def open_del_entity(self,tagname):
        delete_btn = "//tr/td/a[text()='{}']/../../td/button[2]".format(tagname)
        self.selib.click_element(delete_btn)
    def open_edit_entity(self,tagname):
        edit_btn = "//tr/td/a[text()='{}']/../../td/button[1]".format(tagname)
        self.click_locator(edit_btn)
    def open_entity_content(self,name):
        content_btn = "//tr/td/a[text()='{}']".format(name)
        self.click_locator(content_btn)
    def entity_go_back(self):
        self.click_locator(uilocators.go_back_btn)
    def close_edit_entity(self):
        self.click_locator(uilocators.close_entity_btn)
    def confirm_del_entity(self):
        self.selib.click_element(uilocators.del_entity_btn)
    def search_entity(self,text):
        self.selib.input_text(uilocators.tag_search_input, text)
        self.selib.click_element(uilocators.tag_search_btn)
    def verify_entity_field(self,text):
        assert self.wait_page_contains(text, 10)
    def open_import_entity(self):
        self.click_locator(uilocators.import_entity_btn)
    def open_export_entity(self):
        self.click_locator(uilocators.export_entity_btn)
