#!/usr/bin/env python
# coding=utf-8

from lib.modules.Application import Application
from lib.modules.Base import Base
from lib.uilocators import uilocators
from lib.utils import constant
import random
import string
import logging as logger
import os
import time


class TestApplicationDefault(Application):
    def test_open_default_application(self):
        self.open_application_default()
        assert self.wait_element_visible("//ul[@class='left-bar-nav']//a[text()='default']")

    def test_open_application(self):
        self.open_application_navi(constant.agent_name)
        assert self.wait_element_visible(uilocators.nav_application_logs, 10)
        assert self.wait_element_visible(uilocators.application_logs_content, 3)

    def test_new_application_from_navi(self):
        self.open_application_default()
        self.click_by_js(uilocators.application_new_app_from_nav)
        self.selib.input_text(uilocators.new_app_name, constant.agent_name)
        self.selib.input_text(uilocators.new_app_lon, "116.475304")
        self.selib.input_text(uilocators.new_app_lat, "40.004532")
        time.sleep(0.5)
        self.selib.click_element(uilocators.new_app_save_btn)

        ret = self.wait_page_contains('agent name already existed.')
        ret2 = self.wait_element_present("//ul[@class='left-bar-nav']//a[text()={}]".format(constant.application_default_agent))
        assert ret or ret2, "创建成功"

    def test_new_application_from_applist(self):
        interface = Base(constant.SV_USER, constant.SV_PWD)
        interface.get_sv_authinfo()
        para = {'json': {"agentname": constant.application_default_agent, "language": "中文简体", "timezone": "UTC", "longitude": "10",
                         "latitude": "10", "gatewayurl": "", "description": ""}}
        res = interface.sv_request('/v2/ux/agents/add', method='POST', parameter=para)
        self.open_application_default()
        self.open_application_navi(uilocators.nav_application_list_str)
        ret = "agent name already existed." in res[0]['error']
        ret2 = self.wait_element_present("//ul[@class='left-bar-nav']//a[text()={}]".format(constant.application_default_agent))
        assert ret or ret2, "创建成功"

    def test_edit_appliction(self):
        """CV-9249,CV-9254 应用-编辑应用"""
        self.open_application_default()
        description = ''.join(random.sample(string.ascii_letters + string.digits, 50))
        lon = '116.49{}'.format(random.randint(1000,1999))
        items = {'lon': lon, 'lat': '39.98883','description': description}
        self.edit_application_in_applist(constant.account_management_agent, items)
        check = {'check': {'description': description, 'lon': lon}}
        ret = self.edit_application_in_applist(constant.account_management_agent, check)
        assert ret, '没有查到结果'

    def test_search_applicaiton(self):
        """CV-9258 应用-应用列表-搜索"""
        self.search_application(constant.account_management_agent)

    def test_disable_application(self):
        """
        CV-9255 应用-应用列表按钮-停用
        :return: 
        """
        self.search_application(constant.account_management_agent)
        ret = self.get_app_status_in_applist(constant.account_management_agent)
        if not ret:
            assert self.set_app_status_in_applist(constant.account_management_agent, True), '当前状态无法切换为启用状态'
        assert not self.set_app_status_in_applist(constant.account_management_agent, False), '切换为disable是出错'
        interface = Base(constant.SV_USER, constant.SV_PWD)
        interface.get_sv_authinfo()
        agent_id = interface.get_agentId_by_name(constant.account_management_agent)
        assert agent_id != -1, '接口查询agent id失败'
        interface.get_sv_authinfo(agent_id)
        answer = interface.question_test('hello')
        print(answer)
        try:
            self.set_app_status_in_applist(constant.account_management_agent, True)
        except:
            print('末尾enable以免对其他case影响失败.')

        #ret = interface.verify_qa_answer(answer.json(), "气温")
        #assert not ret, 'disable下不应该有回复'


    def test_enable_application(self):
        """
        CV-9250,CV-9256 应用-启用应用
        :return: 
        """
        # self.search_application(constant.account_management_agent)
        self.search_application(constant.agent_name)
        ret = self.get_app_status_in_applist(constant.agent_name)
        if ret:
            assert not self.set_app_status_in_applist(constant.agent_name, False), '切换状态为未启用状态失败'
        assert self.set_app_status_in_applist(constant.agent_name, True), '当前状态无法切换为启用状态'
        interface = Base(constant.SV_USER, constant.SV_PWD)
        interface.get_sv_authinfo()
        agent_id = interface.get_agentId_by_name(constant.agent_name)
        print('current agent ID:', agent_id)
        assert agent_id != -1, '接口查询agent id失败'
        interface.get_sv_authinfo(agent_id)
        answer = interface.question_test('西宁市明天天气怎么样?')
        print(answer)
        assert interface.verify_qa_answer(answer, "气温"), 'enable后验证问答失败'

    def test_list_all_application(self):
        """
        CV-9252 	应用-应用列表按钮-列表的显示
        :return: 
        """
        self.open_application_list()
        assert self.get_elements(uilocators.app_list_table_agentid), 'id不存在'
        assert self.get_elements(uilocators.app_list_table_appname), 'app名称不存在'
        assert self.get_elements(uilocators.app_list_table_language), '语言不存在'
        assert self.get_elements(uilocators.app_list_table_timezone), '失去不存在'
        assert self.get_elements(uilocators.app_list_table_edit), '操作栏不存在'

