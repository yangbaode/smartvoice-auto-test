#!/usr/bin/env python
# coding=utf-8

from lib.modules.FirstPage import FirstPage
from lib.uilocators import uilocators
from lib.utils import constant
import logging as logger
import os
import time

class TestFirstPage(FirstPage):
    ROBOT_LIBRARY_SCOPE = 'TEST SUITE'
    ROBOT_LIBRARY_VERSION = "0.1"
    

    def test_change_language_to_english(self):
        self.change_lang('English')
        assert self.wait_page_contains('Information Overview', 15), 'no Information Overview found'

    def test_change_language_to_cn_tw(self):
        self.change_lang('中文繁體')
        assert self.wait_page_contains('資訊總覽', 15), 'no 資訊總覽 found'

    def test_change_language_to_zhCN(self):
        self.change_lang('中文简体')
        assert self.wait_page_contains('信息总览', 15), 'no 信息总览 found'
    
    def test_change_language_to_japanese(self):
        self.change_lang('日本語')
        assert self.wait_page_contains('アカウント名での申請', 15), 'no アカウント名での申請 found'
    
    def test_forgot_password(self):
        self.forgot_password()
        assert self.wait_page_contains(uilocators.wrong_code), 'not contains '+uilocators.wrong_code
    
    def test_go_to_information_center(self):
        self.go_to_information_center()
        assert self.wait_page_contains(uilocators.information_center_new_task_str), 'not contains '+uilocators.information_center_new_task_str

    def test_email_contains(self):
        assert self.wait_page_contains(constant.SV_USER), 'page doesnt contain '+ constant.SV_USER
    
    def test_application_summary(self):
        assert self.wait_element_present(uilocators.info_summary_total_agent_num, 15), "15秒应用数量未出现"   
        assert self.wait_element_visible(uilocators.info_summary_chart, 15), '15秒未出现图形'
    
    def test_agent_num(self):
        self.wait_element_visible(uilocators.info_summary_total_agent_num, 15)
        num = self.selib.get_text(uilocators.info_summary_total_agent_num)
        assert int(num)>0, 'agent num error'
    
    def test_application_graph(self):
        line = self.wait_element_present(uilocators.info_summary_day_pujing_hittimes, 15)
        pie = self.selib.get_text(uilocators.info_summary_day_pujing_hittimes)
        assert line, "wait for 15s"
        assert int(pie) > 100
    
    def test_hittimes_day(self):
        self.hittimes_by('day')
        line = self.wait_element_present(uilocators.info_summary_day_pujing_hittimes, 15)
        pie = self.selib.get_text(uilocators.info_summary_day_pujing_hittimes)
        assert line, "wait for 15s"
        assert int(pie) > 100
    
    def test_hittimes_month(self):
        self.hittimes_by('month')
        line = self.wait_element_present(uilocators.info_summary_day_pujing_hittimes, 15)
        pie = self.selib.get_text(uilocators.info_summary_day_pujing_hittimes)
        assert line, "wait for 15s"
        assert int(pie) > 100
    