#!/usr/bin/env python
# coding=utf-8
from lib.modules.PlatformManagement import PlatformManagement
from lib.modules.Base import Base
from lib.uilocators import uilocators as pm
from lib.modules.Application import *
from lib.utils import constant
import requests
import logging as logger
import json
import jsonpath
import os
import time
import datetime
import random
import xlrd
import re

class TestPlatformManagement(PlatformManagement):
    def test_template_ui(self):
        """:UI测试的例子,请删除:"""
        self.wait_element_disapear('//div', 2)
        #所有的SeleniumLibrary的关键字都可以通过self.selib
        #所有关键字参考: http://robotframework.org/SeleniumLibrary/SeleniumLibrary.html#Shortcuts
        self.selib.click_element('//div')
        # 包装的公共方法:
        self.click_locator('//div')
        self.click_by_js('//div')
        logger.debug('just for testing.')

    def test_interface_example(self):
        """:接口测试的例子,请删除:"""
        interface = Base(constant.SV_USER, constant.SV_PWD)
        interface.get_sv_authinfo(318)
        url = "/v2/ux/statistics/hittimes/agent"
        para = {'params': {'enddate': '2019-07-10','level': 'month', 'startdate': '2019-06-01'}}
        pattern = r"$.[?(@.agentname=='新接口测试' && @.statisdate=='2019-06')].hittimes"
        result, duration = interface.sv_request_with_authinfo(url, 'GET', parameter=para, pattern=pattern)
        assert result[0] == 1285297
        assert duration < 20
    # def modify_skill_status(self):
    #     self.open_application_default
    #     self.open_item_in_intent(2)

    # 技能管理-页面内容显示1
    def check_skill_page_content_items(self):
        desire_list = ['技能名称', '数据来源', '技能状态', '上线时间开始', '上线时间结束']
        lista = self.get_skill_search_items()
        print(lista)
        assert lista == desire_list, "not equal"

    # 技能管理-页面内容显示
    def check_skill_page_thead(self):
        desire_list = ['技能名称', '技能描述', '数据来源', '技能状态', '上线时间', '订阅应用数', '操作']
        lista = self.get_thead_text(8)
        assert lista == desire_list

    # 技能管理-搜索
    def check_skill_search(self):
        lista = ['weather', '第三方', '启用', '可用', '2017-05-31 16:55:00', '2018-12-31 16:55:00']
        self.input_skill_name(lista[0])      # 搜索 技能名称为weather
        self.click_search_button()
        results = self.get_search_results()
        assert results[0] == lista[0]
        self.click_search_reset_button()
        self.select_data_resource(3)         # 搜索 数据来源为第三方
        self.click_search_button()
        results = self.get_search_results()
        assert results[2] == lista[1]
        self.click_search_reset_button()
        self.select_skill_status(2)         # 搜索 技能状态为可用
        self.click_search_button()
        results = self.get_search_results()
        assert results[3] == lista[3]
        self.click_search_reset_button()
        self.input_online_time_start(lista[4])         # 搜索 上线开始时间
        self.click_search_button()
        results = self.get_search_results()
        assert results[4] > lista[4]
        self.click_search_reset_button()
        # self.input_online_time_end(lista[5])         # 搜索 上线结束时间
        # self.click_search_button()
        # results = self.get_search_results()
        # assert results[4] > lista[3]
        self.input_skill_name(lista[0])                # 搜索  组合条件
        self.select_data_resource(3)
        self.select_skill_status(2)
        self.input_online_time_start(lista[4])
        self.input_online_time_end(lista[5])
        self.click_search_button()
        results = self.get_search_results()
        listb = ['weather', '天气服务', '第三方', '可用', '2017-12-31 16:55:00']
        assert results[:-1] == listb[:-1],  "Not Equal!"

    # 技能管理-搜索重置
    def check_search_reset(self):
        num1 = self.get_total_num()
        lista = ['weather', '第三方', '启用', '可用', '2017-10-31 16:55:00', '2018-12-31 16:55:00']
        self.input_skill_name(lista[0])      # 搜索 技能名称为weather
        self.click_search_button()
        self.click_search_reset_button()
        num2 = self.get_total_num()
        assert num1 == num2
        self.input_skill_name(lista[0])                # 搜索  组合条件
        self.select_data_resource(3)
        self.select_skill_status(2)
        self.input_online_time_start(lista[4])
        self.input_online_time_end(lista[5])
        self.click_search_button()
        self.click_search_reset_button()
        num3 = self.get_total_num()
        assert num1 == num3

    # 技能管理 - 操作 - 内容维护(跳转到CMS)
    def contents_maintenance(self):
        self.input_skill_name('joke')
        self.click_search_button()
        driver = self.selib.driver
        self.click_contents_maintenance()
        handles = driver.window_handles
        driver.switch_to_window(handles[-1])
        self.wait_element_present("//div[@id='leftbar']", 10)
        print(driver.title)
        if driver.title:
            assert driver.title == "SmartOMP管理系统", "新打开的页面title不是CMS"

    # 技能管理 - 操作 - 详情
    def operation_details(self):
        self.input_skill_name('food')
        self.select_data_resource(3)
        self.click_search_button()
        self.click_results_operation()
        details = self.get_skill_details()
        details = details[0:3]+details[4:]
        print(details)  # 	['weather', '第三方', '可用', '2017/12/31 16:55:00', '天气服务', '128', 'weather——中文环境下的天气服务，覆盖世界上大部分地区 审核']
        desir_list = ['food', '第三方', '可用', '2017/12/31 16:55:00', '美食服务', 'food——百度map提供数据服务 审核']
        desir_list = desir_list[0:3]+desir_list[4:]
        assert details == desir_list, "Not Equal!"
        self.click_review()
        self.wait_page_contains('响应结果', 3)
        self.selib.page_should_contain("Successful get the service result")
    def disable_skill_service(self):
        """:接口测试的例子,请删除:"""
        interface = Base(constant.SV_USER, constant.SV_PWD)
        interface.get_sv_authinfo(318)
        url = "/v2/ux/agents/1/domains/313/disable"       # 313诗词服务
        para = {'domainid': 313}
        # pattern = r"$.[?(@.agentname=='新接口测试' && @.statisdate=='2019-06')].hittimes"
        r = interface.sv_request_with_authinfo(url, 'POST', parameter=para)
        print (r.status)
        assert r.status == 200, "请求response状态码错误"

    # 统计-页面内容显示1
    def check_hits_page_content_items(self):
        desire_list = ['技能名称', '数据来源', '供应商', '用户名', '应用ID', '应用名称', '开始时间', '结束时间', '用户名', '应用ID', '应用名称']
        lista = self.get_hits_search_items()
        print(lista)
        assert lista == desire_list, "not equal"
    # 统计-页面内容显示2
    def check_hits_page_thead(self):
        desire_list = ['技能ID', '技能名称', '来源', '数据来源', '供应商', '命中次数']
        lista = self.get_thead_text(7)
        assert lista == desire_list, "not equal"

    # 平台管理 - 统计 - 搜索
    def check_hits_search(self):
        lista = ['times', '第三方', '时间', 'pepper@cloudminds.com', '318', '新接口测试', '开始时间', '结束时间']
        self.wait_element_disapear(pm.loading_spin, 20)
        self.input_skill_name(lista[0])      # 搜索 技能名称
        self.selib.click_element(pm.hits_search_button)
        self.wait_element_disapear(pm.loading_spin, 20)
        result = self.selib.get_text("//tbody/tr[1]/td[2]")
        print(result)
        assert result == lista[0], "技能名称错误"
        self.selib.click_element(pm.hits_search_reset)
        self.select_data_resource(3)                      # 搜索 数据来源
        self.selib.click_element(pm.hits_search_button)
        self.wait_element_disapear(pm.loading_spin, 20)
        result = self.selib.get_text("//tbody/tr[1]/td[4]")
        assert result == lista[1], "数据来源错误"
        self.selib.click_element(pm.hits_search_reset)
        self.selib.input_text(pm.hits_service_input, lista[2])      # 搜索 供应商
        self.wait_element_disapear(pm.hits_search_button, 20)
        self.selib.click_element(pm.hits_search_button)
        self.wait_element_disapear(pm.loading_spin, 20)
        result = self.selib.get_text("//tbody/tr[1]/td[5]")
        assert result == lista[2], "供应商错误"
        self.selib.click_element(pm.hits_search_reset)
        # self.selib.input_text(pm.hits_username_input, lista[3])
        # self.selib.click_element(pm.hits_search_button)


        self.input_skill_name(lista[0])      # 搜索 技能名称
        self.select_data_resource(3)                      # 搜索 数据来源
        self.selib.input_text(pm.hits_service_input, lista[2])      # 搜索 供应商
        self.selib.click_element(pm.hits_search_button)
        self.wait_element_disapear(pm.loading_spin, 20)
        result1 = self.selib.get_text("//tbody/tr[1]/td[2]")
        print("result1--:",result1)
        assert result1 == lista[0], "技能名称错误"
        result2 = self.selib.get_text("//tbody/tr[1]/td[4]")
        print("result2--:", result2)
        assert result2 == lista[1], "数据来源错误"
        result3 = self.selib.get_text("//tbody/tr[1]/td[5]")
        print("result3--:", result3)
        assert result3 == lista[2], "供应商错误"
        # result = self.selib.get_text("//tbody/tr[1]/td[6]")
        # assert result == lista[3], "用户名错误"
        # self.selib.click_element(pm.hits_search_reset)
        # self.selib.input_text(pm.hits_agent_id_input, lista[4])
        # self.selib.click_element(pm.hits_search_button)

        #
        # result = self.selib.get_text("//tbody/tr[1]/td[7]")
        # assert result == lista[4], "用户ID错误"
        # self.selib.click_element(pm.hits_search_reset)
        # self.selib.input_text(pm.hits_agent_name_input, lista[5])
        # self.selib.click_element(pm.hits_search_button)
        # result = self.selib.get_text("//tbody/tr[1]/td[8]")
        # assert result == lista[5], "应用名称错误"
        # self.selib.click_element(pm.hits_search_reset)
    #  平台管理-统计-搜索重置
    def check_hits_reset(self):
        self.wait_element_disapear(pm.loading_spin, 10)
        num1 = self.get_total_num()
        lista = ['times', '第三方', '时间', 'pepper@cloudminds.com', '318', '新接口测试', '开始时间', '结束时间']
        self.input_skill_name(lista[0])      # 搜索 技能名称
        self.selib.click_element(pm.hits_search_button)
        self.wait_element_disapear(pm.loading_spin, 10)
        self.selib.click_element(pm.hits_search_reset)
        self.wait_element_disapear(pm.loading_spin, 10)
        num2 = self.get_total_num()
        assert num1 == num2, "重置后的列表结果与初始值不一致"
        self.input_skill_name(lista[0])                # 搜索  组合条件
        self.select_data_resource(3)
        self.selib.click_element(pm.hits_search_button)
        self.wait_element_disapear(pm.loading_spin, 10)
        self.selib.click_element(pm.hits_search_reset)
        self.wait_element_disapear(pm.loading_spin, 10)
        num3 = self.get_total_num()
        assert num1 == num3, "重置后的列表结果与初始值不一致"
    def check_checkbox_display(self, choice):          # choice --1 用户名   --2  应用ID  --3  应用名称
        self.wait_element_disapear(pm.loading_spin, 10)
        ch = int(choice)
        if ch == 1:
            self.selib.click_element(pm.hits_username_checkbox)
            self.selib.click_element(pm.hits_search_button)
            self.wait_element_disapear(pm.loading_spin, 35)
            item_new = self.selib.get_text("//table/thead/tr/th[6]")
            assert item_new == "用户名", "获取不到用户名"
            item_value = self.selib.get_text("//tbody/tr[1]/td[6]")
            assert item_value != None, "值不应该为空"
            self.selib.click_element(pm.hits_username_checkbox)
            # try:
            #     self.selib.get_text("//table/thead/tr/th[7]")
            # except ElementNotFoundError:             # error待验证
            #     a = 0
            # assert a == 0, "取消勾选失败"

        elif ch == 2:
            self.selib.click_element(pm.hits_agent_id_checkbox)
            self.selib.click_element(pm.hits_search_button)
            self.wait_element_disapear(pm.loading_spin, 10)
            item_new = self.selib.get_text("//table/thead/tr/th[6]")
            assert item_new == '应用ID', "获取不到应用ID"
            item_value = self.selib.get_text("//tbody/tr[1]/td[6]")
            assert item_value != None, "值不应该为空"
            self.selib.click_element(pm.hits_agent_id_checkbox)
            # try:
            #     self.selib.get_text("//table/thead/tr/th[7]")
            # except ElementNotFoundError:             # error待验证
            #     a = 0
            # assert a == 0, "取消勾选失败"
        else:
            self.selib.click_element(pm.hits_agent_name_checkbox)
            self.selib.click_element(pm.hits_search_button)
            self.wait_element_disapear(pm.loading_spin, 10)
            item_new = self.selib.get_text("//table/thead/tr/th[6]")
            assert item_new == '应用名称', "获取不到应用名称"
            item_value = self.selib.get_text("//tbody/tr[1]/td[6]")
            assert item_value != None, "值不应该为空"
            self.selib.click_element(pm.hits_agent_name_checkbox)
            # try:
            #     self.selib.get_text("//table/thead/tr/th[7]")
            # except ElementNotFoundError:             # error待验证
            #     a = 0
            # assert a == 0, "取消勾选失败"
    # 统计-命中次数默认降序排序
    def check_sort_by_hits_counts(self):
        hits_counts = []
        self.wait_element_disapear(pm.loading_spin, 10)
        for i in range(1, 11):
            hits_counts.append(int(self.selib.get_text("//tbody/tr[%d]/td[6]" % i)))
        hits_counts_descending = hits_counts
        hits_counts.sort(reverse=True)
        assert hits_counts == hits_counts_descending, "没有默认按照命中次数降序排序"
    # 统计-排序
    def check_sort_of_hits(self):
        # 按技能ID排序-升序
        self.wait_element_disapear(pm.loading_spin, 10)
        self.selib.click_element("//table/thead/tr/th[1]")
        self.wait_element_disapear(pm.loading_spin, 10)
        skill_ids = []
        for i in range(1, 11):
            skill_ids.append(int(self.selib.get_text("//tbody/tr[%d]/td[1]" % i)))
        skill_ids_asc = skill_ids
        skill_ids.sort(reverse=False)
        print(skill_ids)
        assert skill_ids == skill_ids_asc, "没有按照技能ID升序排序"
        # 按技能ID排序-降序
        self.wait_element_disapear(pm.loading_spin, 10)
        self.selib.click_element("//table/thead/tr/th[1]")
        self.wait_element_disapear(pm.loading_spin, 10)
        skill_ids = []
        for i in range(1, 11):
            skill_ids.append(int(self.selib.get_text("//tbody/tr[%d]/td[1]" % i)))
        skill_ids_desc = skill_ids
        skill_ids.sort(reverse=True)
        print(skill_ids)
        assert skill_ids == skill_ids_desc, "没有按照技能ID降序排序"
        # 按技能名称排序-升序
        self.wait_element_disapear(pm.loading_spin, 10)
        self.selib.click_element("//table/thead/tr/th[2]")
        self.wait_element_disapear(pm.loading_spin, 10)
        skill_names = []
        for i in range(1, 11):
            skill_names.append(self.selib.get_text("//tbody/tr[%d]/td[2]" % i))
        skill_names_asc = skill_names
        skill_names.sort(reverse=False)
        print(skill_names)
        assert skill_names == skill_names_asc, "没有按照技能名称升序排序"
        # 按技能名称排序-降序
        self.wait_element_disapear(pm.loading_spin, 10)
        self.selib.click_element("//table/thead/tr/th[2]")
        self.wait_element_disapear(pm.loading_spin, 10)
        skill_names = []
        for i in range(1, 11):
            skill_names.append(self.selib.get_text("//tbody/tr[%d]/td[2]" % i))
        skill_names_desc = skill_names
        skill_names.sort(reverse=True)
        print(skill_names)
        assert skill_names == skill_names_desc, "没有按照技能名称降序排序"

        # 按来源排序-升序
        self.wait_element_disapear(pm.loading_spin, 10)
        self.selib.click_element("//table/thead/tr/th[3]")
        self.wait_element_disapear(pm.loading_spin, 10)
        resources = []
        for i in range(1, 11):
            resources.append(self.selib.get_text("//tbody/tr[%d]/td[3]" % i))
        resources_asc = resources
        resources.sort(reverse=False)
        print(resources)
        assert resources == resources_asc, "没有按照来源升序排序"
        # 按来源排序-降序
        self.wait_element_disapear(pm.loading_spin, 10)
        self.selib.click_element("//table/thead/tr/th[3]")
        self.wait_element_disapear(pm.loading_spin, 10)
        resources = []
        for i in range(1, 11):
            resources.append(self.selib.get_text("//tbody/tr[%d]/td[3]" % i))
        resources_desc = resources
        resources.sort(reverse=True)
        print(resources)
        assert resources == resources_desc, "没有按照来源降序排序"

        # 按数据来源排序-升序
        self.wait_element_disapear(pm.loading_spin, 10)
        self.selib.click_element("//table/thead/tr/th[4]")
        self.wait_element_disapear(pm.loading_spin, 10)
        data_resources = []
        for i in range(1, 11):
            data_resources.append(self.selib.get_text("//tbody/tr[%d]/td[4]" % i))
        data_resources_asc = data_resources
        data_resources.sort(reverse=False)
        print(data_resources)
        assert data_resources == data_resources_asc, "没有按照数据来源升序排序"
        # 按数据来源排序-降序
        self.wait_element_disapear(pm.loading_spin, 10)
        self.selib.click_element("//table/thead/tr/th[4]")
        self.wait_element_disapear(pm.loading_spin, 10)
        data_resources = []
        for i in range(1, 11):
            data_resources.append(self.selib.get_text("//tbody/tr[%d]/td[4]" % i))
        data_resources_desc = data_resources
        data_resources.sort(reverse=True)
        print(data_resources)
        assert data_resources == data_resources_desc, "没有按照数据来源降序排序"

        # 按供应商排序-升序
        self.wait_element_disapear(pm.loading_spin, 10)
        self.selib.click_element("//table/thead/tr/th[5]")
        self.wait_element_disapear(pm.loading_spin, 10)
        services = []
        for i in range(1, 11):
            services.append(self.selib.get_text("//tbody/tr[%d]/td[5]" % i))
        services_asc = services
        services.sort(reverse=False)
        print(services)
        assert services == services_asc, "没有按照供应商升序排序"
        # 按供应商排序-降序
        self.wait_element_disapear(pm.loading_spin, 10)
        self.selib.click_element("//table/thead/tr/th[5]")
        self.wait_element_disapear(pm.loading_spin, 10)
        services = []
        for i in range(1, 11):
            services.append(self.selib.get_text("//tbody/tr[%d]/td[5]" % i))
        services_desc = services
        services.sort(reverse=True)
        print(services)
        assert services == services_desc, "没有按照供应商降序排序"
    def check_hits_export(self):
        self.selib.click_element(pm.hits_export_button)
        title = self.selib.get_text(pm.export_dialog_title)
        assert title == "导出", "title错误"
        self.selib.page_should_contain_element(pm.export_cancel_button)
        self.selib.page_should_contain_element(pm.export_export_button)

    # 统计-命中次数-导出（导出）
    def hits_export(self):
        self.selib.click_element(pm.hits_export_button)
        time.sleep(5)
        self.selib.click_element(pm.export_export_button)
        tooltip = "//div[@class='ant-message-notice-content']/div[contains(@class,'ant-message-success')]/span"
        self.wait_element_visible(tooltip, 10)
        text = self.selib.get_text(tooltip)
        print("test:---",text)
        assert text == '操作成功', "无操作成功提示"
        self.selib.element_should_be_enabled(pm.hits_search_button)

    # 统计 - 命中次数 - 勾选用户名、应用ID、应用名称后搜索导出
    def hits_check_and_export(self):
        try:
            filepath = os.path.abspath(os.path.join(os.getcwd())) + os.sep + '导出记录.xlsx'
            print("filepath----:",filepath)
            # self.remove_file(filepath)
            self.selib.click_element(pm.hits_username_checkbox)
            self.selib.click_element(pm.hits_agent_id_checkbox)
            self.selib.click_element(pm.hits_agent_name_checkbox)
            self.selib.click_element(pm.hits_search_button)
            time.sleep(10)
            print("+++++++++")
            # self.wait_element_disapear(pm.loading_spin, 5)
            self.selib.page_should_contain_element("//tbody/tr[1]/td[5]")
            self.selib.page_should_contain_element("//tbody/tr[1]/td[6]")
            self.selib.page_should_contain_element("//tbody/tr[1]/td[7]")
            self.selib.click_element(pm.hits_export_button)
            self.selib.click_element(pm.export_export_button)
            self.wait_element_disapear(pm.export_cancel_button, 10)
            self.check_xls(filepath)
            xl_list = self.check_xls(filepath)
            print("-----",xl_list)
            if xl_list:
                print("list-----------",xl_list[0], xl_list[1], xl_list[2])
                assert [xl_list[0][0], xl_list[1][0], xl_list[2][0]] == ['用户名', '应用ID', '应用名称'], "表头字段不一致"
            else:
                print("导出的数据不含用户名、应用ID和应用名称！")
        finally:
            self.remove_file(filepath)
            # self.hit_check_search_export()


    def sensitive_words_base(self):
        self.open_sensitive_words()
        desir = self.get_thead_text(3)
        assert desir == ['敏感词', '操作'], "获取的表头文字错误"
    def sensitive_words_search(self):
        self.open_sensitive_words()
        self.selib.input_text(pm.sensitive_search_input, "的")
        self.selib.click_element(pm.sensitive_search_button)
        text = self.selib.get_text("//tbody/tr[1]/td[1]")
        assert "的" in text, "模糊搜索失败！"
    def sensitive_words_create(self):
        self.open_sensitive_words()
        self.selib.click_element(pm.sensitive_create_button)
        self.selib.page_should_contain_element(pm.sensitive_create_label)
        self.selib.page_should_contain_element(pm.sensitive_cancel_button)
        self.selib.page_should_contain_element(pm.sensitive_save_button)
    def sensitive_words_create_null(self):
        self.open_sensitive_words()
        self.selib.click_element(pm.sensitive_create_button)
        self.selib.element_should_be_disabled(pm.sensitive_save_button)
    def sensitive_words_create_right(self):
        self.open_sensitive_words()
        self.delete_data_with_duplicate_name('测试auto')
        self.selib.click_element(pm.sensitive_create_button)
        self.selib.input_text(pm.sensitive_words_input, "测试auto")
        self.selib.click_element(pm.sensitive_save_button)
        tooltip = "//div[@class='ant-message-notice-content']/div[contains(@class,'ant-message-success')]/span"
        self.wait_element_visible(tooltip, 10)
        text = self.selib.get_text(tooltip)
        assert text == '操作成功', "无操作成功提示"
        self.selib.page_should_contain("测试auto")
        self.delete_data_with_duplicate_name('测试auto')
    def sensitive_words_create(self):
        self.open_sensitive_words()
        self.selib.click_element(pm.sensitive_create_button)
        self.selib.input_text(pm.sensitive_words_input, "测试auto")
        self.selib.click_element(pm.sensitive_save_button)
    def sensitive_words_edit_check(self):  # 编辑第一条数据
        self.open_sensitive_words()
        first_word = self.selib.get_text("//tbody/tr[1]/td[1]")
        print(first_word)
        self.selib.click_element("//tbody/tr[1]/td[2]/button[1]")
        # before_edit_value = self.selib.get_text(pm.sensitive_words_input)
        self.selib.textfield_value_should_be(pm.sensitive_words_input, first_word)
        # print(before_edit_value)
        # assert before_edit_value == first_word, "数据不一致"
        self.selib.page_should_contain_element(pm.sensitive_save_button)
        self.selib.page_should_contain_element(pm.sensitive_cancel_button)
    def sensitive_words_edit_null(self):
        self.open_sensitive_words()
        rand = random.randint(1, 10)
        self.selib.click_element("//tbody/tr[%d]/td[2]/button[1]" % (rand))
        driver = self.selib.driver
        driver.find_element_by_xpath(pm.sensitive_words_input).clear()
        self.selib.press_keys(pm.sensitive_words_input, 'a')
        self.selib.press_keys(pm.sensitive_words_input, 'BACKSPACE')
        self.selib.element_should_be_disabled(pm.sensitive_save_button)
        self.selib.page_should_contain("必填")

    def sensitive_words_edit_right(self):
        self.open_sensitive_words()
        self.delete_data_with_duplicate_name("测试auto")
        self.delete_data_with_duplicate_name("测试autoNEW")
        self.sensitive_words_create()
        self.wait_element_disapear(pm.loading_spin, 5)
        self.selib.input_text(pm.sensitive_search_input, "测试auto")
        self.selib.click_element(pm.sensitive_search_button)
        self.wait_element_disapear(pm.loading_spin, 5)
        self.selib.click_element("//tbody/tr[1]/td[2]/button[1]")
        self.selib.input_text(pm.sensitive_words_input, "测试autoNEW")
        self.selib.click_element(pm.sensitive_save_button)
        self.selib.page_should_contain("测试autoNEW")
        self.selib.element_should_be_enabled(pm.sensitive_search_button)
        self.delete_data_with_duplicate_name("测试autoNEW")
    def delete_sensitive_words(self, words):
        self.selib.input_text(pm.sensitive_search_input, words)
        self.selib.click_element(pm.sensitive_search_button)
        self.wait_element_disapear(pm.loading_spin, 5)
        self.selib.click_element("//tbody/tr[1]/td[2]/button[2]")  # 第一条数据的删除按钮
        self.selib.click_element(pm.sensitive_words_delete_confirm)
    def delete_data_with_duplicate_name(self, words):
        self.selib.input_text(pm.sensitive_search_input, words)
        self.selib.click_element(pm.sensitive_search_button)
        self.wait_element_disapear(pm.loading_spin, 5)
        try:
            num = self.selib.get_element_count("//tbody//tr/td[text()='%s']"%(words))
            for i in range(1, num+1):
                print(i)
                self.selib.click_element("//tbody//tr[%d]/td[text()='%s']/../td/button[2]" %(i, words))
                self.selib.click_element(pm.sensitive_words_delete_confirm)
        except:
            pass
    def sensitive_words_delete_check(self):
        self.open_sensitive_words()
        self.delete_data_with_duplicate_name("测试auto")
        self.sensitive_words_create()
        self.selib.click_element("//tbody/tr[1]/td[2]/button[2]")   # 第一条数据的删除按钮
        self.selib.page_should_contain("确定要删除敏感词吗？")
        self.selib.page_should_contain_element(pm.sensitive_words_delete_cancel)
        self.selib.page_should_contain_element(pm.sensitive_words_delete_confirm)
        self.selib.click_element(pm.sensitive_words_delete_confirm)
    def sensitive_words_delete(self):
        self.open_sensitive_words()
        self.delete_data_with_duplicate_name("测试auto")
        self.sensitive_words_create()
        self.wait_element_disapear(pm.loading_spin, 5)
        self.selib.click_element("//tbody/tr[1]/td[2]/button[2]")  # 第一条数据的删除按钮
        self.selib.click_element(pm.sensitive_words_delete_confirm)
        self.selib.page_should_contain_element(pm.sensitive_search_button)
        self.selib.page_should_not_contain("测试auto")
    def response_time_page_content(self):
        self.open_response_time()
        self.selib.page_should_contain_element(pm.response_time_start_time)
        self.selib.page_should_contain_element(pm.response_time_end_time)
        self.selib.page_should_contain_element(pm.response_time_min)
        self.selib.page_should_contain_element(pm.response_time_hour)
        self.selib.page_should_contain_element(pm.response_time_day)
        self.selib.page_should_contain_element(pm.response_time_chart)

    # 技能管理-技能状态
    def skill_status_check(self, service_name):
        self.input_skill_name(service_name)
        self.click_search_button()
        results = self.get_search_results()
        skill_status = results[3]
        itf_status = self.get_service_info_by_name(service_name)
        print(skill_status, type(skill_status))
        print(itf_status['enabled'], type(itf_status['enabled']))
        if skill_status == '可用':
            assert itf_status['enabled'] == True, '接口中的该服务状态与技能管理不一致'
        else:
            assert itf_status['enabled'] == False, '接口中的该服务状态与技能管理不一致'

    # 技能管理-数据来源
    def get_data_resource(self, skill_name):
        self.input_skill_name(skill_name)
        self.click_search_button()
        results = self.get_search_results()
        data_resource = results[2]
        re = self.get_service_info(skill_name)
        print(re)
        tp = re[0][0]['type']
        assert data_resource == tp, "数据来源错误"
    # 技能管理-上线时间
    def get_online_time(self, skill_name):
        self.input_skill_name(skill_name)
        self.click_search_button()
        results = self.get_search_results()
        online_time = results[4]
        re = self.get_service_info(skill_name)
        timeStamp = re[0][0]['createtime']
        timeArray = time.localtime(timeStamp)
        disr_time = time.strftime("%Y-%m-%d %H:%M:%S", timeArray)
        assert disr_time == online_time, "上线时间错误"
    # 技能管理-技能描述
    def get_skill_description(self, skill_name):
        self.input_skill_name(skill_name)
        self.click_search_button()
        results = self.get_search_results()
        skill_descp = results[1]
        re = self.get_service_info(skill_name)
        domaininfo = re[0][0]['domaininfo']
        assert domaininfo == skill_descp, "技能描述错误"

    # 统计 - 数据来源
    def get_hits_data_resource(self, skill_name):
        self.input_skill_name(skill_name)
        self.selib.click_element(pm.hits_search_button)
        self.wait_element_disapear(pm.loading_spin, 10)
        data_resource = self.selib.get_text("//tbody/tr[1]/td[4]")  #获取数据来源
        re = self.get_service_info(skill_name)
        print(re)
        tp = re[0][0]['type']
        assert data_resource == tp, "数据来源错误"
    # 响应时间-时间监控报表
    def response_time_chart_check(self):
        self.wait_element_present(pm.response_time_start_time, 10)
        self.wait_element_disapear(pm.loading_spin, 10)
        self.selib.click_element(pm.response_time_start_time)
        year_start = self.selib.get_text("//a[@class='ant-calendar-year-select']")
        mon_start = self.selib.get_text("//a[@class='ant-calendar-month-select']")
        day_start = self.selib.get_text("//td[contains(@class,'ant-calendar-selected-day')]/div")
        print("mon_start---:",mon_start,mon_start[0],mon_start[1],mon_start[2])
        # if int(mon_start[0]) < 10: #baldwin,之前的代码这样判断会出现错误，在月大于9月时，修改
        if len(mon_start) < 3:
            mon_start = '0' + mon_start
        if int(day_start) < 10:
            day_start = '0' + day_start
        print(year_start)
        print(mon_start)
        print(day_start)
        self.selib.click_element("//a[contains(@class,'ant-calendar-time-picker-btn')]")
        hour_start = self.selib.get_text("//div[contains(@class,'ant-calendar-time-picker-select')][1]/ul/li[contains(@class,'ant-time-picker-panel-select-option-selected')]")
        min_start = self.selib.get_text("//div[contains(@class,'ant-calendar-time-picker-select')][2]/ul/li[contains(@class,'ant-time-picker-panel-select-option-selected')]")
        second_start = self.selib.get_text("//div[contains(@class,'ant-calendar-time-picker-select')][3]/ul/li[contains(@class,'ant-time-picker-panel-select-option-selected')]")
        get_start_time = year_start[:4] + '-' + mon_start[:2] + '-' + day_start+' '+hour_start+':'+min_start+':'+second_start
        print(get_start_time)
        self.selib.click_element('//span[@class="ant-calendar-footer-btn"]/a[3]')
        # self.selib.click_element('//span[@class="ant-calendar-footer-btn"]/a[3]')
        self.wait_element_disapear(pm.loading_spin, 10)


        self.selib.click_element(pm.response_time_end_time)
        year_end = self.selib.get_text("//a[@class='ant-calendar-year-select']")
        mon_end = self.selib.get_text("//a[@class='ant-calendar-month-select']")
        day_end = self.selib.get_text("//td[contains(@class,'ant-calendar-selected-day')]/div")
        # if int(mon_end[0]) < 10:#baldwin,之前的代码这样判断会出现错误，在月大于9月时，修改
        if len(mon_end) < 3:
            mon_end = '0' + mon_end
        if int(day_end) < 10:
            day_end = '0' + day_end
        print(year_end)
        print(mon_end)
        print(day_end)
        self.selib.click_element("//a[contains(@class,'ant-calendar-time-picker-btn')]")
        hour_end = self.selib.get_text("//div[contains(@class,'ant-calendar-time-picker-select')][1]/ul/li[contains(@class,'ant-time-picker-panel-select-option-selected')]")
        min_end = self.selib.get_text("//div[contains(@class,'ant-calendar-time-picker-select')][2]/ul/li[contains(@class,'ant-time-picker-panel-select-option-selected')]")
        second_end = self.selib.get_text("//div[contains(@class,'ant-calendar-time-picker-select')][3]/ul/li[contains(@class,'ant-time-picker-panel-select-option-selected')]")
        get_end_time = year_end[:4] + '-' + mon_end[:2] + '-' + day_end+' '+hour_end+':'+min_end+':'+second_end
        print(get_end_time)


        yesterday = datetime.datetime.now() + datetime.timedelta(days=-1)
        yes_start = yesterday.strftime("%Y-%m-%d" + ' 00:00:00')
        yes_end = yesterday.strftime("%Y-%m-%d" + ' 23:59:59')
        print(get_start_time)
        print(get_end_time)
        assert get_start_time == yes_start, "默认开始时间错误！"
        assert get_end_time == yes_end, "默认结束时间错误！"

    # 分类显示
    def classified_display(self):
        self.selib.page_should_contain_element(pm.top_bar_skill_management)
        self.selib.page_should_contain("统计")
        self.selib.page_should_contain("敏感词")
        url = self.selib.get_location()
        desire_url = constant.SERVER+"/#/platform/skills"
        assert url == desire_url, "当前不在技能管理菜单下"

    # 技能管理-超链接
    def test_hyperlink(self, service_name, agent_name):
        ret1 = self.get_service_info_by_name(service_name)
        ret2 = self.get_service_info(service_name)
        assert ret1['agentid'] == ret2[0][0]['agentid'], "应用ID不一致"
    # 统计-来源
    def statistics_resource(self, question, resource):
        res = self.bl_get_sv_response_source(question)
        assert res == resource, "服务来源错误！"
    # 平台管理-问答
    def check_oper_account(self):
        self.selib.page_should_contain('技能管理')
        self.selib.page_should_contain('统计')
        self.selib.page_should_contain('敏感词')
        self.selib.page_should_not_contain('应用:')

    # 平台管理-统计-供应商
    def statistics_Supplier(self):
        dicta = {'music':'网易云音乐', 'search':'搜索', 'qa':'腾讯闲聊'}
        for key in dicta.keys():
            self.input_skill_name(key)
            self.select_data_resource(3)
            self.selib.click_element(pm.hits_search_button)
            self.wait_element_disapear(pm.loading_spin, 10)
            self.selib.page_should_contain(dicta[key])
            # msc_suppler = self.selib.get_text("//tbody/tr[1]/td[5]")   # 获取供应商
            # print(msc_suppler)
            # assert msc_suppler == dicta[key], "供应商错误"
    # 统计-命中次数
    def statistics_hits_number(self, question):
        self.input_skill_name('joke')
        self.selib.click_element(pm.hits_search_button)
        self.wait_element_disapear(pm.loading_spin, 10)
        get_hits_before = self.selib.get_text("//tbody/tr[1]/td[6]")   # 获取命中次数
        print(get_hits_before)
        self.bl_get_sv_response_source(question)
        self.selib.click_element(pm.hits_search_reset)
        self.input_skill_name('joke')
        self.selib.click_element(pm.hits_search_button)
        self.wait_element_disapear(pm.loading_spin, 10)
        get_hits_after = self.selib.get_text("//tbody/tr[1]/td[6]")   # 获取命中次数
        print(get_hits_after)
        # assert get_hits_before < get_hits_after, "命中次数无变化，失败！" #baldwin ,统计命中次数为24小时统计一次，之前的问完就进行测试，无法正常进行测试，
        assert (get_hits_before == get_hits_after) and (int(get_hits_after) > 995), "命中次数无变化，失败！" #baldwin，只要大于历史数据，就认为统计功能正常,20192为20191009日数据

    # 第三方服务审核
    def third_party_verify(self):
        self.input_skill_name("times")
        self.click_search_button()
        self.click_results_operation()
        self.selib.click_element(pm.details_radio)
        self.selib.click_element(pm.details_review)
        self.selib.page_should_contain("Successful get the service result")
        self.selib.page_should_contain("现在时间")

    # 响应时间-时间监控报表（分/小时/天）
    def time_monitoring_report(self, starttime, endtime):
        ret = self.get_response_time_by_min(starttime, endtime)
        # print(ret)
        assert ret, "分钟-维度的响应时间数据为空！"
        ret = self.get_response_time_by_hour(starttime, endtime)
        # print(ret)
        assert ret, "小时-维度的响应时间数据为空！"
        ret = self.get_response_time_by_day(starttime, endtime)
        # print(ret)
        assert ret, "天-维度的响应时间数据为空！"

    # 响应时间-时间监控报表开始时间/结束时间
    def time_monitoring_report_time_end(self, starttime, endtime):
        ret = self.get_statistime_by_hour(starttime, endtime)
        # print(ret)
        # print(type(starttime))
        for t in ret:
            # print(t)
            # print(type(t))
            assert starttime[:-4] <= t <= endtime[:-4], "响应时间数据的时间段错误"






    # def test_get_all_skills(self):
    #     #print(self.get_skills())
    #     #self.get_service_info_by_name('meta')
    #     # assert self.set_status_for_service('meta', True)
    #     # assert not self.set_status_for_service('meta', False)
    #     # self.get_service_info('weather')
    #     self.get_service_agent_id('food', 'system')
    # def get_cms_joke_id(self, title):
    #     joke_id = self.cms_search_joke(title)
    #     print("joke id 为：", joke_id)
    #     self.cms_delete_joke(joke_id)
    #
    # def add_cms_joke(self, content, content1):
    #     self.cms_add_joke(content)
    #     joke_id = self.cms_search_joke(content)
    #     self.cms_edit_joke(joke_id, content1)
    #
    # def testtest(self):
    #     self.cms_add_joke('auto测试0812')
    #     # self.login_cms()
    #     # self.cms_search_joke()
    #     # self.cms_delete_joke()
    #     # self.cms_edit_joke()
    # ROC进入CMS编辑 - 笑话
    def goto_cms_edit_joke(self, content, content_new):
        session_id = self.get_smartompsessionid()
        add_info = self.cms_add_joke(session_id, content)
        assert add_info, "新增笑话失败！"
        joke_id = self.cms_search_joke(session_id, content)
        assert joke_id, "搜索笑话失败！"
        edit_info = self.cms_edit_joke(session_id, joke_id, content_new)
        assert edit_info, "编辑笑话失败！"
        # 添加审核，否则编辑后全部同步失败
        sync_joke = self.story_joke(joke_id)
        assert sync_joke, "审核失败！！"
        try:
            response = self.get_sv_response_text("id是%s的笑话"%(joke_id))
            assert response == content_new, "编辑的笑话同步失败！"
        finally:
            del_info = self.cms_delete_joke(session_id, joke_id)
            assert del_info, "删除笑话失败！"
    # ROC进入CMS编辑 - 故事
    def goto_cms_edit_story(self, title, content, content_new):
        session_id = self.get_smartompsessionid()
        add_info = self.cms_add_story(session_id, title, content)
        assert add_info, "新增故事失败！"
        story_id = self.cms_search_story(session_id, title)    #和诗词共用同一搜索接口
        assert story_id, "搜索故事失败！"
        edit_info = self.cms_edit_story(session_id, story_id, title, content_new)
        assert edit_info, "编辑故事失败！"
        #添加审核，否则编辑后全部同步失败
        sync_story=self.story_sync(story_id)
        assert sync_story,"审核失败！！"
        time.sleep(5)
        try:
            response = self.get_sv_response_text("讲个%s故事"%(title))
            assert response == content_new, "编辑的故事同步失败！"
        finally:
            del_info = self.cms_delete_story(session_id, story_id)
            assert del_info, "删除故事失败！"
    # ROC进入CMS编辑 - 诗词
    def goto_cms_edit_poetry(self, title, content, content_new):
        # session_id = self.get_smartompsessionid()
        # add_info = self.cms_add_poetry(session_id, title, content)
        # print("添加诗词：",add_info)
        # assert add_info, "新增诗词失败！"
        # poetry_id = self.cms_search_poetry(session_id, title)
        # assert poetry_id, "搜索诗词失败！"
        # edit_info = self.cms_edit_poetry(session_id, poetry_id, title, content_new)
        # assert edit_info, "编辑诗词失败！"
        # #添加审核，否则编辑后全部同步失败
        # sync_poetry=self.poetry_sync(poetry_id)
        # assert sync_poetry,"审核失败！！"
        # time.sleep(15)
        # try:
        #     response = self.get_sv_response_text("读一下%s这一首诗"%(title))
        #     assert response == content_new, "编辑的诗词同步失败！"
        # finally:
        #     del_info = self.cms_delete_poetry(session_id, poetry_id)
        #     assert del_info, "删除诗词失败！"
        #     # pass
        session_id = self.get_adminlogin_cms_token()
        add_info = self.sv_cms_add_poetry(session_id, title, content)
        print("添加诗词：",add_info)
        assert add_info, "新增诗词失败！"
        poetry_id = self.sv_cms_search_poetry(session_id, title)
        assert poetry_id, "搜索诗词失败！"
        edit_info = self.sv_cms_edit_poetry(session_id, poetry_id, title, content_new)
        assert edit_info, "编辑诗词失败！"
        #添加审核，否则编辑后全部同步失败
        sync_poetry=self.poetry_sync(poetry_id)
        assert sync_poetry,"审核失败！！"
        time.sleep(15)
        try:
            response = self.get_sv_response_text("读一下%s这一首诗"%(title))
            print("response---:",response,content_new)
            assert response == content_new, "编辑的诗词同步失败！"
        finally:
            del_info = self.cms_delete_poetry(session_id, poetry_id)
            assert del_info, "删除诗词失败！"


    # ROC进入CMS编辑 - 相声
    def goto_cms_edit_crosstalk(self, title, author, keyword, audio_link1, audio_link2):
        cms_url = constant.CMS_SERVER
        session_id = self.get_smartompsessionid()
        add_info = self.cms_add_crosstalk(session_id, title, author, keyword, audio_link1)
        assert add_info, "新增相声失败！"
        data_id = self.cms_search_crosstalk(session_id, title)
        print(data_id)
        assert data_id, "搜索相声失败！"
        edit_info = self.cms_edit_crosstalk(session_id, data_id, title, author, audio_link1, audio_link2)
        assert edit_info, "编辑相声失败！"
        #添加审核，否则编辑后全部同步失败
        sync_crosstalk=self.crosstalk_sync(data_id)
        assert sync_crosstalk,"审核失败！！"
        time.sleep(5)
        try:
            response = self.get_sv_response_url("我想听段相声%s" % (title))
            print(response)
            url = cms_url + audio_link2
            print(url)
            assert url == response, "编辑的相声同步失败"
        finally:
            del_info = self.cms_delete_crosstalk(session_id, data_id)
            assert del_info, "删除相声失败！"

    # ROC进入CMS编辑 - 评书
    def goto_cms_edit_storytelling(self, title, author, keyword, audio_link1, audio_link2):
        cms_url = constant.CMS_SERVER
        session_id = self.get_smartompsessionid()
        add_info = self.cms_add_storytelling(session_id, title, author, keyword)
        assert add_info, "新增评书失败！"
        id = self.cms_search_crosstalk(session_id, title)  # 和相声共用搜索接口
        print("ids------------",id)
        assert id, "搜索评书失败！"
        edit_info = self.cms_edit_storytelling(session_id, id, title, author, audio_link1, audio_link2)
        assert edit_info, "编辑评书失败！"
        #添加审核，否则编辑后全部同步失败
        sync_pingshu=self.storytelling_sync(id)
        assert sync_pingshu,"审核失败！！"
        time.sleep(15)
        try:
            response = self.get_sv_response_url("我想听评书%s" % (title))
            print("responseresponseresponseresponse--",response)
            url = cms_url + audio_link2
            print("url------------",url)
            assert url == response, "编辑的评书同步失败"
        finally:
            del_info = self.cms_delete_storytelling(session_id, id)
            assert del_info, "删除评书失败！"





    # ROC进入CMS编辑 - 戏剧
    def goto_cms_edit_drama(self, title, author, keyword, audio_link1, audio_link2):
        cms_url = constant.CMS_SERVER
        session_id = self.get_smartompsessionid()
        add_info = self.cms_add_drama(session_id, title, author, keyword)
        assert add_info, "新增戏曲失败！"
        id = self.cms_search_crosstalk(session_id, title)
        print(id)
        assert id, "搜索戏曲失败！"
        edit_info = self.cms_edit_drama(session_id, id, title, author, audio_link1, audio_link2)
        assert edit_info, "编辑戏曲失败！"
        #添加审核，否则编辑后全部同步失败
        sync_drama=self.drama_sync(id)
        assert sync_drama,"审核失败！！"
        time.sleep(15)
        try:
            response = self.get_sv_response_url("我要听戏曲%s" % (title))
            print(response)
            url = cms_url + audio_link2
            print(url)
            assert url == response, "编辑的戏曲同步失败"
        finally:
            del_info = self.cms_delete_storytelling(session_id, id)
            assert del_info, "删除戏曲失败！"

    def print_session(self):
        session_id = self.get_sv_session_id()
        print(session_id)

if __name__ == "__main__":
    TestPlatformManagement().test_get_all_skills()






