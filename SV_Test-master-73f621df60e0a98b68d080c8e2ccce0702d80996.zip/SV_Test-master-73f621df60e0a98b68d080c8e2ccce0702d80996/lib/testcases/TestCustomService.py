#!/usr/bin/env python
# coding=utf-8

from lib.modules.CustomService import CustomService
from lib.utils import constant
import random
import os
import time
import urllib.parse

class TestCustomService(CustomService):
    ROBOT_LIBRARY_SCOPE = 'TEST SUITE'
    ROBOT_LIBRARY_VERSION = "0.1"

    def __init__(self):
        CustomService.__init__(self, constant.SV_USER, constant.SV_PWD)

    #自定义服务重名验证
    def test_domainName_DoubleName(self):
        try:
            result = self.create_domain("domainnamedoublename")
            if result:
                result = self.create_domain("domainnamedoublename")
                print(result)
                if "domain name has been already in current agent." in result:
                    print("自定义重名测试通过！")
                    assert True
                else:
                    print("自定义重名测试失败！")
                    assert False
        finally:
            #数据清理
            clearinfo = self.delete_domain_by_domain_name("domainnamedoublename")
            assert clearinfo, "数据清理失败！"


    #自定义服务-编辑
    def test_domain_edit(self):
        try:
            result = self.create_domain("domainnamedoublename")
            if result:
                result = self.edit_domain("domainnamedoublename","domainnamedoublename",0)
                if result:
                    print("自定义服务编辑测试通过！")
                    assert True
                else:
                    print("自定义服务编辑测试失败！")
                    assert False
        finally:
            #数据清理
            clearinfo = self.delete_domain_by_domain_name("domainnamedoublename")
            assert clearinfo, "数据清理失败！"

    #自定义服务-删除
    def test_domain_delete(self):
        try:
            result = self.create_domain("domainnamedoublename")
            if result:
                result = self.delete_domain_by_domain_name("domainnamedoublename")
                if result:
                    print("自定义服务删除测试通过！")
                    assert True
                else:
                    print("自定义服务删除测试失败！")
                    assert False
        finally:
            #数据清理
            # result = result
            # assert result,"数据清理失败！"
            print("info!")


    #自定义服务-服务列表导入
    def test_domain_importFiletemplate(self):
        # 模板下载
        importdomainname = self.download_domain_filetemplate()
        try:
            if importdomainname:
                result = self.import_domain_filetemplate()
                if result:
                    print("自定义服务列表导入测试通过！")
                    assert True
                else:
                    print("自定义服务列表导入测试失败！")
                    assert False
        finally:
            #数据清理
            clearinfo = self.delete_domain_by_domain_name(importdomainname)
            assert clearinfo, "数据清理失败！"


    #自定义服务-服务列表导出
    def test_domain_export(self):
        # 创建自定义服务
        result = self.create_domain("domainnamedoublename")
        domainLength = len(self.get_domain_itemtotalcountlist())#平台上服务总数量
        intentsLength = self.get_intents_itemtotalcount()#平台上服务下所有的意图总数
        try:
            #服务导出
            exporttuple = self.export_domain()
            if exporttuple != "no domain!":
                if (exporttuple[0] == domainLength) and (exporttuple[1] == intentsLength):
                    print("domains:",exporttuple[0])
                    print("intents:",exporttuple[1])
                    print("自定义服务列表导出测试通过！")
                    assert True
                else:
                    print("自定义服务列表导出测试失败！")
                    assert False
        finally:
            #数据清理
            #result = self.delete_domain_by_domain_name(importdomainname)
            #assert result,"数据清理成功！"
            print("True")
            # 数据清理
            clearinfo = self.delete_domain_by_domain_name("domainnamedoublename")
            assert clearinfo, "数据清理失败！"

    # 自定义服务-意图列表的显示和浏览操作
    def test_intentslist_browse(self):
        #创建服务
        domainname = "domaintestone"+str(random.randint(10000,99999))
        result = self.create_domain(domainname)
        try:
            if result:
                #创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                intentnames = self.create_domain_intents(domain_id)
                if intentnames:
                    intents_id = self.get_intents_id_by_domain_name(domain_id,intentnames)
                    intentsname = self.get_intentsOFinstentsname(domain_id,intents_id)
                    inputcontext = self.get_intentsOFinputcontext(domain_id,intents_id)
                    outputcontext = self.get_intentsOFoutputcontext(domain_id,intents_id)
                    prompt = self.get_intentsOFprompt(domain_id,intents_id)
                    if intentnames == intentsname:
                        print("意图名称一致！")
                        if inputcontext == "inputcontext":
                            print("上文一致！")
                            if outputcontext == "outputcontext":
                                print("下文一致！")
                                if prompt == "prompt":
                                    print("回复一致！")
                                    assert True
                                else:
                                    print("回复不一致！")
                                    assert False
                            else:
                                print("下文不一致！")
                                assert False
                        else:
                            print("上文不一致！")
                            assert False
                    else:
                        print("意图名称不一致！")
                        assert False
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            # 数据清理
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"

    #自定义服务-意图列表-新建
    def test_intents_create(self):
        # 创建服务
        domainname = "domaintestone" + str(random.randint(10000, 99999))
        try:
            result = self.create_domain(domainname)
            if result:
                # 创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                intentnames = self.create_domain_intents(domain_id)
                if intentnames:
                    print("意图创建成功！意图名称为：{}".format(intentnames))
                    assert True
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            #数据清理
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"


    #自定义服务-意图列表-删除
    def test_intents_delete(self):
        # 创建服务
        domainname = "domaintestone" + str(random.randint(10000, 99999))
        result = self.create_domain(domainname)
        try:
            if result:
                # 创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                intentnames = self.create_domain_intents(domain_id)
                if intentnames:
                    intents_id = self.get_intents_id_by_domain_name(domain_id, intentnames)
                    result = self.delete_domain_intents(domain_id,intents_id)
                    if result:
                        print("意图删除测试成功！")
                        assert True
                    else:
                        print("意图删除测试失败！")
                        assert False
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            #数据清理
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"

    #自定义服务-意图列表-编辑
    def test_intents_edit(self):
        # 创建服务
        domainname = "domaintestone" + str(random.randint(10000, 99999))
        result = self.create_domain(domainname)
        try:
            if result:
                # 创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                intentnames = self.create_domain_intents(domain_id)
                if intentnames:
                    intents_id = self.get_intents_id_by_domain_name(domain_id, intentnames)
                    result = self.edit_intents(domain_id,intents_id,"editintentsname","editinputcontextm","editoutputcontextm","editpromp","editcorpustext")
                    if result:
                        print("意图编辑测试成功！")
                        assert True
                    else:
                        print("意图编辑测试失败！")
                        assert False
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            #数据清理
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"

    #自定义服务-服务列表-列表的显示
    def test_domain_PaginationDisplay(self):
        # 创建服务
        domainlists = []
        try:
            for i in range(10):
                domainname = "domaintestone" + str(random.randint(10000, 99999))+str(random.randint(10000, 99999))
                domainlists.append(domainname)
                result = self.create_domain(domainname)
                if result:
                    print(domainname)
                    continue
                else:
                    print("创建服务失败！")
                    assert False
            result = self.get_domain_ItemcountPagecountIdCount()
            print("-----",result[0],result[1],result[2])
            if ((result[0] >= 10) and (result[1] >= 1) and (result[2] == 10)):
                assert True
            else:
                print("自定义服务分页显示异常！")
                assert False
        finally:
            #数据清理
            for i in range(10):
                clearinfo = self.delete_domain_by_domain_name(domainlists[i])
                assert clearinfo, "数据清理失败！"

    #自定义服务-服务列表-新建（非Admin账号登录）
    def test_domain_create(self):
        domainname = "autotestdomain"+str(random.randint(10000, 99999)) + str(random.randint(10000, 99999))
        try:
            result = self.create_domain(domainname)
            if result:
                assert True
            else:
                print("创建服务失败！")
                assert False
        finally:
            #数据清理
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"

    #自定义服务-服务列表-新建（Admin账号登录）
    def test_domain_admincreate(self):
        domainname = "autotestdomain"+str(random.randint(10000, 99999)) + str(random.randint(10000, 99999))
        try:
            result = self.admin_create_domain(domainname,domainname)
            if result:
                assert True
            else:
                print("创建服务失败！")
                assert False
        finally:
            #数据清理
            domainid = self.admin_get_domain_id_by_domain_name(domainname)
            clearinfo = self.admin_delete_domain_by_domain_id(domainid)
            assert clearinfo, "数据清理失败！"

    # 自定义服务-意图列表-语料-自然语料模式的使用
    def test_domain_NaturalCorpus(self):
        # 创建服务
        domainname = "domaintestone" + str(random.randint(10000, 99999))
        intentsname = "intentstestone" + str(random.randint(10000, 99999))
        try:
            result = self.create_domain(domainname)
            if result:
                # 创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                result = self.create_domain_NaturalCorpus(domain_id, intentsname)
                time.sleep(5)
                # 创建意图后，编辑提交一次，否则经常出现命中不了的问题
                result_save1 = self.domain_IntentsComplex_put_NaturalCorpus(domain_id, intentsname)
                time.sleep(5)
                result_save2 = self.domain_IntentsComplex_put_NaturalCorpus(domain_id, intentsname)
                time.sleep(5)
                result_save3 = self.domain_IntentsComplex_put_NaturalCorpus(domain_id, intentsname)
                time.sleep(5)
                if result:
                    result = self.enable_domain_by_DomainId(domain_id)
                    time.sleep(60)
                    if result:
                        reponse = self.question_test("你叔叔{}会骑自行车吗".format(intentsname))
                        result1 = self.domain_qa_answer_verification_source(reponse, 'user_service')
                        result2 = self.domain_qa_answer_verification_operation_tts_text(reponse, "NaturalCorpus")
                        if result1 and result2:
                            print("问答测试通过")
                            assert True
                        else:
                            assert False
                    else:
                        print("服务开启失败！")
                        assert False
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            # 数据清理
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"
            # pass




    #自定义服务-意图列表-语料-复杂模板模式的使用
    def test_domain_ComplexCorpus(self):
        # 创建服务 + str(random.randint(10000, 99999))
        domainname = "domaintestone"+ str(random.randint(10000, 99999))
        intentsname = "intentstestone"+ str(random.randint(10000, 99999))
        print("----------",intentsname)
        try:
            result = self.create_domain(domainname)
            if result:
                # 创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                result = self.create_domain_IntentsComplex(domain_id,intentsname)
                time.sleep(5)
                #创建意图后，编辑提交一次，否则经常出现命中不了的问题
                # result_save = self.domain_IntentsComplex_put(domain_id,intentsname)
                # time.sleep(5)
                if result:
                    result = self.enable_domain_by_DomainId(domain_id)
                    time.sleep(60)
                    if result:
                        reponse = self.question_test("我要订一张哪吒{}的电影票".format(intentsname))
                        # reponse1 = self.domain_SV_QUESTION("我要订一张哪吒{}的电影票".format(intentsname))
                        # reponse = self.domain_SV_QUESTION("我要订一张哪吒{}的电影票".format(intentsname),intentsname)
                        # reponse = self.send_qa("我要订一张哪吒{}的电影票".format(intentsname))
                        # reponse = self.send_qa("我要订一张哪吒intentstestone54755的电影票")
                        result1 = self.domain_qa_answer_verification_source(reponse,'user_service')
                        result2 = self.domain_qa_answer_verification_operation_tts_text(reponse,'致命罗密欧的电影票不够了')
                        # result3 = self.domain_qa_answer_verification_operation_computer(reponse, "1099")
                        result4 = self.domain_qa_answer_verification_operation_intents(reponse, intentsname)
                        print("---",result1,result2,result4)
                        if result1 and result2 and result4:
                            print("问答测试通过")
                            assert True
                        else:
                            assert False
                    else:
                        print("服务开启失败！")
                        assert False
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            #数据清理
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"
            # pass

    #自定义服务-意图列表-语料规则测试-中括号的使用
    def test_domain_ComplexCorpus_UseOfBrackets(self):
        # 创建服务
        domainname = "domaintestone" + str(random.randint(10000, 99999))
        intentsname = "intentstestone" + str(random.randint(10000, 99999))
        try:
            result = self.create_domain(domainname)
            if result:
                # 创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                result = self.create_domain_IntentsComplex_UseOfBrackets(domain_id,intentsname)
                time.sleep(5)
                # result1 = self.edit_domain_IntentsComplex_UseOfBrackets(domain_id,intentsname)
                # time.sleep(5)
                # result2 = self.edit_domain_IntentsComplex_UseOfBrackets(domain_id, intentsname)
                # time.sleep(5)
                # result3 = self.edit_domain_IntentsComplex_UseOfBrackets(domain_id, intentsname)
                # time.sleep(5)
                # result3 = self.edit_domain_IntentsComplex_UseOfBrackets(domain_id, intentsname)
                # time.sleep(5)
                if result:
                    result = self.enable_domain_by_DomainId(domain_id)
                    time.sleep(60)
                    if result:
                        reponse = self.question_test("她要订一张电影票")
                        result1 = self.domain_qa_answer_verification_source_notexpected(reponse,'user_service')
                        reponse = self.question_test("她要订一张我是谁的电影票")
                        result2 = self.domain_qa_answer_verification_source_notexpected(reponse, 'user_service')
                        reponse = self.question_test("她{}要订一张卧虎藏龙的电影票".format(intentsname))
                        result3 = self.domain_qa_answer_verification_source(reponse, 'user_service')
                        result4 = self.domain_qa_answer_verification_operation_tts_text(reponse, "卧虎藏龙的电影票不够了")
                        print("result:",result1,result2,result3,result4)
                        if result1 and result2 and result3 and result4:
                            print("问答测试通过")
                            assert True
                        else:
                            assert False
                    else:
                        print("服务开启失败！")
                        assert False
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            #数据清理
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"
            # pass



    #自定义服务-意图列表-语料规则测试-|的使用
    def test_domain_ComplexCorpus_UseOfVerticalLines(self):
        # 创建服务
        domainname = "domaintestone" + str(random.randint(10000, 99999))
        intentsname = "intentstestone" + str(random.randint(10000, 99999))
        try:
            result = self.create_domain(domainname)
            if result:
                # 创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                result = self.create_domain_IntentsComplex_UseOfVerticalLines(domain_id,intentsname)
                time.sleep(5)
                # 创建意图后，编辑提交一次，否则经常出现命中不了的问题
                result_save1 = self.domain_IntentsComplex_put_UseOfVerticalLines(domain_id, intentsname)
                # time.sleep(5)
                result_save2 = self.domain_IntentsComplex_put_UseOfVerticalLines(domain_id, intentsname)
                # time.sleep(60)
                if result:
                    result = self.enable_domain_by_DomainId(domain_id)
                    time.sleep(60)
                    if result:
                        reponse = self.question_test("今天很不错")
                        result1 = self.domain_qa_answer_verification_source_notexpected(reponse,'user_service')
                        reponse = self.question_test("大纲{}很不错".format(intentsname))
                        result2 = self.domain_qa_answer_verification_source(reponse, 'user_service')
                        result3 = self.domain_qa_answer_verification_operation_tts_text(reponse, "UseOfVerticalLines")
                        reponse = self.question_test("今天大纲{}很不错".format(intentsname))
                        result4 = self.domain_qa_answer_verification_source(reponse, 'user_service')
                        result5 = self.domain_qa_answer_verification_operation_tts_text(reponse, "UseOfVerticalLines")
                        reponse = self.question_test("明天大纲{}很不错".format(intentsname))
                        result6 = self.domain_qa_answer_verification_source(reponse, 'user_service')
                        result7 = self.domain_qa_answer_verification_operation_tts_text(reponse, "UseOfVerticalLines")
                        if result1 and result2 and result3 and result4 and result5 and result6 and result7:
                            print("问答测试通过")
                            assert True
                        else:
                            assert False
                    else:
                        print("服务开启失败！")
                        assert False
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            #数据清理
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"
            # pass


    #自定义服务-意图列表-语料规则测试-调用系统命名体变量
    def test_domain_ComplexCorpus_CallSystemVariableName(self):
        # 创建服务
        domainname = "domaintestone" + str(random.randint(10000, 99999))
        intentsname = "intentstestone" + str(random.randint(10000, 99999))
        try:
            result = self.create_domain(domainname)
            if result:
                # 创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                result = self.create_domain_IntentsComplex_CallSystemVariableName(domain_id,intentsname)
                time.sleep(5)
                # 创建意图后，编辑提交一次，否则经常出现命中不了的问题
                result_save1 = self.domain_IntentsComplex_put_CallSystemVariableName(domain_id, intentsname)
                # time.sleep(5)
                # result_save2 = self.domain_IntentsComplex_put_CallSystemVariableName(domain_id, intentsname)
                # time.sleep(5)
                if result:
                    result = self.enable_domain_by_DomainId(domain_id)
                    time.sleep(60)
                    if result:
                        reponse = self.question_test("小邓{}准备武汉出国旅游呢".format(intentsname))
                        result1 = self.domain_qa_answer_verification_source(reponse, 'user_service')
                        result2 = self.domain_qa_answer_verification_operation_tts_text(reponse, "嗯呐嗯呐，好好玩吧!")
                        if result1 and result2:
                            print("问答测试通过！")
                            assert True
                        else:
                            print("问答测试失败！")
                            assert False
                    else:
                        print("服务开启失败！")
                        assert False
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            #数据清理
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"
            # pass



    # 自定义服务-意图列表-语料规则测试-调用系统命名体变量
    def test_domain_ComplexCorpus_CallSystemVariableName_NUMTWO(self):
        # 创建服务
        domainname = "domaintestone" + str(random.randint(10000, 99999))
        intentsname = "intentstestone" + str(random.randint(10000, 99999))
        try:
            result = self.create_domain(domainname)
            if result:
                # 创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                result = self.create_domain_IntentsComplex_CallSystemVariableName_NUMTWO(domain_id,intentsname)
                if result:
                    result = self.enable_domain_by_DomainId(domain_id)
                    time.sleep(80)
                    if result:
                        reponse = self.question_test("1加1等于几")
                        result1 = self.domain_qa_answer_verification_source(reponse, 'user_service')
                        #result2 = self.domain_qa_answer_verification_operation_name(reponse, intentsname)
                        result3 = self.domain_qa_answer_verification_operation_computer(reponse, "2")
                        #if result1 and result2 and result3:
                        if result1 and result3:
                            print("问答测试通过")
                            assert True
                        else:
                            assert False
                    else:
                        print("服务开启失败！")
                        assert False
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            # 数据清理
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"
            # pass

    #自定义服务-意图列表-语料规则测试-调用用户自定义命名体变量
    def test_domain_ComplexCorpus_CustomEntityVariableName(self):
        # 创建服务
        domainname = "domaintestone" + str(random.randint(10000, 99999))
        intentsname = "intentstestone" + str(random.randint(10000, 99999))
        #自定义实体
        entityname = "day"+ str(random.randint(10000, 99999))
        result = self.create_entity(entityname)
        if result:
            entityid = self.get_entity_id_by_entity_name(entityname)
            #创建实体的实例
            entityitem1 = self.create_entityItems(entityid, "大饼")
            entityitem2 = self.create_entityItems(entityid, "大葱")
            entityitem3 = self.create_entityItems(entityid, "大壮")
            if entityitem1 and entityitem2 and entityitem3:
                print("创建实例成功！")
                pass
            else:
                print("创建自定义实体的实例失败！")
                assert False
        else:
            print("创建自定义实体失败！")
            assert False
        try:
            result = self.create_domain(domainname)
            if result:
                # 创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                result = self.create_domain_IntentsComplex_CustomEntityVariableName(domain_id, intentsname,entityname,entityid)
                time.sleep(3)
                # time.sleep(5)
                # 创建意图后，编辑提交一次，否则经常出现命中不了的问题
                result_save1 = self.domain_IntentsComplex_put_CustomEntityVariableName(domain_id, intentsname)
                # time.sleep(5)
                result_save2 = self.domain_IntentsComplex_put_CustomEntityVariableName(domain_id, intentsname)
                # time.sleep(5)
                result_save3 = self.domain_IntentsComplex_put_CustomEntityVariableName(domain_id, intentsname)
                # time.sleep(15)
                # print(result)
                if result:
                    result = self.enable_domain_by_DomainId(domain_id)
                    time.sleep(60)
                    if result:
                        reponse = self.question_test("大饼好{}".format(intentsname))
                        result1 = self.domain_qa_answer_verification_source(reponse, 'user_service')
                        result2 = self.domain_qa_answer_verification_operation_name(reponse, intentsname)
                        result3 = self.domain_qa_answer_verification_operation_tts_text(reponse, "CustomEntityVariableName")
                        reponse = self.question_test("大葱好{}".format(intentsname))
                        result4 = self.domain_qa_answer_verification_source(reponse, 'user_service')
                        result5 = self.domain_qa_answer_verification_operation_name(reponse, intentsname)
                        result6 = self.domain_qa_answer_verification_operation_tts_text(reponse,
                                                                                        "CustomEntityVariableName")
                        reponse = self.question_test("大壮好{}".format(intentsname))
                        result7 = self.domain_qa_answer_verification_source(reponse, 'user_service')
                        result8 = self.domain_qa_answer_verification_operation_name(reponse, intentsname)
                        result9 = self.domain_qa_answer_verification_operation_tts_text(reponse,
                                                                                        "CustomEntityVariableName")
                        if result1 and result2 and result3 and result4 and result5 and result6 and result7 and result8 and result9:
                            print("自定义实体问答测试通过")
                            assert True
                        else:
                            print("自定义实体问答测试失败")
                            assert False
                    else:
                        print("服务开启失败！")
                        assert False
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            #pass
            #数据清理---必须保证数据清理成功，否则之后测试，创建实例失败，因为系统要求不能实例重复
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"
            deleteinfo = self.delete_entity_by_entity_id(entityid)
            assert deleteinfo, "数据清理失败！"
            # pass


    #自定义服务-意图列表-语料-简单模板模式的使用
    def test_domain_SimpleTemplate(self):
        # 创建服务
        domainname = "domaintestone" + str(random.randint(10000, 99999))
        intentsname = "intentstestone" + str(random.randint(10000, 99999))
        #自定义实体
        entityname = "day"+ str(random.randint(10000, 99999))
        result = self.create_entity(entityname)
        if result:
            entityid = self.get_entity_id_by_entity_name(entityname)
            #创建实体的实例
            entityitem1 = self.create_entityItems(entityid, "冰花")
            if entityitem1 :
                print("创建实例成功！")
                pass
            else:
                print("创建自定义实体的实例失败！")
                assert False
        else:
            print("创建自定义实体失败！")
            assert False
        try:
            result = self.create_domain(domainname)
            if result:
                # 创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                result = self.create_domain_SimpleTemplate(domain_id, intentsname,entityname,entityid)
                time.sleep(5)
                # 创建意图后，编辑提交一次，否则经常出现命中不了的问题
                result_save1 = self.domain_IntentsComplex_put_SimpleTemplate(domain_id, intentsname)
                time.sleep(5)
                result_save2 = self.domain_IntentsComplex_put_SimpleTemplate(domain_id, intentsname)
                time.sleep(5)
                print(result)
                if result:
                    result = self.enable_domain_by_DomainId(domain_id)
                    time.sleep(60)
                    if result:
                        reponse = self.question_test("冰花{}好".format(intentsname))
                        result1 = self.domain_qa_answer_verification_source(reponse, 'user_service')
                        result2 = self.domain_qa_answer_verification_operation_tts_text(reponse, "SimpleTemplate")
                        result3 = self.domain_qa_answer_verification_operation_name(reponse, intentsname)
                        if result1 and result2 and result3 :
                            print("自定义实体问答测试通过")
                            assert True
                        else:
                            print("自定义实体问答测试失败")
                            assert False
                    else:
                        print("服务开启失败！")
                        assert False
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            # pass
            #数据清理---必须保证数据清理成功，否则之后测试，创建实例失败，因为系统要求不能实例重复
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"
            deleteinfo = self.delete_entity_by_entity_id(entityid)
            assert deleteinfo, "数据清理失败！"
            # pass

    #自定义服务-意图列表-语料-动作和参数-多条参数和实体名称一致的记录显示
    def test_domain_ComplexCorpus_DoubleCorps(self):
        # 创建服务
        domainname = "domaintestone" + str(random.randint(10000, 99999))
        intentsname = "intentstestone" + str(random.randint(10000, 99999))
        try:
            result = self.create_domain(domainname)
            if result:
                # 创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                result = self.create_domain_IntentsComplex_DoubleCorps(domain_id,intentsname)
                if result:
                    result = self.enable_domain_by_DomainId(domain_id)
                    time.sleep(60)
                    if result:
                        reponse = self.question_test("小兴算算15加5等于几")
                        result1 = self.domain_qa_answer_verification_source(reponse,'user_service')
                        result2 = self.domain_qa_answer_verification_operation_computer(reponse, "20")
                        # result3 = self.domain_qa_answer_verification_operation_name(reponse, intentsname)
                        if result1 and result2:
                            print("问答测试通过")
                            assert True
                        else:
                            assert False
                    else:
                        print("服务开启失败！")
                        assert False
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            #数据清理
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"
            # pass



    #自定义服务-意图列表-语料-动作和参数-添加追问
    def test_domain_ComplexCorpus_QuestioningInformation(self):
        # 创建服务
        domainname = "domaintestone" + str(random.randint(10000, 99999))
        intentsname = "intentstestone" + str(random.randint(10000, 99999))
        try:
            result = self.create_domain(domainname)
            if result:
                # 创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                result = self.create_domain_IntentsComplex_QuestioningInformation(domain_id,intentsname)
                time.sleep(5)
                # 创建意图后，编辑提交一次，否则经常出现命中不了的问题
                result_save1 = self.domain_IntentsComplex_put_QuestioningInformation(domain_id, intentsname)
                # time.sleep(5)
                # result_save2 = self.domain_IntentsComplex_put_QuestioningInformation(domain_id, intentsname)
                # time.sleep(15)
                if result:
                    result = self.enable_domain_by_DomainId(domain_id)
                    time.sleep(65)
                    if result:
                        reponse = self.question_test("点点{}告诉我怎么样".format(intentsname))
                        result1 = self.domain_qa_answer_verification_source(reponse,'user_service')
                        result2 = self.domain_qa_answer_verification_operation_tts_text(reponse, "请问是什么呀")
                        if result1 and result2:
                            print("问答测试通过")
                            assert True
                        else:
                            print("自定义服务问答追问测试失败！")
                            assert False
                    else:
                        print("服务开启失败！")
                        assert False
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            #数据清理
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"
            # pass




    # 自定义服务-意图列表-语料-动作和参数-参数的编辑操作
    def test_domain_ComplexCorpus_EditInfo(self):
        # 创建服务
        domainname = "domaintestone" + str(random.randint(10000, 99999))
        intentsname = "intentstestone" + str(random.randint(10000, 99999))
        try:
            result = self.create_domain(domainname)
            if result:
                # 创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                result = self.create_domain_IntentsComplex_EDIT(domain_id, intentsname)
                if result:
                    result = self.enable_domain_by_DomainId(domain_id)
                    time.sleep(60)
                    if result:
                        reponse = self.question_test("算算5加5等于几")
                        result1 = self.domain_qa_answer_verification_source(reponse, 'user_service')
                        result2 = self.domain_qa_answer_verification_operation_computer(reponse, "10")
                        if result1 and result2:
                            print("问答测试通过")
                            assert True
                        else:
                            assert False
                    else:
                        print("服务开启失败！")
                        assert False
                    #编辑意图
                    result = self.create_domain_IntentsComplex_EditInfo(domain_id,intentsname)
                    if result:
                        reponse = self.question_test("算算5加5等于几")
                        result1 = self.domain_qa_answer_verification_source(reponse, 'user_service')
                        result2 = self.domain_qa_answer_verification_operation_computer(reponse, "10")
                        if result1 and result2:
                            print("问答测试通过")
                            assert True
                        else:
                            assert False
                    else:
                        print("服务开启失败！")
                        assert False
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            # 数据清理
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"
            # pass



    # 自定义服务-意图列表-上下文
    def test_domain_ComplexCorpus_Context(self):
        # 创建服务
        domainname = "domaintestone" + str(random.randint(10000, 99999))
        intentsname1 = "intentstestone" + str(random.randint(10000, 99999))
        intentsname2 = "intentstestone" + str(random.randint(10000, 99999))
        try:
            result = self.create_domain(domainname)
            if result:
                # 创建服务下的意图
                domain_id = self.get_domain_id_by_domain_name(domainname)
                result1 = self.create_domain_IntentsComplex_Context1(domain_id, intentsname1)
                result2 = self.create_domain_IntentsComplex_Context2(domain_id, intentsname2)
                # 创建意图后，编辑提交一次，否则经常出现命中不了的问题
                # result_save1 = self.domain_IntentsComplex_put_Context1(domain_id, intentsname1)
                # time.sleep(10)
                # # 创建意图后，编辑提交一次，否则经常出现命中不了的问题
                # result_save2 = self.domain_IntentsComplex_put_Context2(domain_id, intentsname2)
                # time.sleep(10)
                # result_save3 = self.domain_IntentsComplex_put_Context1(domain_id, intentsname1)
                # time.sleep(10)
                # # 创建意图后，编辑提交一次，否则经常出现命中不了的问题
                # result_save4 = self.domain_IntentsComplex_put_Context2(domain_id, intentsname2)
                # time.sleep(10)
                if result1 and result2:
                    result = self.enable_domain_by_DomainId(domain_id)
                    time.sleep(80)
                    if result:
                        #意图上下文测试
                        reponse = self.question_test("泰坦尼克号呢")
                        # result1 = self.domain_qa_answer_verification_source(reponse, 'user_default_qa')
                        result1 = self.domain_qa_answer_verification_source_notexpected(reponse, 'user_service')
                        reponse = self.question_test("我要订一张哪吒{}的电影票".format(intentsname1))
                        result2 = self.domain_qa_answer_verification_source(reponse, 'user_service')
                        result3 = self.domain_qa_answer_verification_operation_tts_text(reponse,"卧虎藏龙的电影票不够了")
                        result4 = self.domain_qa_answer_verification_operation_tree_currentstate(reponse,"OrderTicket")
                        # result5 = self.domain_qa_answer_verification_operation_tree_template(reponse,"OrderTicket")
                        reponse2 = self.question_test("泰坦尼克号呢")
                        result6 = self.domain_qa_answer_verification_source(reponse2, 'user_service')
                        result7 = self.domain_qa_answer_verification_operation_tts_text(reponse2,
                                                                                        "泰坦尼克号的电影票很充足")
                        result5 = self.domain_qa_answer_verification_operation_tree_template(reponse2, "OrderTicket")
                        print("result------------:",result1,result2,result3,result4,result5,result6,result7)
                        if result1 and result2 and result3 and result4  and result5 and result6 and result7:
                            print("自定义服务上下文问答测试通过")
                            assert True
                        else:
                            assert False
                    else:
                        print("服务开启失败！")
                        assert False
                else:
                    print("创建意图失败！")
                    assert False
            else:
                print("创建服务失败！")
                assert False
        finally:
            # 数据清理
            clearinfo = self.delete_domain_by_domain_name(domainname)
            assert clearinfo, "数据清理失败！"
            # pass






    #操作手册下载
    def test_login_setting_OperationManualDownload(self):
        # 模板下载
        smartvoicename = "SmartVoice-Manual-zh-CN"+ str(random.randint(10000, 99999))+".pptx"
        try:
            result = self.download_file(smartvoicename)
            if result:
                filepath = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                                        'testdata/{}'.format(smartvoicename))
                fileexit = os.path.exists(filepath)
                if fileexit:
                    print("操作手册下载测试通过！")
                    assert True
                else:
                    print("操作手册下载测试失败！")
                    assert False
            else:
                print("操作手册下载测试失败！")
                assert False
        finally:
            # 数据清理，删除下载的文件
            filepath = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                                    'testdata/{}'.format(smartvoicename))
            fileexit = os.path.exists(filepath)
            if fileexit:
                print("操作手册清理成功！！")
                os.remove(filepath)
                assert True
            else:
                print("操作手册清理失败！！")
                assert False

