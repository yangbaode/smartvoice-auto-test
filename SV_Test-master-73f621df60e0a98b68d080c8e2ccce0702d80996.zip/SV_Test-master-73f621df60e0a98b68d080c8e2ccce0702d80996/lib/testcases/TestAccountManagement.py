#!/usr/bin/env python
# coding=utf-8

from lib.modules.AccountManagement import AccountManagement
from lib.utils import constant
import logging as logger
import os
import json
import random
import string

class TestAccountManagement(AccountManagement):
    ROBOT_LIBRARY_SCOPE = 'TEST SUITE'
    ROBOT_LIBRARY_VERSION = "0.1"

    def __init__(self):
        AccountManagement.__init__(self, constant.SV_USER, constant.SV_PWD)

    def _setup_account(self, username="automation@cloudminds.com"):
        account = {"groupids": [],
                   "user": {"mail": "automation@cloudminds.com", "password": "Pepper1113", "realname": "automation",
                            "telephone": "13488821231", "username": username}}
        user_list = self.get_user_list(keyword=username)
        if not user_list:
            self.new_account(account)
        elif username not in [user['user']['username'] for user in user_list]:
            self.new_account(account)
        user_list = self.get_user_list(keyword=username)
        assert username in [user['user']['username'] for user in user_list]

    def test_create_account(self):
        """
        CV-9509 	账号管理-子账号管理-新建子账号界面
        CV-9510 	账号管理-子账号管理-新建子账号
        CV-9512 	账号管理-子账号管理-新建子账号(合乎规则的密码)
        :return: 
        """
        account = {"groupids": [],
                "user": {"mail": "automation@cloudminds.com", "password": "Pepper1113", "realname": "automation", "telephone": "13488821231",
                         "username": "automation@cloudminds.com"}}
        user_list = self.get_user_list(keyword='automation@cloudminds.com')
        if user_list:
            if 'automation@cloudminds.com' in [user['user']['username'] for user in user_list]:
                delete_result = self.delete_user('automation@cloudminds.com')
                print('delete code', delete_result)

        self.new_account(account)
        user_list = self.get_user_list(keyword='automation@cloudminds.com')
        if user_list:
            assert 'automation@cloudminds.com' in [user['user']['username'] for user in user_list]
        assert user_list, '没有找到创建的{}'.format("automation@cloudminds.com")

    def test_delete_account(self):
        """
        CV-9522 账号管理-子账号管理-删除
        :return: 
        """
        self._setup_account()
        delete_result = self.delete_user('automation@cloudminds.com')
        assert delete_result == 204, '删除失败'
        user_list = self.get_user_list(keyword='automation@cloudminds.com')
        assert not user_list, '删除后仍然能够找到{}'.format("automation@cloudminds.com")

    def test_account_search(self):
        """
        CV-9507 	账号管理-显示子模块
        CV-9508 	账号管理-子账号管理
        CV-9529 
        :return: 
        """
        #setup account
        for i in range(20):
            username = "autotest_{}@cloudminds.com".format(i)
            self._setup_account(username)
        user_list = self.get_user_list()
        assert len(user_list) == 10, '当期账户默认搜索不足10个,请查看实际情况'

        user_list = self.get_user_list(keyword='123243243243')
        assert not user_list, '应该为空'

        user_list = self.get_user_list(keyword='autotest_')
        assert user_list, '应该不为空'

        user_list = self.get_user_list(keyword='autotest_', pagesize=10, page=1)
        assert len(user_list)==10, 'page list length is not 10'

        user_list = self.get_user_list(keyword='autotest_', pagesize=10, page=2)
        assert len(user_list) == 10, 'page list length is not 10'

        user_list = self.get_user_list(keyword='autotest_', pagesize=10000, page=1)
        assert len(user_list) == 20, 'page list length is not 20'

        #clear
        for i in range(20):
            username = "autotest_{}@cloudminds.com".format(i)
            self.delete_user(username)

    def test_account_disable(self):
        """
        CV-9520 	账号管理-子账号管理-停用
        :return: 
        """
        self._setup_account()
        user = self.get_user_by_name('automation@cloudminds.com')
        assert user, 'no user available'
        user_status = user['user']['active']
        if user_status == 1:
            self.set_user_status('automation@cloudminds.com', 0)
            assert self.get_user_by_name('automation@cloudminds.com')['user']['active'] == 0
        else:
            self.set_user_status('automation@cloudminds.com', 1)
            assert self.get_user_by_name('automation@cloudminds.com')['user']['active'] == 1
            self.set_user_status('automation@cloudminds.com', 0)
            assert self.get_user_by_name('automation@cloudminds.com')['user']['active'] == 0
        self.set_user_status('automation@cloudminds.com', 1)
        assert self.get_user_by_name('automation@cloudminds.com')['user']['active'] == 1

    def test_account_enable(self):
        """
        CV-9521 	账号管理-子账号管理-启用
        :return: 
        """
        self._setup_account()
        user = self.get_user_by_name('automation@cloudminds.com')
        assert user, 'no user available'
        user_status = user['user']['active']
        if user_status == 1:
            self.set_user_status('automation@cloudminds.com', 0)
            assert self.get_user_by_name('automation@cloudminds.com')['user']['active'] == 0
        self.set_user_status('automation@cloudminds.com', 1)
        assert self.get_user_by_name('automation@cloudminds.com')['user']['active'] == 1

    def test_account_edit(self):
        """
        CV-9517 账号管理-子账号管理-编辑（合乎规则的密码，姓名，邮箱）
        CV-9515 账号管理-子账号管理-编辑
        """
        self._setup_account()
        status_code = self.edit_user('automation@cloudminds.com', {})
        assert status_code == 204, '什么都不改默认修改未成功'
        telephone = '139{}'.format(random.randint(10000000, 92345678))
        content = {'telephone': telephone}
        status_code = self.edit_user('automation@cloudminds.com', content)
        assert status_code == 204, '修改电话号码'
        user = self.get_user_by_name('automation@cloudminds.com')
        print(user['user']['telephone'])
        assert user['user']['telephone'] == telephone, '修改电话失败'

        realname = ''.join(random.sample(string.ascii_letters + string.digits, 30))
        content = {'realname': realname}
        status_code = self.edit_user('automation@cloudminds.com', content)
        assert status_code == 204, '修改realname失败'
        user = self.get_user_by_name('automation@cloudminds.com')
        print(user['user']['realname'])
        assert user['user']['realname'] == realname, '修改realname失败'

    def test_new_group(self):
        """
        CV-9532 	账号管理-组管理-新建组
        CV-9533 	账号管理-组管理-新建组（内容符合规则）
        :return: 
        """
        group = self.get_group_by_name('automation_group')
        if group:
            self.delete_group('automation_group')
        self._setup_group()
        assert self.get_group_by_name('automation_group'), 'Create Group failed'

    def _setup_group(self, name='automation_group'):
        group = {'name': name, 'info': 'this is automation group'}
        authority = {"chitchat": False, "customdomain": True, "domainmanage": True, "faq": False, "faqmanage": True,
                     "qamark": True, "qatype": True, "train": True}
        # self.new_group(group=group, agent='automation', authority=authority)
        # self.new_group(group=group, agent='automation', authority=authority) #baldwinEdit  原始代码数据未分离，提取agent
        self.new_group(group=group, agent=constant.account_management_agent, authority=authority)
    def test_delete_group(self):
        """
        CV-9538 	账号管理-组管理-删除
        CV-9539 	账号管理-组管理-删除（点击删除按钮）
        :return: 
        """
        group = self.get_group_by_name('automation_group')
        if not group:
            self._setup_group()
        assert self.delete_group('automation_group') == 204, 'Delete group failed'

    def test_list_and_search_group(self):
        """
        CV-9531 	账号管理-组管理-搜索
        CV-9530 	账号管理-组管理
        :return: 
        """
        #create 10
        for i in range(20):
            name = 'automation_g{}'.format(i)
            self._setup_group(name)

        #default:
        assert len(self.get_group_list(keyword='', page=1, pagesize=10))==10, 'List group not in 10'
        #
        assert len(self.get_group_list(keyword='', page=2, pagesize=10)) == 10, 'List group not in 10'
        assert len(self.get_group_list(keyword='', page=1, pagesize=20)) == 20, 'List group not in 10'
        assert len(self.get_group_list(keyword='automation_g', page=1, pagesize=10)) == 10, 'search error'

        # del 10 group
        for i in range(20):
            name = 'automation_g{}'.format(i)
            self.delete_group(name)

    def test_edit_group(self):
        """
        CV-9537 	账号管理-组管理-编辑
        CV-9536 	账号管理-组管理-编辑界面
        :return: 
        """
        group = self.get_group_by_name('automation_group')
        if group:
            self.delete_group('automation_group')
        self._setup_group('automation_group')
        group_info = ''.join(random.sample(string.ascii_letters, 50))
        print(group_info)
        agent = self.get_agentId_by_name('pepper')
        authority = {'chitchat': False,
                    'customdomain': False,
                    'domainmanage': False,
                    'faq': False,
                    'faqmanage': False,
                    'qamark': False,
                    'qatype': False,
                    'train': False}
        assert self.edit_group('automation_group', group_info=group_info, agent_id=agent,
                               authority=authority) == 204, 'Modified request failed'

        group = self.get_group_by_name('automation_group')
        assert group['agent']['id'] == agent, 'agent modified failed'
        assert group['group']['info'] == group_info, 'group info modified failed'

        for key in group['authority']:
            assert authority[key] == group['authority'][key], 'authority {} modified failed'.format(key)

if __name__ == "__main__":
    t = TestAccountManagement()
    t.test_account_search()

