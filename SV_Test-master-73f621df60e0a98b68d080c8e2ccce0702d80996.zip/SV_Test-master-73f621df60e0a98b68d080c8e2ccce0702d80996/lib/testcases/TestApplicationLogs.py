#!/usr/bin/env python
# coding=utf-8
from lib.modules.Application import Application
from lib.modules.Base import Base
from lib.uilocators import uilocators
from lib.utils import constant
import logging as logger
import os
import time
import datetime

class TestApplicationLogs(Application):

    def test_applicaiton_log_modules_list(self):
        #CV-9464
        self.open_application_default()
        self.open_item_in_intent(1)
        self.open_item_in_intent(2)
        self.open_item_in_intent(3)
        self.open_item_in_faq(1)
        self.open_item_in_faq(2)
        self.open_item_in_faq(3)
        self.open_item_in_faq(4)

    def test_open_application_logs(self):
        self.open_application_default()
        self.open_application_navi(constant.dont_modify_agent_name)
        assert self.wait_element_visible(uilocators.application_logs_content)

    def test_application_check_logs_export(self):
        self.test_application_logs_export()
        self.selib.click_element(uilocators.app_logs_export_btn_confirm)
        time.sleep(2)
        self.wait_element_disapear("//button[contains(@class,'ant-btn-loading')]", 60)
        time.sleep(3)
        excel_file = os.path.join(self.download_path, '导出记录.xls')
        ret = self.check_item_in_excel('system_service', excel_file)
        if ret:
            os.remove(excel_file)
        assert ret, '检查excel内容出错'

    def test_application_logs_export(self):
        self.open_application_default()
        self.open_application_navi(constant.dont_modify_agent_name)
        assert self.wait_element_visible(uilocators.application_logs_content)
        self.click_by_js(uilocators.app_logs_export_btn)
        ret = self.wait_element_present(uilocators.app_logs_export_btn_confirm,5)
        assert ret

    def test_application_log_search(self, hit_type='all', delta_days=0):
        #hit_type 应该为 all, hit_qa, hit_param, hit_command
        #目前无case选特定的日期,为默认参数
        #前提:需要打开logs才能做
        #self.open_application_default()
        #self.open_application_navi('automation')
        assert self.wait_element_visible(uilocators.application_logs_content)

        if hit_type == 'all':
            print('all')
            self.click_by_js(uilocators.app_logs_hit_type)
            time.sleep(0.3)
            self.click_by_js(uilocators.app_logs_hit_menu_items + "[1]")
        elif hit_type == 'hit_qa':
            self.click_by_js(uilocators.app_logs_hit_type)
            time.sleep(0.3)
            self.click_by_js(uilocators.app_logs_hit_menu_items + "[2]")
        elif hit_type == 'hit_param':
            self.click_by_js(uilocators.app_logs_hit_type)
            time.sleep(0.3)
            self.click_by_js(uilocators.app_logs_hit_menu_items + "[3]")
        elif hit_type == 'hit_command':
            self.click_by_js(uilocators.app_logs_hit_type)
            time.sleep(0.3)
            self.click_by_js(uilocators.app_logs_hit_menu_items + "[4]")
        else:
            assert False, "hit_type 应该为 all, hit_qa, hit_param, hit_command"

        #start time
        if delta_days != 0:
            now = datetime.datetime.now()
            delta = datetime.timedelta(days=abs(delta_days))
            want_date = now
            if delta_days < 0:
                want_date = now - delta
            else:
                want_date = now + delta
            self.click_locator(uilocators.app_logs_start_datepicker)
            #有个bug,先点一号,再键入日期
            # self.click_by_js("//td[contains(@title, '-01')]/div[@class='ant-calendar-date']")
            self.selib.input_text(uilocators.app_logs_datepicker_input, want_date.strftime("%Y-%m-%d %H:%M:%S"))
            self.click_by_js(uilocators.app_logs_datepicker_ok_btn)
            time.sleep(1)
            self.click_locator(uilocators.app_logs_end_datepicker)
            self.click_by_js(uilocators.app_logs_datepicker_today)
            time.sleep(0.5)

        self.click_by_js(uilocators.app_logs_search)
        assert self.wait_element_visible(uilocators.application_logs_content), "无内容,请检查"



