#!/usr/bin/env python
# coding=utf-8

from lib.modules.Application import Application
from lib.modules.Base import Base
from lib.uilocators import uilocators
from lib.utils import constant
import logging as logger
import os
import time

class TestApplicationTag(Application):
    def test_open_application_tag(self):
        self.open_application_tag()
    def select_application_tag(self):
        # self.selib.click_element(uilocators.nav_applicaiton_tab_intent)
        self.selib.click_element(uilocators.nav_applicaiton_tab_faq)
        self.selib.click_element(uilocators.app_qa_tag)
    def open_app_tag(self):
        self.selib.click_element(uilocators.new_app_tag)
    def new_app_tag(self,tagname):
        self.open_app_tag()
        self.selib.input_text(uilocators.tag_name_input, tagname)
        self.selib.click_element(uilocators.new_tag_save_btn)
        text = self.selib.get_text(uilocators.msg_message_text)
        if (text == 'tag name has been exist.'):
            self.close_edit_tag()
            self.del_tag(tagname)
            self.open_app_tag()
            self.selib.input_text(uilocators.tag_name_input, tagname)
            self.selib.click_element(uilocators.new_tag_save_btn)
    def search_tag(self,text):
        self.selib.input_text(uilocators.tag_search_input, text)
        self.selib.click_element(uilocators.tag_search_btn)
    def del_tag(self,tagname):
        self.open_del_tag(tagname)
        self.confirm_del_tag()
    def open_del_tag(self,tagname):
        del_btn = "//tr/td[text()='{}']/../td/button[2]".format(tagname)
        self.click_locator(del_btn)
    def confirm_del_tag(self):
        self.selib.click_element(uilocators.del_tag_btn)
    def edit_tag(self,tagname_old,tagname_new):
        self.open_edit_tag(tagname_old)
        self.selib.input_text(uilocators.tag_name_input, tagname_new)
        self.confirm_edit_tag()
    def open_edit_tag(self,tagname):
        edit_btn = "//tr/td[text()='{}']/../td/button[1]".format(tagname)
        self.click_locator(edit_btn)
    def confirm_edit_tag(self):
        self.selib.click_element(uilocators.new_tag_save_btn)
    def close_edit_tag(self):
        self.selib.click_element(uilocators.close_edit_tag_btn)
    def verify_tag_field(self,text):
        assert self.wait_page_contains(text, 10)
