#!/usr/bin/env python
# coding=utf-8

from lib.modules.LoginMenu import LoginMenu
from lib.utils import constant
import logging as logger
import os
import json
import jsonpath
import requests
import random

class TestLoginMenu(LoginMenu):
    ROBOT_LIBRARY_SCOPE = 'TEST SUITE'
    ROBOT_LIBRARY_VERSION = "0.1"

    def __init__(self):
        #self.testlogin = LoadingMainPage(os.getenv('SV_USER'), os.getenv('SV_PWD'), 549)
        LoginMenu.__init__(self, constant.SV_USER, constant.SV_PWD)

    def test_login(self):
        assert self.is_complete()

    def test_login_errorpassword(self):
        logger.info("login process")
        headers = {'Connection': 'keep-alive',
         'Content-Type':'application/json',
         'Accept':'application/json, text/plain, */*'}
        url = '/v2/ux/user/login'
        data ={"username":"pepper@cloudminds.com","password":"123456"}
        r = requests.post(constant.SERVER +url, headers=headers, json=data, timeout=15, verify=False)
        print(r.json()["error"])
        if r.json()["error"] == "username or password is wrong!":
            assert True
        else:
            assert False

    def test_login_admin(self):
        logger.info("login process")
        headers = {'Connection': 'keep-alive',
         'Content-Type':'application/json',
         'Accept':'application/json, text/plain, */*'}
        url = '/v2/ux/user/login'
        #data ={"username":constant.SV_ADMIN,"password":constant.SV_ADMIN_PWD}
        data = {"username": 'admin@cloudminds', "password": 'Smartvoice1506'}
        result = requests.post(constant.SERVER +url, headers=headers, json=data, timeout=15, verify=False)
        data = json.loads(result.text)
        json_data = jsonpath.jsonpath(data, expr='$.[agentid]')
        if json_data[0] == 1:
            assert True
        else:
            assert False

    def test_login_master(self):
        AccountName = "autotestaccount" + str(random.randint(10000, 99999)) + str(
            random.randint(10000, 99999)) + "@cloudminds.com"
        Password = "Cloudminds123"
        GroupName = "autotestgroup" + str(random.randint(10000, 99999)) + str(random.randint(10000, 99999))
        # AccountName = "autotestaccount@cloudminds.com"
        # Password = "Cloudminds123"
        # GroupName = "autotestgroup"
        try:
            groupname = self.test_admin_create_groups(GroupName,GroupName)
            result = self.test_admin_create_master(AccountName,Password,GroupName)
            if result:
                headers = {'Connection': 'keep-alive',
                           'Content-Type': 'application/json',
                           'Accept': 'application/json, text/plain, */*'}
                url = '/v2/ux/user/login'
                data = {"username": AccountName, "password": Password}
                result = requests.post(constant.SERVER + url, headers=headers, json=data, timeout=15, verify=False)
                data = json.loads(result.text)
                json_data = jsonpath.jsonpath(data, expr='$.[agentid]')
                if json_data[0] == 1:
                    print("Master登陆成功")
                    assert True
                else:
                    print("Master登陆失败")
                    assert False
        finally:
            accid = self.test_admin_get_accountid(AccountName)
            accresult = self.test_admin_dalete_account(accid)
            print("测试数据清理成功")
            if accresult:
                print("账户数据清理成功！")
            else:
                print("账户数据清理失败！")
            groupid = self.test_admin_get_groupsid(GroupName)
            grrresult = self.test_admin_dalete_group(groupid)
            if grrresult:
                print("分组数据清理成功！")
            else:
                print("分组数据清理失败！")

    #Slave账号登录
    def test_login_slave(self):
        AccountName = "autotestaccount" + str(random.randint(10000, 99999)) + str(
            random.randint(10000, 99999)) + "@cloudminds.com"
        Password = "Cloudminds123"
        GroupName = "autotestgroup" + str(random.randint(10000, 99999)) + str(random.randint(10000, 99999))
        try:
            groupname = self.test_admin_create_slavegroups(GroupName,GroupName)
            result = self.test_admin_create_slavemaster(AccountName,Password,GroupName)
            if result:
                headers = {'Connection': 'keep-alive',
                           'Content-Type': 'application/json',
                           'Accept': 'application/json, text/plain, */*'}
                url = '/v2/ux/user/login'
                data = {"username": AccountName, "password": Password}
                result = requests.post(constant.SERVER + url, headers=headers, json=data, timeout=15, verify=False)
                data = json.loads(result.text)
                rolevalue = jsonpath.jsonpath(data, expr='$.[role]')
                if rolevalue[0] == "slave":
                    print("角色验证成功！")
                    assert True
                else:
                    print("角色验证失败！")
                    assert False
                authalue = jsonpath.jsonpath(data, expr='$.[authority]')
                print(authalue)
                print(authalue[0]["customdomain"])
                if authalue[0]["customdomain"] == True  and authalue[0]["domainmanage"] == False and authalue[0]["qatype"] == False and authalue[0]["qamark"] == False and authalue[0]["faqmanage"] == True and authalue[0]["faq"] == False and authalue[0]["chitchat"] == False and authalue[0]["train"] == False:
                    print("应用列表权限验证成功!")
                    assert True
                else:
                    print("应用列表权限验证失败!")
                    assert False
        finally:
            accid = self.test_admin_get_accountid(AccountName)
            accresult = self.test_admin_dalete_account(accid)
            if accresult:
                print("账户数据清理成功！")
            else:
                print("账户数据清理失败！")
            groupid = self.test_admin_get_groupsid(GroupName)
            grrresult = self.test_admin_dalete_group(groupid)
            if grrresult:
                print("分组数据清理成功！")
            else:
                print("分组数据清理失败！")


    def test_login_setting_accountinfo(self):
        #保存原始账号信息
        UserOfOriginalInformation = self.user_info()
        #创建修改的账号信息
        realname = "realnameinfo" + str(random.randint(10000, 99999)) + str(random.randint(10000, 99999))
        mail = "mailinfo" + str(random.randint(10000, 99999))+"@cloudminds.com"
        telephone = "159"+str(random.randint(1000, 9999)) + str(random.randint(1000, 9999))
        try:
            result = self.user_edit(realname,mail,telephone)
            if result:
                result = self.user_info()
                if result[0][0] == realname and result[1][0] == mail and result[2][0] == telephone:
                    print("修改账号信息测试通过！")
                    assert True
                else:
                    print("修改账号信息测试失败！")
                    assert False
            else:
                print("修改信息失败")
                assert False
        finally:
            # 数据清理
            result = self.user_edit(UserOfOriginalInformation[0][0],UserOfOriginalInformation[1][0],UserOfOriginalInformation[2][0])
            if result:
                print("账号信息恢复成功！")
                assert True
            else:
                print("账号信息恢复失败！")
                assert False



    #子账号修改密码验证
    def test_login_setting_accountChangePassword(self):
        AccountName = "autotestaccount" + str(random.randint(10000, 99999)) + str(
            random.randint(10000, 99999)) + "@cloudminds.com"
        Password = "Cloudminds123"
        GroupName = "autotestgroup" + str(random.randint(10000, 99999)) + str(random.randint(10000, 99999))
        try:
            groupname = self.test_admin_create_groups(GroupName, GroupName)
            result = self.test_admin_create_master(AccountName, Password, GroupName)
            if result:
                headers = {'Connection': 'keep-alive',
                           'Content-Type': 'application/json',
                           'Accept': 'application/json, text/plain, */*'}
                url = '/v2/ux/user/login'
                data = {"username": AccountName, "password": Password}
                result = requests.post(constant.SERVER + url, headers=headers, json=data, timeout=15, verify=False)
                data = json.loads(result.text)
                json_data = jsonpath.jsonpath(data, expr='$.[agentid]')
                if json_data[0] == 1:
                    print("Master登陆成功")
                    # 账号修改密码
                    newpassword = self.uaer_ChangePassword(AccountName, Password)
                    if newpassword:
                        # 使用新密码登录
                        result = self.test_logininfo_AddedOperator(AccountName, newpassword)
                        if result:
                            # 使用老密码登录
                            print("新密码登陆成功！")
                            result = self.test_logininfo_AddedOperator(AccountName, Password)
                            if result:
                                print("老密码仍能登录，测试失败")
                                assert False
                            else:
                                print("老密码不能登陆！")
                                assert True
                        else:
                            print("新密码登录失败！")
                            assert False
                    else:
                        print("密码修改失败")
                        assert False
                else:
                    print("Master登陆失败")
                    assert False
            else:
                print("创建账号失败")
                assert False
        finally:
            accid = self.test_admin_get_accountid(AccountName)
            accresult = self.test_admin_dalete_account(accid)
            print("测试数据清理成功")
            if accresult:
                print("账户数据清理成功！")
            else:
                print("账户数据清理失败！")
            groupid = self.test_admin_get_groupsid(GroupName)
            grrresult = self.test_admin_dalete_group(groupid)
            if grrresult:
                print("分组数据清理成功！")
            else:
                print("分组数据清理失败！")




    #创建子账号，退出测试
    def test_login_setting_Logout(self):
        AccountName = "autotestaccount" + str(random.randint(10000, 99999)) + str(
            random.randint(10000, 99999)) + "@cloudminds.com"
        Password = "Cloudminds123"
        GroupName = "autotestgroup" + str(random.randint(10000, 99999)) + str(random.randint(10000, 99999))
        try:
            groupname = self.test_admin_create_groups(GroupName, GroupName)
            result = self.test_admin_create_master(AccountName, Password, GroupName)
            if result:
                headers = {'Connection': 'keep-alive',
                           'Content-Type': 'application/json',
                           'Accept': 'application/json, text/plain, */*'}
                url = '/v2/ux/user/login'
                data = {"username": AccountName, "password": Password}
                result = requests.post(constant.SERVER + url, headers=headers, json=data, timeout=15, verify=False)
                data = json.loads(result.text)
                json_data = jsonpath.jsonpath(data, expr='$.[agentid]')
                if json_data[0] == 1:
                    print("Master登陆成功")
                    # 退出
                    result = self.uaer_logout(AccountName, Password)
                    if result:
                        print("账号退出成功！")
                        assert True
                    else:
                        print("账号退出失败")
                        assert False
                else:
                    print("Master登陆失败")
                    assert False
            else:
                print("创建账号失败")
                assert False
        finally:
            accid = self.test_admin_get_accountid(AccountName)
            accresult = self.test_admin_dalete_account(accid)
            print("测试数据清理成功")
            if accresult:
                print("账户数据清理成功！")
            else:
                print("账户数据清理失败！")
            groupid = self.test_admin_get_groupsid(GroupName)
            grrresult = self.test_admin_dalete_group(groupid)
            if grrresult:
                print("分组数据清理成功！")
            else:
                print("分组数据清理失败！")


