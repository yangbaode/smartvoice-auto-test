#!/usr/bin/env python
# coding=utf-8

from lib.modules.LoadingMainPage import LoadingMainPage
import logging as logger
from lib.utils import constant
import os
import json
import time
data = time.strftime("%Y-%m-%d", time.localtime())

class TestLogin(LoadingMainPage):
    ROBOT_LIBRARY_SCOPE = 'TEST SUITE'
    ROBOT_LIBRARY_VERSION = "0.1"

    def __init__(self):
        LoadingMainPage.__init__(self, constant.SV_USER, constant.SV_PWD, constant.agent_id)

    def test_login(self):
        assert self.is_complete()

    def test_loadpage_agentid_by_day(self):
        para = {'params':{'enddate': data,'level': 'day', 'startdate': '2019-06-10'}}
        _, duration = self.statistics_hittimes_agent(para)
        assert duration < 20

    def test_loadpage_domain_by_day(self):
        para = {'params':{'enddate': data,'level': 'day', 'startdate': '2019-06-10'}}
        pattern = "$.[?(@.agentname=='{}' && @.x=='test_position')]".format(constant.agent_name)
        result, duration = self.statistics_hittimes_domain(para, pattern=pattern)
        assert result[0]['agentname'] == constant.agent_name
        assert duration < 20

    def test_loadpage_agent_hittime_by_month(self):
        para = {'params':{'enddate': '2019-08-01','level': 'month', 'startdate': '2019-06-01'}}
        pattern = "$.[?(@.agentname=='{}' && @.statisdate=='2019-06')].hittimes".format(constant.agent_name)
        #基于历史数据的验证
        result, duration = self.statistics_hittimes_agent(para, pattern=pattern)
        assert result[0] >= 1285297
        assert duration < 20

    def test_loadpage_agent_hittime_by_day(self):
        para = {'params':{'enddate': data,'level': 'day', 'startdate': '2019-06-10'}}
        pattern = "$.[?(@.agentname=='{}' && @.statisdate=='2019-06-27')].hittimes".format(constant.agent_name)
        #基于历史数据的验证
        result, duration = self.statistics_hittimes_agent(para, pattern=pattern)
        assert result[0] >= 5321
        assert duration < 20

    def test_get_agent_num(self):
        result = self.get_agent_num()
        assert result > 190

    def test_question(self):
        result = self.question_test('你好')
        js = json.loads(result['answer'])
        print('回答内容:', js)
