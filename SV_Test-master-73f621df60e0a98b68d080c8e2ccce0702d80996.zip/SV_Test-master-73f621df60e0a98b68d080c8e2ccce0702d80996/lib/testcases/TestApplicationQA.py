#!/usr/bin/env python
# coding=utf-8

'''
Created on Jun 10, 2019

@author: chendianmo
'''

from lib.uilocators import uilocators_QA
from lib.modules.UiBase import UiBase
from lib.modules.ApplicationQAInterFace import ApplicationQAInterFace
import os
import time
from lib.utils import constant
from lib.utils.logger import logger



class TestApplicationQA(ApplicationQAInterFace):

    def __init__(self):
        ApplicationQAInterFace.__init__(self, constant.SV_USER, constant.SV_PWD, constant.agent_id)
        # ApplicationQAInterFace.__init__(self, constant.SV_SLAVE, constant.SV_SLAVE_PWD, constant.agent_id1)
        # logger.error("测试使用")

        ### UI #################################
        ### UI #################################
        ### UI #################################
        self.add_user_group()

    def login_to_agent(self):
        '''
        登录SmartVoice，点击应用列表的agent名称
        :return:
        '''
        ui = UiBase()
        ui.login_smartvoice()
        ui.click_by_js(uilocators_QA.application_default)
        ui.wait_element_present(uilocators_QA.applicationName, timeout=10)
        ui.click_by_js(uilocators_QA.applicationName)
        ui.wait_element_disapear(uilocators_QA.loading, timeout=5)

    def enter_agent_QA_dirName(self):
        '''
        点击问答按钮，再点击问答分类按钮，
        :return:
        '''
        ui = UiBase()
        ui.wait_element_present(uilocators_QA.answer_button, timeout=10)
        ui.click_by_js(uilocators_QA.answer_button)
        ui.wait_element_present(uilocators_QA.answer_type_button, timeout=10)
        ui.click_by_js(uilocators_QA.answer_type_button)

    def click_qa_dirName(self):
        '''
        点击 目录里面的  自定义问答 按钮
        :return:
        '''
        ui = UiBase()
        ui.wait_element_present(uilocators_QA.user_defined_qa, timeout=10)
        time.sleep(3)
        ui.click_by_js(uilocators_QA.user_defined_qa)

    def click_qa_checkbox(self, question):
        '''
        点击问答对的 勾选框
        :param question: 问题
        :return:
        '''
        ui = UiBase()
        ui.wait_element_present(
            "//tr[@class='ant-table-row ng-star-inserted'][contains(.,{})]/td[1]//span[@class='ant-checkbox']".format(
                question), timeout=10)
        ui.click_by_js(
            "//tr[@class='ant-table-row ng-star-inserted'][contains(.,{})]/td[1]//span[@class='ant-checkbox']".format(
                question))

    def choose_dirName_move(self, dirName):
        '''
        点击批量移动按钮，一直到子目录
        :param dirName:
        :return:
        '''
        ui = UiBase()
        ui.wait_element_present(uilocators_QA.lots_move, timeout=10)
        ui.click_locator(uilocators_QA.lots_move)
        time.sleep(1)
        ui.wait_element_present(uilocators_QA.choose_type, timeout=10)
        ui.click_locator(uilocators_QA.choose_type)
        time.sleep(1)
        ui.wait_element_present(uilocators_QA.choose_parent, timeout=10)
        ui.click_locator(uilocators_QA.choose_parent)
        time.sleep(1)
        ui.wait_element_present("//div[@class='cdk-overlay-container']//li[contains(.,'{}')]".format(dirName))
        ui.click_locator("//div[@class='cdk-overlay-container']//li[contains(.,'{}')]".format(dirName))

    def lots_del(self):
        ui = UiBase()
        ui.wait_element_present(uilocators_QA.lots_del, timeout=10)
        ui.click_locator(uilocators_QA.lots_del)

    def click_cancel_button(self):
        ui = UiBase()
        ui.wait_element_present(uilocators_QA.cancel_button, timeout=10)
        ui.click_locator(uilocators_QA.cancel_button)

    def choose_qa_click_edit(self, question):
        ui = UiBase()
        ui.wait_element_present(
            "//tr[@class='ant-table-row ng-star-inserted'][contains(.,'{}')]/td[8]/button[2]".format(question))
        ui.click_locator(
            "//tr[@class='ant-table-row ng-star-inserted'][contains(.,'{}')]/td[8]/button[2]".format(question))
        a = ui.selib.get_element_attribute("//div[@class='form-item-bottom ant-form-item']", "innerHTML")
        print('元素标签内容： ', a)
        return a

    def verify_UI_exist_element(self, question):
        ui = UiBase()
        ui.wait_element_present(
            "//tr[@class='ant-table-row ng-star-inserted'][contains(.,'{}')]".format(question))
        a = ui.selib.get_element_attribute("//tr[@class='ant-table-row ng-star-inserted'][contains(.,'{}')]".format(question), "innerHTML")
        print('元素标签内容： ', a)
        return a

### 接口测试 ###

    # CV-10988 应用 - 问答 - 编辑问答时删除问题
    def test_001_del_One_question_send_qa(self):
        real_dirName = ['默认回答', '自定义问答', '迎宾语', '开机语']
        # for a in real_dirName:
        #     self.del_all_qa(a)
        print("这轮CASES开始执行...")
        time.sleep(2)
        # self.del_all_dirName()
        time.sleep(2)
        self.add_qa_lots('自定义问答','你今年多大了','我今年30岁了', '你今年几岁了啊', '我今年奔三十了呢')
        time.sleep(2)
        a,b,c = self.send_qa('你今年几岁了啊','我今年30岁了')
        assert b == '我今年30岁了' or b == '我今年奔三十了呢', "回答错误"
        self.edit_qa_lots('自定义问答','你今年多大了','我今年30岁了', '你今年几岁了啊', '我今年30岁了', new_answer2='我今年奔三十了呢')
        time.sleep(2)
        a, b, d = self.send_qa('你今年几岁了啊', '我今年30岁了')
        assert b == '我今年30岁了' or b == '我今年奔三十了呢', "回答错误"
        time.sleep(2)
        # self.del_qa('自定义问答','你今年几岁了啊','我今年30岁了')

    # CV-10987 应用-问答-编辑问答时删除答案
    def test_002_del_One_answer_send_qa(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        self.add_qa_lots('自定义问答','你今年多大了','我今年30岁了', '你今年几岁了啊', '我今年奔三十了呢')
        time.sleep(2)
        a,b,c = self.send_qa('你今年几岁了啊','我今年30岁了')
        assert b == '我今年30岁了' or b == '我今年奔三十了呢', "回答错误"
        self.edit_qa_lots('自定义问答','你今年多大了','我今年30岁了', '你今年多大了', '我今年30岁了', new_question2='你今年几岁了啊')
        time.sleep(2)
        a, b, d = self.send_qa('你今年几岁了啊', '我今年30岁了')
        assert b == '我今年30岁了', "回答错误"
        time.sleep(2)
        self.del_qa('自定义问答','你今年几岁了啊','我今年30岁了')

    # CV-9458 应用-问答-在smartVoice库中存在一个问题多个答案时测试
    def test_003_lots_answer_test(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        self.add_qa('自定义问答','你今年几岁了啊','我今年30岁了', answer1='我今年奔三十了呢')
        time.sleep(2)
        a, b, c = self.send_qa('你今年几岁了啊', '我今年30岁了')
        assert b == '我今年30岁了' or b == '我今年奔三十了呢', "回答错误"
        time.sleep(2)
        a, b, c = self.send_qa('你今年几岁了啊', '我今年30岁了')
        assert b == '我今年30岁了' or b == '我今年奔三十了呢', "回答错误"
        time.sleep(2)
        self.del_qa('自定义问答', '你今年几岁了啊', '我今年30岁了')

    # CV-9457 应用-问答-在smartVoice库中新增自定义问答问题中包含关键字测试
    def test_004_keywords_test(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        self.add_qa('自定义问答','你今年多大了','我今年30岁了', answer1='我今年奔三十了呢', keywords='今年多大')
        time.sleep(2)
        keywords = self.get_qa_keywords('自定义问答','你今年多大了','我今年30岁了')
        print('keywords: ', keywords)
        assert keywords == '今年多大', "关键字错误，两者不一样"
        time.sleep(2)
        self.del_qa('自定义问答', '你今年多大了', '我今年30岁了')

    # CV-9456 应用-问答-在smartVoice库中新增重复提问回答后测试
    def test_005_lots_send_repeat_QA(self):
        print('由于SV已经没有重复提问回答目录， 所以Pass')
        # self.del_all_qa('自定义问答')
        # time.sleep(2)
        # self.add_qa('自定义问答', '你今年多大了', '我今年30岁了', answer1='我今年奔三十了呢', keywords='今年多大')
        # time.sleep(2)
        # a, b, c = self.send_qa('你今年多大了', '我今年30岁了')
        # assert b == '我今年30岁了' or b == '我今年奔三十了呢', "回答错误"
        # time.sleep(2)
        # a, b, c = self.send_qa('你今年多大了', '我今年30岁了')
        # assert b == '我今年30岁了' or b == '我今年奔三十了呢', "回答错误"
        # time.sleep(1)
        # a, b, c = self.send_qa('你今年多大了', '我今年30岁了')
        # assert b == '我今年30岁了' or b == '我今年奔三十了呢', "回答错误"
        # time.sleep(1)
        # a, b, c = self.send_qa('你今年多大了', '我今年30岁了')
        # assert b == '我今年30岁了' or b == '我今年奔三十了呢', "回答错误"
        # for i in range(5):
        #     value = self.del_qa('自定义问答', '你今年多大了', '我今年30岁了')
        #     time.sleep(2)
        #     if value == False:
        #         break
        # a, b, c = self.send_qa('你今年多大了', '我今年30岁了')
        # assert c == 'user_default_qa', "source 为默认回答"

    # CV-9455 应用-问答-在smartVoice库中新增默认回答后测试
    def test_006_send_QA_return_default_answer(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        assert self.add_welcome_repeat_default_words('默认回答', '这是默认答案')
        time.sleep(2)
        a, b, c = self.send_qa('你是小小邓么', '我今年30岁了')
        print('a:',a, '\n','b: ',b, '\n','c: ',c)
        time.sleep(2)
        assert b == '这是默认答案', "回答的不是默认答案，不等于 这是默认答案  "
        assert c == 'user_default_qa', "source 是默认答案"

    # CV-9454 应用-问答-在smartVoice库中新增自定义问答后测试
    def test_007_send_qa_normal(self):
        self.del_all_qa('自定义问答')
        time.sleep(5)
        self.add_qa('自定义问答', '她今年多大了', '我今年30岁了', answer1='我今年奔三十了呢', keywords='今年多大')
        time.sleep(8)
        a, b, c = self.send_qa('她今年多大了', '我今年30岁了')
        print("a,b,c:",a, b, c)
        assert b == '我今年30岁了' or b == '我今年奔三十了呢', "回答错误"
        assert a == '她今年多大了', "问题错误"
        assert c == 'user_qa', "source 不正确"
        for i in range(5):
            value = self.del_qa('自定义问答', '她今年多大了', '我今年30岁了')
            time.sleep(2)
            if value == False:
                break
        a, b, c = self.send_qa('她今年多大了', '我今年30岁了')
        print("a,b,c:", a, b, c)
        assert c == 'user_default_qa', "source 为默认回答"

    # CV-9435 应用-问答-删除问答
    def test_008_del_QA(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        self.add_qa('自定义问答', '你今年多大了', '我今年30岁了', answer1='我今年奔三十了呢', keywords='今年多大')
        assert self.del_qa('自定义问答', '你今年多大了', '我今年30岁了')
        # a, b, c = self.send_qa('你今年多大了', '我今年30岁了')
        # print("a,b,c---:",a, b, c)
        self.fqa_enable()
        a, b, c = self.send_qa('你今年多大了', '我今年30岁了')
        print("b--:",b)
        self.fqa_able()
        # assert b == '默认回答', "回答的不是默认答案， == 这是默认答案  "
        assert c == 'user_default_qa', "source 为默认回答"

    # CV-9432 应用-问答分类-新建问答时添加关键字
    def test_009_add_keywords(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        self.add_qa('自定义问答', '你今年多大了', '我今年30岁了', answer1='我今年奔三十了呢', keywords='今年多大')
        time.sleep(2)
        keywords = self.get_qa_keywords('自定义问答', '你今年多大了', '我今年30岁了')
        print('keywords: ', keywords)
        assert keywords == '今年多大', "关键字错误，两者不一样"
        time.sleep(2)
        assert self.del_qa('自定义问答', '你今年多大了', '我今年30岁了')

    # CV-9433 应用-问答分类-编辑问答时删除关键字
    def test_010_edit_del_keywords(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        self.add_qa('自定义问答', '你今年多大了', '我今年30岁了', keywords='今年多大')
        time.sleep(2)
        keywords = self.get_qa_keywords('自定义问答', '你今年多大了', '我今年30岁了')
        print('keywords: ', keywords)
        assert keywords == '今年多大', "关键字错误，两者不一样"
        time.sleep(2)
        self.edit_qa_lots('自定义问答', '你今年多大了', '我今年30岁了','你今年多大了', '我今年30岁了')
        time.sleep(2)
        keywords_value = self.get_qa_keywords('自定义问答', '你今年多大了', '我今年30岁了')
        print('keywords: ', keywords_value)
        assert keywords_value == False, "还有关键字"
        time.sleep(2)
        self.del_qa('自定义问答', '你今年多大了', '我今年30岁了')

    # CV-9429 应用-问答-编辑问答时删除问题和答案
    def test_011_edit_lots_QA(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        self.add_qa('自定义问答', '你今年多大了', '我今年30岁了', question1='你几岁了啊', answer1='我今年已经不小了呢')
        time.sleep(2)
        self.edit_qa_lots('自定义问答', '你今年多大了', '我今年30岁了', '你几岁了啊', '我今年已经不小了呢', new_answer2='你管我多大呢')
        time.sleep(2)
        a, b, c = self.send_qa('你几岁了啊', '我今年已经不小了呢')
        assert b == '我今年已经不小了呢' or b == '你管我多大呢', "回答错误"
        assert c == 'user_qa', "source 不正确"
        self.del_all_qa('自定义问答')
        time.sleep(2)
        # d, e, f = self.send_qa('你几岁了啊', '我今年已经不小了呢')
        self.fqa_enable()
        d, e, f = self.send_qa('你几岁了啊', '我今年已经不小了呢')
        self.fqa_able()
        assert f == 'user_default_qa', "source 为默认回答"

    # CV-9430 应用-问答-编辑问答时添加标签
    def test_012_edit_add_keywords(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        self.add_qa('自定义问答', '她今年多大了', '我今年30岁了', question1='她几岁了啊', answer1='我今年已经不小了呢')
        time.sleep(2)
        self.edit_qa_lots('自定义问答', '她今年多大了', '我今年30岁了', '她今年多大了', '我今年已经不小了呢', keywords='她今年多大了')
        time.sleep(2)
        a, b, c = self.send_qa('她今年多大了', '我今年已经不小了呢')
        assert b == '我今年已经不小了呢', "回答错误"
        keywords_value = self.get_qa_keywords('自定义问答','她今年多大了', '我今年已经不小了呢')
        print('keywords_value:', keywords_value)
        assert keywords_value =='她今年多大了', "关键字匹配正确"
        time.sleep(2)
        self.del_qa('自定义问答', '她今年多大了', '我今年已经不小了呢')

    # CV-9431 应用-问答-编辑问答时删除标签
    def test_013_edit_qa_del_keywords(self):
        self.add_qa('自定义问答', '你今年多大了', '我今年30岁了', keywords='你今年多大了')
        time.sleep(2)
        keywords_value = self.get_qa_keywords('自定义问答', '你今年多大了', '我今年30岁了')
        print('keywords_value:', keywords_value)
        assert keywords_value == '你今年多大了', "关键字匹配正确"
        time.sleep(2)
        self.edit_qa_lots('自定义问答', '你今年多大了', '我今年30岁了', '你今年多大了', '我今年30岁了')
        keywords_value1 = self.get_qa_keywords('自定义问答', '你今年多大了', '我今年30岁了')
        print('keywords_value:', keywords_value1)
        assert keywords_value1 == False, "还存在关键字"
        time.sleep(2)
        self.del_qa('自定义问答', '你今年多大了', '我今年30岁了')

    # CV-9434 应用-问答-组ID无法编辑
    def test_014_edit_group_ID(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        self.add_qa('自定义问答', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        group_ID = self.get_qa_groupId('自定义问答', '你今年多大了', '我今年30岁了')
        print('group_ID: ', group_ID)
        self.login_to_agent()
        self.enter_agent_QA_dirName()
        self.click_qa_dirName()
        content = self.choose_qa_click_edit('你今年多大了')
        assert 'input' not in content, "存在输入框，可以编辑"

    # CV-9443 应用-问答-通过标签筛选
    def test_015_search_tag_QA(self,tagname):
        self.add_tag(tagname)
        self.del_all_qa('自定义问答')
        self.del_all_dirName()
        time.sleep(2)
        self.add_qa('自定义问答', '你今年多大了', '我今年30岁了', keywords='你今年多大了', tag1=tagname)
        time.sleep(2)
        self.add_qa('自定义问答', '你今年多大了', '我不告诉你', keywords='你今年多大了', tag1=tagname)
        time.sleep(2)
        assert self.get_tag_qa_verify_tag('自定义问答', tagname), "正确"
        self.del_qa('自定义问答', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        self.del_qa('自定义问答', '你今年多大了', '我不告诉你')
        self.delete_teg(tagname)

    # CV-9444 应用-问答-通过重置标签筛选
    def test_016_reset_search_QA_tag(self,tagname):
        self.add_tag(tagname)
        self.add_qa('自定义问答', '你今年多大了', '我今年30岁了', keywords='你今年多大了', tag1=tagname)
        time.sleep(2)
        self.add_qa('自定义问答', '你今年多大了', '我不告诉你', keywords='你今年多大了', tag1=tagname)
        time.sleep(2)
        assert self.get_tag_qa_verify_tag('自定义问答', tagname), "正确"
        # 重置TAG
        time.sleep(2)
        all_tag, all_qa_numbers = self.get_all_qa_tag('自定义问答')
        print('all_tag, all_qa_numbers: ',all_tag,'||' ,all_qa_numbers)
        assert all_qa_numbers >= len(all_tag)
        self.del_qa('自定义问答', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        self.del_qa('自定义问答', '你今年多大了', '我不告诉你')
        self.delete_teg(tagname)

    # CV-9452 应用-问答-修改列表每页显示数
    def test_017_edit_pageDisplay_counts(self):
        self.upload_file('自定义问答', 'temp_test.xlsx')
        assert self.switch_page_qa_numbers('自定义问答', 20)
        assert self.switch_page_qa_numbers('自定义问答', 30)

    # CV-9411 应用-问答-迎宾语中的问答对操作
    def test_018_add_edit_del_welcome_words(self):
        assert self.add_welcome_repeat_default_words('迎宾语', '你是猪么')
        time.sleep(2)
        assert self.edit_welcome_repeat_default_words('迎宾语', '你是猪么', '我不是猪')
        time.sleep(2)
        assert self.del_welcome_repeat_default_words('迎宾语', '我不是猪')
        time.sleep(2)
        assert self.verify_answer_exist('迎宾语', '我不是猪')==False

    # CV-9420 应用-问答-新建自定义问答
    def test_019_new_add_qa(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        self.add_qa('自定义问答','她今年多大了','我今年30岁了', answer1='我今年奔三十了呢')
        time.sleep(2)
        a, b, c = self.send_qa('她今年多大了', '我今年30岁了')
        assert b == '我今年30岁了' or b == '我今年奔三十了呢', "回答错误"
        time.sleep(2)
        assert self.del_qa('自定义问答', '她今年多大了', '我今年30岁了')

    # CV-9419 应用-问答-新建重复提问回答
    def test_020_add_repeat_qa(self):
        print('由于SV已经没有重复提问回答目录， 所以Pass')
        # assert self.add_welcome_repeat_default_words('重复提问回答', '你是猪么')
        # time.sleep(2)
        # assert self.del_welcome_repeat_default_words('重复提问回答', '你是猪么')

    # CV-9418 应用-问答-新建默认回答
    def test_021_add_default_qa(self):
        assert self.add_welcome_repeat_default_words('默认回答', '你是猪么')
        time.sleep(2)
        assert self.del_welcome_repeat_default_words('默认回答', '你是猪么')

    # CV-9450 应用-问答-导入不符合要求的文件
    def test_022_import_abnormal_file(self):
        value = self.upload_file('自定义问答', 'error_qa.xlsx')
        assert value==False, "导入失败"

    # CV-9446 应用-问答-问答根目录下搜索
    def test_023_qa_search_parent(self):
        self.tag_add("我是标签")
        self.add_qa('自定义问答', '你今年多大了', '我今年30岁了', keywords='你今年多大了', tag1='我是标签')
        time.sleep(2)
        assert self.verify_search_Q_inList('自定义问答', '你今年多大了')
        time.sleep(2)
        self.del_qa('自定义问答', '你今年多大了', '我今年30岁了')

    # CV-9445 应用-问答-问答分类下搜索
    def test_024_qa_search_dirName(self):
        self.add_qa('自定义问答', '你今年多大了', '我今年30岁了', keywords='你今年多大了', tag1='我是标签')
        time.sleep(2)
        assert self.verify_search_Q_inList('自定义问答', '你今年多大了')
        time.sleep(2)
        self.del_qa('自定义问答', '你今年多大了', '我今年30岁了')

    # CV-9441 应用-问答-全部移动
    def test_025_move_all_qa(self):
        # 需要解决json报错问题
        self.del_all_dirName()
        time.sleep(2)
        self.del_all_qa('自定义问答')
        time.sleep(2)
        self.add_dirName('这是测试目录')
        time.sleep(2)
        self.add_qa('自定义问答', '你是哪个国家的','我是中国人')
        self.add_qa('自定义问答', '你喜欢美国么', '你才喜欢猪呢')
        self.add_qa('自定义问答', '你是中国人吗', '我是')
        time.sleep(2)
        assert self.qa_move('自定义问答','这是测试目录','你是哪个国家的','我是中国人',q2='你喜欢美国么',a2='你才喜欢猪呢',q3='你是中国人吗',a3='我是')
        time.sleep(2)
        assert self.verify_qa_display_UI('自定义问答','你是哪个国家的','我是中国人') == False
        assert self.verify_qa_display_UI('这是测试目录','你喜欢美国么','你才喜欢猪呢')
        time.sleep(2)
        self.del_all_dirName()

    # CV-9442 应用-问答-全部删除
    def test_026_del_qa_batch(self):
        # 需要解决json报错问题
        self.del_all_dirName()
        time.sleep(2)
        assert self.add_dirName('测试')
        time.sleep(2)
        self.del_all_qa('测试')
        time.sleep(2)
        self.add_qa('测试', '你是哪个国家的', '我是中国人')
        self.add_qa('测试', '你喜欢美国么', '你才喜欢猪呢')
        self.add_qa('测试', '你是中国人吗', '我是')
        time.sleep(2)
        assert self.del_qa_batch('测试','你是哪个国家的','我是中国人',q2='你喜欢美国么',a2='你才喜欢猪呢',q3='你是中国人吗',a3='我是')
        time.sleep(2)
        assert self.verify_qa_display_UI('测试','你是哪个国家的','我是中国人') == False

    # CV-9439 应用-问答-批量删除
    def test_027_del_qa_batch(self):
        # 需要解决json报错问题
        self.del_all_dirName()
        time.sleep(2)
        self.add_dirName('测试')
        time.sleep(2)
        self.del_all_qa('测试')
        time.sleep(2)
        self.add_qa('测试', '你是哪个国家的', '我是中国人')
        self.add_qa('测试', '你喜欢美国么', '你才喜欢猪呢')
        self.add_qa('测试', '你是中国人吗', '我是')
        time.sleep(2)
        assert self.del_qa_batch('测试', '你是哪个国家的', '我是中国人', q2='你喜欢美国么', a2='你才喜欢猪呢', q3='你是中国人吗', a3='我是')
        time.sleep(2)
        assert self.verify_qa_display_UI('测试', '你是哪个国家的', '我是中国人') == False

    # CV-9378 应用-问答-admin/master账号的系统分类/根目录下新建子分类
    def test_028_add_dirName(self):
        self.del_all_dirName()
        time.sleep(2)
        assert self.add_dirName('添加测试目录'), "增加目录失败"
        time.sleep(2)
        self.add_qa('添加测试目录', '山海关河', '长江南北海北')
        time.sleep(15)
        a,b,c = self.send_qa('山海关河', '长江南北海北')
        assert b == '长江南北海北'
        time.sleep(2)
        assert self.del_dir_name('添加测试目录')

    # CV-9386 应用-问答-admin/master账号下自定义问答目录-导入
    def test_029_import_file_default(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        assert self.upload_file('自定义问答', 'temp_test.xlsx')
        time.sleep(8)
        a,b,c = self.send_qa('你们喜欢美国么','不喜欢')
        assert b == '不喜欢', "回答不正确"
        assert self.verify_qa_display_UI('自定义问答', '你们喜欢美国么','不喜欢')
        time.sleep(2)
        self.del_all_qa('自定义问答')

    # CV-9391 应用-问答-admin/master账号下用户自定义目录-导入
    def test_030_import_file_user(self):
        # self.del_all_dirName()
        # time.sleep(2)
        try:
            assert self.add_dirName('这是测试目录')
            time.sleep(8)
            assert self.upload_file('这是测试目录', 'temp_test.xlsx')
            time.sleep(8)
            a, b, c = self.send_qa('你们喜欢美国么', '不喜欢')
            assert b == '不喜欢', "回答不正确"
            assert self.verify_qa_display_UI('这是测试目录', '你们喜欢美国么', '不喜欢')
            time.sleep(2)
        finally:
            self.del_dir_name('这是测试目录')
    def test_group(self): #此函数查看是否存在分组，未存在，创建分组，绑定账号
        print("exec-----------")
        result = self.add_user_group()
        # assert result,"未存在分组，数据异常，请添加分组数据！"
    # CV-9402 应用-问答-slave账号下自定义问答目录-导入
    def test_031_slave_import_file_custom(self):
        ApplicationQAInterFace.__init__(self, constant.SV_SLAVE, constant.SV_SLAVE_PWD, constant.agent_id)
        self.del_all_qa('自定义问答')
        time.sleep(2)
        assert self.upload_file('自定义问答', 'temp_test.xlsx')
        time.sleep(8)
        a, b, c = self.send_qa('你们喜欢美国么', '不喜欢')
        assert b == '不喜欢', "回答不正确"
        assert self.verify_qa_display_UI('自定义问答', '你们喜欢美国么', '不喜欢')
        time.sleep(2)
        self.del_all_qa('自定义问答')

    # CV-9406 应用-问答-slave/operator账号下用户自定义目录-导入
    def test_032_slave_import_file_user_defined(self):
        ApplicationQAInterFace.__init__(self, constant.SV_SLAVE, constant.SV_SLAVE_PWD, constant.agent_id)
        self.del_all_qa('自定义问答')
        time.sleep(2)
        assert self.upload_file('自定义问答', 'temp_test.xlsx')
        time.sleep(8)
        a, b, c = self.send_qa('你们喜欢美国么', '不喜欢')
        assert b == '不喜欢', "回答不正确"
        assert self.verify_qa_display_UI('自定义问答', '你们喜欢美国么', '不喜欢')
        time.sleep(2)
        self.del_all_qa('自定义问答')

    # CV-10399 应用-问答-在smartVoice库中新增重复提问回答后测试
    def test_033_add_repeatQA_send_QA(self):
        print('由于SV已经没有重复提问回答目录， 所以Pass')
        # 这个函数可以删除所有目录
        # self.del_all_qa('重复提问回答')
        # time.sleep(2)
        # assert self.add_welcome_repeat_default_words('重复提问回答','这是重复问答')
        # time.sleep(2)
        # self.add_qa('自定义问答', '你今年多大了', '我今年30岁了', answer1='我今年奔三十了呢', keywords='今年多大')
        # time.sleep(2)
        # a, b, c = self.send_qa('你今年多大了', '我今年30岁了')
        # assert b == '我今年30岁了' or b == '我今年奔三十了呢', "回答错误"
        # time.sleep(2)
        # a, b, c = self.send_qa('你今年多大了', '我今年30岁了')
        # assert b == '我今年30岁了' or b == '我今年奔三十了呢', "回答错误"
        # time.sleep(1)
        # a, b, c = self.send_qa('你今年多大了', '我今年30岁了')
        # assert b == '我今年30岁了' or b == '我今年奔三十了呢', "回答错误"
        # time.sleep(1)
        # a, b, c = self.send_qa('你今年多大了', '我今年30岁了')
        # assert b == '我今年30岁了' or b == '我今年奔三十了呢', "回答错误"
        # for i in range(5):
        #     value = self.del_qa('自定义问答', '你今年多大了', '我今年30岁了')
        #     time.sleep(2)
        #     if value == False:
        #         break
        # d, e, f = self.send_qa('你今年多大了', '我今年30岁了')
        # assert f == 'user_default_qa', "source 为默认回答"

    # CV-9385 应用-问答-admin/master账号下自定义问答目录-新建子分类
    def test_034_add_new_child_dirName(self):
        self.del_all_child_dirName_name('自定义问答')
        time.sleep(2)
        assert self.add_child_next_dir_name('自定义问答', '测试子目录')
        time.sleep(2)
        assert self.del_child_dirName_name('自定义问答', '测试子目录')

    # CV-9390 应用-问答-admin/master账号下用户自定义目录-新建子分类
    def test_035_add_new_child_dirName_user(self):
        self.add_dirName('这是测试目录')
        time.sleep(2)
        assert self.add_child_next_dir_name('这是测试目录', '下一级目录')
        time.sleep(2)
        assert self.del_child_dirName_name('这是测试目录', '下一级目录')
        time.sleep(2)
        self.del_dir_name('这是测试目录')

    # CV-9393 应用-问答-admin/master账号下用户自定义自创目录-编辑
    def test_036_edit_user_dirName(self):
        self.del_all_dirName()
        assert self.add_dirName('这是测试目录')
        time.sleep(2)
        assert self.edit_dir_name('这是测试目录','编辑后测试目录')
        time.sleep(2)
        assert self.verify_dirName_exist('编辑后测试目录')
        time.sleep(2)
        assert self.del_dir_name('编辑后测试目录')

    # CV-9394 应用-问答-admin/master账号下用户自定义自创目录-删除
    def test_037_del_user_dirName(self):
        self.del_all_dirName()
        assert self.add_dirName('这是测试目录')
        time.sleep(2)
        assert self.verify_dirName_exist('这是测试目录')
        time.sleep(2)
        assert self.del_dir_name('这是测试目录')

    # CV-9417 应用-问答-新建问答时添加多个问题和答案
    def test_038_add_lots_question_answer(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        assert self.add_qa('自定义问答', '你今年多大了','我今年30岁了', '你今年几岁了啊', '我今年奔三十了呢')
        time.sleep(2)
        assert self.verify_qa_display_UI('自定义问答', '你今年多大了','我今年奔三十了呢')
        self.del_qa('自定义问答', '你今年多大了','我今年奔三十了呢')

    # CV-9416 应用-问答-新建问答时问题或答案输入特殊字符和空格
    def test_039_add_qa_spec_words(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        assert self.add_qa('自定义问答', '，。、；’’【】`~!@#$%^&*()', '!@#$%^&*()_+-=[]')
        time.sleep(2)
        assert self.verify_qa_display_UI('自定义问答', '，。、；’’【】`~!@#$%^&*()', '!@#$%^&*()_+-=[]')
        self.del_qa('自定义问答', '，。、；’’【】`~!@#$%^&*()', '!@#$%^&*()_+-=[]')

    # CV-9415 应用-问答-新建问答时不输入问题或答案无法新建成功
    def test_040_add_QA_no_question_answer(self):
        self.del_all_dirName()
        assert self.add_dirName('这是测试目录')
        time.sleep(2)
        assert self.verify_dirName_exist('这是测试目录')
        time.sleep(2)
        return_value = self.add_qa('自定义问答', '你今年多大了', '')
        print(return_value)
        assert return_value == False, "添加成功"
        return_value1 = self.add_qa('自定义问答', '', '我今年三十了')
        assert return_value1 == False, "添加成功"
        time.sleep(2)
        assert self.del_dir_name('这是测试目录')

    # CV-9409 应用-问答-默认问答目录中的问答对操作
    def test_041_default_dirName_operate(self):
        self.del_all_welcome_repeat_default_words('默认回答')
        time.sleep(2)
        self.add_welcome_repeat_default_words('默认回答', '这是香港')
        time.sleep(2)
        assert self.verify_answer_exist('默认回答', '这是香港')
        self.edit_welcome_repeat_default_words('默认回答', '这是香港', '这是台湾')
        time.sleep(2)
        assert self.verify_answer_exist('默认回答', '这是台湾')
        time.sleep(2)
        assert self.del_welcome_repeat_default_words('默认回答', '这是台湾')

    # CV-9410 应用-问答-重复提问回答目录中的问答对操作
    def test_042_default_dirName_operate(self):
        print('由于SV已经没有重复提问回答目录， 所以Pass')
        # self.del_all_welcome_repeat_default_words('重复提问回答')
        # time.sleep(2)
        # self.add_welcome_repeat_default_words('重复提问回答', '这是香港')
        # time.sleep(2)
        # assert self.verify_answer_exist('重复提问回答', '这是香港')
        # self.edit_welcome_repeat_default_words('重复提问回答', '这是香港', '这是台湾')
        # time.sleep(2)
        # assert self.verify_answer_exist('重复提问回答', '这是台湾')
        # time.sleep(2)
        # assert self.del_welcome_repeat_default_words('重复提问回答', '这是台湾')

    # CV-9412 应用-问答-开机语目录中的问答对操作
    def test_043_default_dirName_operate(self):
        self.del_all_welcome_repeat_default_words('开机语')
        time.sleep(2)
        self.add_welcome_repeat_default_words('开机语', '这是香港')
        time.sleep(2)
        assert self.verify_answer_exist('开机语', '这是香港')
        self.edit_welcome_repeat_default_words('开机语', '这是香港', '这是台湾')
        time.sleep(2)
        assert self.verify_answer_exist('开机语', '这是台湾')
        time.sleep(2)
        assert self.del_welcome_repeat_default_words('开机语', '这是台湾')

    # CV-9449 应用-问答-不同应用中的问答相互独立
    def test_044_send_QA_diff_agent(self):
        self.del_qa('自定义问答', '她今年多大了', '我今年30岁了')
        time.sleep(2)
        self.add_qa('自定义问答', '她今年多大了', '我今年30岁了')
        time.sleep(2)
        a, b, c = self.send_qa('她今年多大了', '我今年30岁了')
        print('b:', b)
        assert b == '我今年30岁了', "回答错误"
        time.sleep(2)
        ApplicationQAInterFace.__init__(self,constant.SV_USER, constant.SV_PWD, constant.agent_id1)
        self.add_qa('自定义问答', '她今年多大了', '我就不告诉你')
        time.sleep(2)
        d,e,f = self.send_qa('她今年多大了', '我就不告诉你')
        print('e:', e)
        assert e == '我就不告诉你', "回答错误"
        time.sleep(2)
        self.del_qa('自定义问答', '她今年多大了', '我今年30岁了')

    # CV-9428 应用-问答-编辑问答时新增问题和答案
    def test_045_edit_QA_add_QA(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        assert self.add_qa('自定义问答', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        group_id1 = self.get_qa_groupId('自定义问答', '你今年多大了', '我今年30岁了')
        assert self.edit_qa_lots('自定义问答', '你今年多大了', '我今年30岁了', '你今年多大了', '我今年30岁了', new_question2='你多大了哈', new_answer2='我还很年轻')
        time.sleep(2)
        group_id2 = self.get_qa_groupId('自定义问答', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        assert group_id1==group_id2, "组ID已经变化"
        self.del_qa('自定义问答', '你今年多大了', '我今年30岁了')

    # CV-9425 应用-问答-移动时更改选择的路径
    def test_046_qa_move(self):
        assert self.add_qa('自定义问答', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        assert self.add_dirName('这是测试目录')
        time.sleep(2)
        self.qa_move_one('自定义问答', '这是测试目录','你今年多大了', '我今年30岁了')
        time.sleep(2)
        assert self.verify_qa_display_UI('这是测试目录','你今年多大了', '我今年30岁了')
        time.sleep(2)
        self.del_dir_name('这是测试目录')
        print('开始自定义问答已经不存在了')
        time.sleep(3)
        value = self.verify_qa_display_UI('自定义问答', '你今年多大了', '我今年30岁了')
        assert value != True, "还存在该问题"

    # CV-9426 应用-问答-不选择任何路径移动
    def test_047_QA_move_NoPath(self):
        # 最好UI实现
        self.del_all_qa('自定义问答')
        time.sleep(2)
        self.del_all_dirName()
        time.sleep(2)
        assert self.add_qa('自定义问答', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        assert self.add_dirName('这是测试目录')
        time.sleep(2)
        value = self.qa_move_one_NoPATG('自定义问答', '这是测试目录', '你今年多大了', '我今年30岁了')
        print('value: ', value)
        assert value==False, "移动成功"

    # CV-9423 应用-问答-查看问答分类子分类下问答页面显示
    def test_048_dirName_type(self):
        self.del_all_dirName()
        time.sleep(2)
        self.del_dir_name('这是测试目录')
        time.sleep(2)
        assert self.add_dirName('这是测试目录')
        time.sleep(2)
        assert self.add_child_next_dir_name('这是测试目录', '二级目录')
        time.sleep(2)
        self.add_child_dirName_qa('这是测试目录', '二级目录', 'hello', 'world')
        time.sleep(2)
        assert self.verify_child_qa_display_UI('这是测试目录', '二级目录', 'hello', 'world')
        time.sleep(2)
        value = self.get_all_child_question_answer_dirName('这是测试目录', '二级目录')
        question = value[0]
        answer = value[1]
        assert 'hello' == question[0][0], "问题不相等"
        assert 'world' == answer[0][0], "问题不相等"
        time.sleep(2)
        self.del_child_dirName_name('这是测试目录', '二级目录')
        time.sleep(1)
        assert self.del_dir_name('这是测试目录')

    # CV-9383 应用 - 问答 - admin / master账号下默认问答目录 - 导出
    def test_049_master_download_default_QA(self):
        assert self.add_welcome_repeat_default_words('默认回答', '默认答案很好')
        assert self.add_welcome_repeat_default_words('默认回答', '默认答案不好')
        time.sleep(2)
        assert self.download_file('默认回答', 'default_test_file.xlsx')
        time.sleep(2)
        assert self.verify_data_In_excel('default_test_file.xlsx', answer='默认答案不好')
        time.sleep(1)
        assert self.verify_data_In_excel('default_test_file.xlsx', answer='默认答案很好')
        time.sleep(2)
        self.del_all_qa('默认回答')

    # CV-9384 应用-问答-admin/master账号下重复提问回答目录-导出
    def test_050_master_download_repeat_QA(self):
        print('由于SV已经没有重复提问回答目录， 所以Pass')
        # self.del_all_qa('重复提问回答')
        # assert self.add_welcome_repeat_default_words('重复提问回答', '重复回答很好')
        # assert self.add_welcome_repeat_default_words('重复提问回答', '重复回答不好')
        # time.sleep(2)
        # assert self.download_file('重复提问回答', 'repeat_test_file.xlsx')
        # time.sleep(2)
        # assert self.verify_data_In_excel('repeat_test_file.xlsx', answer='重复回答不好')
        # time.sleep(1)
        # assert self.verify_data_In_excel('repeat_test_file.xlsx', answer='重复回答很好')
        # time.sleep(2)
        # self.del_all_qa('重复提问回答')

    # CV-9389 应用 - 问答 - admin / master账号下开机语目录 - 导出
    def test_051_master_download_powerON_QA(self):
        self.del_all_qa('开机语')
        assert self.add_welcome_repeat_default_words('开机语', '开机语回答很好')
        assert self.add_welcome_repeat_default_words('开机语', '开机语回答不好')
        time.sleep(2)
        assert self.download_file('开机语', 'power_test_file.xlsx')
        time.sleep(2)
        assert self.verify_data_In_excel('power_test_file.xlsx', answer='开机语回答不好')
        time.sleep(1)
        assert self.verify_data_In_excel('power_test_file.xlsx', answer='开机语回答很好')
        time.sleep(2)
        self.del_all_qa('开机语')

    # CV-9388 应用 - 问答 - admin / master账号下迎宾语目录 - 导出
    def test_052_master_download_welcome_QA(self):
        self.del_all_qa('迎宾语')
        assert self.add_welcome_repeat_default_words('迎宾语', '迎宾语回答很好')
        assert self.add_welcome_repeat_default_words('迎宾语', '迎宾语回答不好')
        time.sleep(2)
        assert self.download_file('迎宾语', 'welcome_test_file.xlsx')
        time.sleep(2)
        assert self.verify_data_In_excel('welcome_test_file.xlsx', answer='迎宾语回答不好')
        time.sleep(1)
        assert self.verify_data_In_excel('welcome_test_file.xlsx', answer='迎宾语回答很好')
        time.sleep(2)
        self.del_all_qa('迎宾语')

    # CV-9387 应用 - 问答 - admin / master账号下自定义问答目录 - 导出
    def test_053_master_download_custom_QA(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        assert self.add_qa('自定义问答', '你是猪么','你才是猪')
        assert self.add_qa('自定义问答', '你是谁','我是中国人')
        time.sleep(2)
        assert self.download_file('自定义问答', 'custom_test_file.xlsx')
        time.sleep(2)
        assert self.verify_data_In_excel('custom_test_file.xlsx', question='你是猪么' ,answer='你才是猪')
        time.sleep(1)
        assert self.verify_data_In_excel('custom_test_file.xlsx', question='你是谁', answer='我是中国人')
        time.sleep(2)
        self.del_all_qa('自定义问答')

    # CV-9392 应用 - 问答 - admin / master账号下用户自定义自创目录 - 导出
    def test_054_master_download_user_defined_QA(self):
        self.del_all_dirName()
        time.sleep(2)
        assert self.add_dirName('这是测试目录')
        time.sleep(2)
        assert self.add_qa('这是测试目录', '你是猪么', '你才是猪')
        assert self.add_qa('这是测试目录', '你是谁', '我是中国人')
        time.sleep(2)
        assert self.download_file('这是测试目录', 'user_defined_test_file.xlsx')
        time.sleep(2)
        assert self.verify_data_In_excel('user_defined_test_file.xlsx', question='你是猪么', answer='你才是猪')
        time.sleep(1)
        assert self.verify_data_In_excel('user_defined_test_file.xlsx', question='你是谁', answer='我是中国人')
        time.sleep(2)
        self.del_all_dirName()

    # CV-9451 应用 - 问答 - 下载导入模板
    def test_055_download_import_temp_file(self):
        assert self.download_file_template()
        time.sleep(2)
        print('开始验证excel数据')
        assert self.verify_data_In_excel('file_template.xlsx', question='问题(多个问题以&&隔开,每个问题如果有关键字需要使用||和问题分开,多个关键字用英文逗号分割)', answer='答案(多个答案以&&隔开)')

    # CV-9399 应用-问答-slave账号下默认问答目录-导出
    def test_056_slave_download_default_QA(self):
        ApplicationQAInterFace.__init__(self, constant.SV_SLAVE, constant.SV_SLAVE_PWD, constant.agent_id)
        self.del_all_qa('默认回答')
        time.sleep(2)
        assert self.add_welcome_repeat_default_words('默认回答', 'slave默认答案很好')
        assert self.add_welcome_repeat_default_words('默认回答', 'slave默认答案不好')
        time.sleep(2)
        assert self.download_file('默认回答', 'default_test_file.xlsx')
        time.sleep(2)
        assert self.verify_data_In_excel('default_test_file.xlsx', answer='slave默认答案不好')
        time.sleep(1)
        assert self.verify_data_In_excel('default_test_file.xlsx', answer='slave默认答案很好')
        time.sleep(2)
        self.del_all_qa('默认回答')

    # CV-9400 应用-问答-slave账号下重复提问回答目录-导出
    def test_057_slave_download_repeat_QA(self):
        print('由于SV已经没有重复提问回答目录， 所以Pass')
        # ApplicationQAInterFace.__init__(self, constant.SV_SLAVE, constant.SV_SLAVE_PWD, constant.agent_id)
        # assert self.add_welcome_repeat_default_words('重复提问回答', 'slave重复回答很好')
        # assert self.add_welcome_repeat_default_words('重复提问回答', 'slave重复回答不好')
        # time.sleep(2)
        # assert self.download_file('重复提问回答', 'repeat_test_file.xlsx')
        # time.sleep(2)
        # assert self.verify_data_In_excel('repeat_test_file.xlsx', answer='slave重复回答不好')
        # time.sleep(1)
        # assert self.verify_data_In_excel('repeat_test_file.xlsx', answer='slave重复回答很好')
        # time.sleep(2)
        # self.del_all_qa('重复提问回答')

    # CV-9404 应用-问答-slave账号下迎宾语目录-导出
    def test_058_slave_download_welcome_QA(self):
        ApplicationQAInterFace.__init__(self, constant.SV_SLAVE, constant.SV_SLAVE_PWD, constant.agent_id)
        assert self.add_welcome_repeat_default_words('迎宾语', 'slave迎宾语回答很好')
        assert self.add_welcome_repeat_default_words('迎宾语', 'slave迎宾语回答不好')
        time.sleep(2)
        assert self.download_file('迎宾语', 'welcome_test_file.xlsx')
        time.sleep(2)
        assert self.verify_data_In_excel('welcome_test_file.xlsx', answer='slave迎宾语回答不好')
        time.sleep(1)
        assert self.verify_data_In_excel('welcome_test_file.xlsx', answer='slave迎宾语回答很好')
        time.sleep(2)
        self.del_all_qa('迎宾语')

    # CV-9405 应用-问答-slave账号下开机语目录-导出
    def test_059_slave_download_powerON_QA(self):
        ApplicationQAInterFace.__init__(self, constant.SV_SLAVE, constant.SV_SLAVE_PWD, constant.agent_id)
        assert self.add_welcome_repeat_default_words('开机语', 'slave开机语回答很好')
        assert self.add_welcome_repeat_default_words('开机语', 'slave开机语回答不好')
        time.sleep(2)
        assert self.download_file('开机语', 'power_test_file.xlsx')
        time.sleep(2)
        assert self.verify_data_In_excel('power_test_file.xlsx', answer='slave开机语回答不好')
        time.sleep(1)
        assert self.verify_data_In_excel('power_test_file.xlsx', answer='slave开机语回答很好')
        time.sleep(2)
        self.del_all_qa('开机语')

    # CV-9403 应用-问答分类-slave账号下自定义问答目录-导出
    def test_060_slave_download_custom_QA(self):
        ApplicationQAInterFace.__init__(self, constant.SV_SLAVE, constant.SV_SLAVE_PWD, constant.agent_id)
        self.del_all_qa('自定义问答')
        time.sleep(2)
        assert self.add_qa('自定义问答', 'slave你是猪么', '你才是猪')
        assert self.add_qa('自定义问答', 'slave你是谁', '我是中国人')
        time.sleep(2)
        assert self.download_file('自定义问答', 'custom_test_file.xlsx')
        time.sleep(2)
        assert self.verify_data_In_excel('custom_test_file.xlsx', question='slave你是猪么', answer='你才是猪')
        time.sleep(1)
        assert self.verify_data_In_excel('custom_test_file.xlsx', question='slave你是谁', answer='我是中国人')
        time.sleep(2)
        self.del_all_qa('自定义问答')

    # CV-9407 应用-问答-slave账号下用户自定义自创目录-导出
    def test_061_slave_download_user_defined_QA(self):
        self.del_all_dirName()
        assert self.add_dirName('slave这是测试目录')
        time.sleep(2)
        assert self.add_qa('slave这是测试目录', 'slave你是猪么', '你才是猪')
        time.sleep(1)
        assert self.add_qa('slave这是测试目录', 'slave你是谁', '我是中国人')
        time.sleep(2)
        ApplicationQAInterFace.__init__(self, constant.SV_SLAVE, constant.SV_SLAVE_PWD, constant.agent_id)
        time.sleep(2)
        assert self.download_file('slave这是测试目录', 'user_defined_test_file.xlsx')
        time.sleep(2)
        assert self.verify_data_In_excel('user_defined_test_file.xlsx', question='slave你是猪么', answer='你才是猪')
        time.sleep(1)
        assert self.verify_data_In_excel('user_defined_test_file.xlsx', question='slave你是谁', answer='我是中国人')
        time.sleep(2)
        ApplicationQAInterFace.__init__(self, constant.SV_USER, constant.SV_PWD, constant.agent_id1)
        self.del_all_dirName()

    # CV-9395 应用-问答分类-slave账号系统分类/根目录下没有操作权限
    def test_062_slave_operate_add_dirName(self):
        ApplicationQAInterFace.__init__(self, constant.SV_SLAVE, constant.SV_SLAVE_PWD, constant.agent_id)
        self.del_all_dirName()
        time.sleep(2)
        value = self.add_dirName('这是测试目录')
        print('value: ', value)
        assert value==False, "新增目录成功"

    # CV-9401 应用-问答-slave账号下自定义问答目录-没有新建子分类功能
    def test_063_slave_operate_add_child_dirName(self):
        ApplicationQAInterFace.__init__(self, constant.SV_SLAVE, constant.SV_SLAVE_PWD, constant.agent_id)
        value = self.add_child_next_dir_name('自定义问答', '这是测试目录')
        print('value: ', value)
        assert value==False, "新增目录成功"

    # CV-9377 应用-问答-master账号下默认分配的问答分类-普通应用(非system应用)
    def test_064_master_display_dirName(self):
        self.del_all_dirName()
        time.sleep(2)
        list_dirName = self.get_agent_all_dirName_name()
        print('list_dirName: ',list_dirName)
        real_dirName = ['默认回答', '自定义问答', '迎宾语', '开机语']
        for i in range(len(list_dirName)):
            print('开始比对：', list_dirName[i], ',||,', real_dirName[i])
            assert list_dirName[i] == real_dirName[i]

    # CV-9376 应用-问答-默认分配的问答分类-system应用
    def test_065_admin_display_dirName(self):
        ApplicationQAInterFace.__init__(self, constant.SV_ADMIN, constant.SV_ADMIN_PWD, 1)
        list_dirName = self.get_agent_all_dirName_name()
        print('list_dirName: ', list_dirName)
        real_dirName = ['默认回答', '自定义问答', '系统抓取', 'Japan', '迎宾语', '开机语']
        # for i in range(len(list_dirName)):
        for i in range(len(real_dirName)):
            print('开始比对：', list_dirName[i], ',||,', real_dirName[i])
            assert list_dirName[i] == real_dirName[i]

    # CV-9379 应用-问答-admin/master账号系统分类/根目录下不能新建问答对
    def test_066_parent_Not_add_QA(self):
        value = self.add_qa('根目录','111','222')
        assert value==False, "新建答案成功"

    # CV-9408 应用-问答-预置目录的问答对移动规则
    def test_067_dirName_move_rule(self):
        assert self.add_welcome_repeat_default_words('默认回答', '默认')
        assert self.add_welcome_repeat_default_words('迎宾语', '迎宾')
        assert self.add_welcome_repeat_default_words('开机语', '开机')
        assert self.add_qa('自定义问答', '测试','测不测试')
        time.sleep(2)
        assert self.answer_move_one('迎宾语', '开机语', '迎宾') == False, "移动成功"
        assert self.answer_move_one('开机语', '迎宾语', '开机') == False, "移动成功"
        time.sleep(2)
        assert self.qa_move_one('自定义问答', '默认回答','测试','测不测试')==False
        assert self.qa_move_one('自定义问答', '迎宾语', '测试', '测不测试') == False
        assert self.qa_move_one('自定义问答', '开机语', '测试', '测不测试') == False
        time.sleep(2)
        self.add_dirName('这是测试目录')
        time.sleep(2)
        self.add_qa('这是测试目录', 'aa','bb')
        time.sleep(2)
        assert self.qa_move_one('这是测试目录', '开机语', 'aa','bb') == False
        self.del_all_dirName()
        self.del_all_qa('默认回答')
        self.del_all_qa('迎宾语')
        self.del_all_qa('开机语')

    # CV-9380 应用-问答-admin/master账号系统分类/根目录下移动已存在的以前的遗留问答对数据
    def test_068_move_qa(self):
        self.add_dirName('测试目录')
        time.sleep(2)
        self.add_qa('测试目录', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        assert self.verify_qa_display_UI('测试目录', '你今年多大了', '我今年30岁了')
        assert self.qa_move_one('测试目录', '自定义问答','你今年多大了', '我今年30岁了')
        time.sleep(2)
        assert self.verify_qa_display_UI('自定义问答', '你今年多大了', '我今年30岁了')
        assert self.verify_qa_display_UI('测试目录', '你今年多大了', '我今年30岁了')==False
        time.sleep(2)
        self.del_all_qa('自定义问答')
        self.del_all_dirName()

    # CV-9381 应用-问答-admin/master账号系统分类/根目录下编辑已存在的以前的遗留问答对数据
    def test_069_edit_qa(self):
        self.add_dirName('测试目录')
        time.sleep(2)
        self.add_qa('测试目录', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        self.edit_qa_lots('测试目录', '你今年多大了', '我今年30岁了', '你是谁', '我是谁')
        time.sleep(2)
        assert self.verify_qa_display_UI('测试目录', '你是谁', '我是谁')
        assert self.verify_qa_display_UI('测试目录', '你今年多大了', '我今年30岁了')==False
        self.del_all_qa('测试目录')
        self.del_all_dirName()

    # CV-9382 应用-问答-admin/master账号系统分类/根目录下删除已存在的以前的遗留问答对数据
    def test_070_del_qa(self):
        self.del_all_qa('测试目录')
        self.del_all_dirName()
        time.sleep(2)
        self.add_dirName('测试目录')
        time.sleep(2)
        self.add_qa('测试目录', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        assert self.del_qa('测试目录', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        assert self.verify_qa_display_UI('测试目录', '你今年多大了', '我今年30岁了') == False
        self.del_all_dirName()

    # CV-9396 应用-问答-slave账号系统分类/根目录下移动已存在的以前的遗留问答对数据
    def test_071_slave_move_qa(self):
        self.del_all_qa('测试目录')
        self.del_all_dirName()
        time.sleep(2)
        self.add_dirName('测试目录')
        time.sleep(2)
        self.add_qa('测试目录', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        ApplicationQAInterFace.__init__(self, constant.SV_SLAVE, constant.SV_SLAVE_PWD, constant.agent_id)
        assert self.verify_qa_display_UI('测试目录', '你今年多大了', '我今年30岁了')
        assert self.qa_move_one('测试目录', '自定义问答', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        assert self.verify_qa_display_UI('自定义问答', '你今年多大了', '我今年30岁了'), "QA移动失败"
        assert self.verify_qa_display_UI('测试目录', '你今年多大了', '我今年30岁了') == False, "QA移动失败"

    # CV-9397 应用-问答-slave账号系统分类/根目录下编辑已存在的以前的遗留问答对数据
    def test_072_slave_edit_qa(self):
        ApplicationQAInterFace.__init__(self, constant.SV_USER, constant.SV_PWD, constant.agent_id)
        self.del_all_qa('自定义问答')
        self.del_all_dirName()
        time.sleep(2)
        self.add_dirName('测试目录')
        time.sleep(2)
        self.add_qa('测试目录', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        ApplicationQAInterFace.__init__(self, constant.SV_SLAVE, constant.SV_SLAVE_PWD, constant.agent_id)
        self.edit_qa_lots('测试目录', '你今年多大了', '我今年30岁了', '你是谁', '我是谁')
        time.sleep(2)
        assert self.verify_qa_display_UI('测试目录', '你是谁', '我是谁'), "没有找到该问答对"
        assert self.verify_qa_display_UI('测试目录', '你今年多大了', '我今年30岁了') == False, "问答对编辑删除失败"

    # CV-9398 应用-问答-slave账号系统分类/根目录下删除已存在的以前的遗留问答对数据
    def test_073_slave_del_qa(self):
        ApplicationQAInterFace.__init__(self, constant.SV_SLAVE, constant.SV_SLAVE_PWD, constant.agent_id)
        self.del_all_qa('测试目录')
        self.del_all_dirName()
        time.sleep(2)
        self.add_qa('自定义问答', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        assert self.del_qa('自定义问答', '你今年多大了', '我今年30岁了')
        time.sleep(2)
        assert self.verify_qa_display_UI('自定义问答', '你今年多大了', '我今年30岁了') == False

    # CV-9440 应用-问答-批量删除时取消
    def test_074_batch_del_and_cancel(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        self.add_dirName('测试')
        time.sleep(2)
        self.add_qa('自定义问答', '你是哪个国家的', '我是中国人')
        self.add_qa('自定义问答', '你喜欢美国么', '你才喜欢猪呢')
        time.sleep(2)
        self.login_to_agent()
        self.enter_agent_QA_dirName()
        self.click_qa_dirName()
        self.click_qa_checkbox('你是哪个国家的')
        self.click_qa_checkbox('你喜欢美国么')
        self.lots_del()
        self.click_cancel_button()
        time.sleep(2)
        assert self.verify_qa_display_UI('自定义问答', '你是哪个国家的', '我是中国人')
        assert self.verify_qa_display_UI('自定义问答', '你喜欢美国么', '你才喜欢猪呢')

    # CV-9438 应用-问答分类-批量移动时取消
    def test_075_batch_move_and_cancel(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        self.add_dirName('测试')
        time.sleep(2)
        self.add_qa('自定义问答', '你是哪个国家的', '我是中国人')
        self.add_qa('自定义问答', '你喜欢美国么', '你才喜欢猪呢')
        time.sleep(2)
        self.login_to_agent()
        self.enter_agent_QA_dirName()
        self.click_qa_dirName()
        self.click_qa_checkbox('你是哪个国家的')
        self.click_qa_checkbox('你喜欢美国么')
        self.choose_dirName_move('测试')
        self.click_cancel_button()
        time.sleep(2)
        assert self.verify_qa_display_UI('自定义问答', '你是哪个国家的', '我是中国人')
        assert self.verify_qa_display_UI('自定义问答', '你喜欢美国么', '你才喜欢猪呢')
        assert self.verify_qa_display_UI('测试', '你是哪个国家的', '我是中国人')==False
        assert self.verify_qa_display_UI('测试', '你喜欢美国么', '你才喜欢猪呢')==False

    # CV-9437 应用-问答-批量移动
    def test_076_batch_move(self):
        self.del_all_qa('自定义问答')
        self.del_all_dirName()
        time.sleep(2)
        assert self.add_dirName('移动目录')
        self.add_qa('自定义问答', '你是哪个国家的', '我是中国人')
        self.add_qa('自定义问答', '你喜欢美国么', '你才喜欢猪呢')
        self.add_qa('自定义问答', '你是中国人吗', '我是')
        assert self.qa_move('自定义问答','移动目录', '你是哪个国家的', '我是中国人', q2='你喜欢美国么',a2='你才喜欢猪呢',q3='你是中国人吗',a3='我是')
        time.sleep(2)
        assert self.verify_qa_display_UI('移动目录', '你是哪个国家的', '我是中国人')
        assert self.verify_qa_display_UI('移动目录', '你喜欢美国么', '你才喜欢猪呢')
        assert self.verify_qa_display_UI('移动目录', '你是中国人吗', '我是')
        assert self.verify_qa_display_UI('自定义问答', '你是哪个国家的', '我是中国人')==False
        assert self.verify_qa_display_UI('自定义问答', '你喜欢美国么', '你才喜欢猪呢')==False
        assert self.verify_qa_display_UI('自定义问答', '你是中国人吗', '我是')==False

    # CV-9413 应用-问答-自定义问答目录中的问答对操作
    def test_077_user_defined_qa_operate(self):
        self.del_all_qa('自定义问答')
        self.del_all_dirName()
        time.sleep(2)
        self.add_dirName('移动目录')
        time.sleep(2)
        assert self.add_qa('自定义问答', '你是哪个国家的', '我是中国人') # 单个移动
        assert self.add_qa('自定义问答', '你喜欢美国么', '你才喜欢猪呢') # 批量移动
        assert self.add_qa('自定义问答', '你是中国人吗', '我是') # 编辑
        assert self.add_qa('自定义问答', '你是谁呢', '我不告诉你') # 批量移动
        time.sleep(2)
        assert self.edit_qa_lots('自定义问答', '你是中国人吗', '我是', '你是中国哪个地方的', '我是南方人')
        time.sleep(2)
        assert self.verify_qa_display_UI('自定义问答', '你是中国哪个地方的', '我是南方人')
        assert self.verify_qa_display_UI('自定义问答', '你是中国人吗', '我是')==False
        time.sleep(2)
        assert self.qa_move('自定义问答', '移动目录','你是哪个国家的', '我是中国人')
        assert self.verify_qa_display_UI('移动目录', '你是哪个国家的', '我是中国人')
        assert self.verify_qa_display_UI('自定义问答', '你是哪个国家的', '我是中国人') == False
        assert self.qa_move('自定义问答', '移动目录', '你喜欢美国么', '你才喜欢猪呢', q2='你是谁呢', a2='我不告诉你')
        time.sleep(2)
        assert self.verify_qa_display_UI('移动目录', '你喜欢美国么', '你才喜欢猪呢')
        assert self.verify_qa_display_UI('移动目录', '你是谁呢', '我不告诉你')
        assert self.verify_qa_display_UI('自定义问答',  '你喜欢美国么', '你才喜欢猪呢')==False
        assert self.verify_qa_display_UI('自定义问答', '你是谁呢', '我不告诉你')==False
        time.sleep(2)
        assert self.del_qa('自定义问答', '你是中国哪个地方的', '我是南方人')
        time.sleep(2)
        assert self.verify_qa_display_UI('自定义问答', '你是中国哪个地方的', '我是南方人')==False

    # CV-9414 应用-问答-用户自己创建目录中的问答对操作
    def test_078_user_custom_qa_operate(self):
        self.del_all_qa('自定义问答')
        self.del_all_dirName()
        time.sleep(2)
        self.add_dirName('测试目录')
        time.sleep(2)
        assert self.add_qa('测试目录', '你是哪个国家的', '我是中国人')  # 单个移动
        assert self.add_qa('测试目录', '你喜欢美国么', '你才喜欢猪呢')  # 批量移动
        assert self.add_qa('测试目录', '你是中国人吗', '我是')  # 编辑
        assert self.add_qa('测试目录', '你是谁呢', '我不告诉你')  # 批量移动
        time.sleep(2)
        assert self.edit_qa_lots('测试目录', '你是中国人吗', '我是', '你是中国哪个地方的', '我是南方人')
        time.sleep(2)
        assert self.verify_qa_display_UI('测试目录', '你是中国哪个地方的', '我是南方人')
        assert self.verify_qa_display_UI('测试目录', '你是中国人吗', '我是') == False
        time.sleep(2)
        assert self.qa_move('测试目录', '自定义问答', '你是哪个国家的', '我是中国人')
        assert self.verify_qa_display_UI('自定义问答', '你是哪个国家的', '我是中国人')
        assert self.verify_qa_display_UI('测试目录', '你是哪个国家的', '我是中国人') == False
        assert self.qa_move('测试目录', '自定义问答', '你喜欢美国么', '你才喜欢猪呢', q2='你是谁呢', a2='我不告诉你')
        time.sleep(2)
        assert self.verify_qa_display_UI('自定义问答', '你喜欢美国么', '你才喜欢猪呢')
        assert self.verify_qa_display_UI('自定义问答', '你是谁呢', '我不告诉你')
        assert self.verify_qa_display_UI('测试目录', '你喜欢美国么', '你才喜欢猪呢') == False
        assert self.verify_qa_display_UI('测试目录', '你是谁呢', '我不告诉你') == False
        time.sleep(2)
        assert self.del_qa('测试目录', '你是中国哪个地方的', '我是南方人')
        assert self.verify_qa_display_UI('测试目录', '你是中国哪个地方的', '我是南方人') == False

    # CV-9422 应用-问答-查看问答页面显示
    def test_079_UI_display_dirName(self):
        self.del_all_qa('自定义问答')
        time.sleep(2)
        self.add_qa('自定义问答', '你今年多大了', '我今年30岁了', keywords='今年多大')
        time.sleep(2)
        self.del_all_dirName()
        time.sleep(2)
        list_dirName = self.get_agent_all_dirName_name()
        print('list_dirName: ', list_dirName)
        real_dirName = ['默认回答', '自定义问答', '迎宾语', '开机语']
        for i in range(len(list_dirName)):
            print('开始比对：', list_dirName[i], ',||,', real_dirName[i])
            assert list_dirName[i] == real_dirName[i]
        assert self.verify_qa_display_UI('自定义问答', '你今年多大了', '我今年30岁了')
        assert self.get_qa_keywords('自定义问答', '你今年多大了', '我今年30岁了')=='今年多大', "标签不一致"
        time.sleep(2)
        self.add_welcome_repeat_default_words('默认回答', '默认回答')
        self.add_welcome_repeat_default_words('迎宾语', '迎宾语')
        self.add_welcome_repeat_default_words('开机语', '开机语')
        time.sleep(2)
        assert self.verify_answer_exist('默认回答', '默认回答')
        assert self.verify_answer_exist('迎宾语', '迎宾语')
        assert self.verify_answer_exist('开机语', '开机语')
        time.sleep(2)
        self.login_to_agent()
        self.enter_agent_QA_dirName()
        self.click_qa_dirName()
        content = self.verify_UI_exist_element('你今年多大了')
        print('content: ', content)
        list = ['移动', '编辑', '删除']
        for i in list:
            assert i in content
        time.sleep(2)
        self.del_all_qa('自定义问答')
        time.sleep(2)
        for a in real_dirName:
            self.del_all_qa(a)
        print("这轮CASES执行结束...")

# if __name__ == "__main__":
#     p = TestApplicationQA()
#     print(p.test_012_edit_add_keywords())


