#!/usr/bin/env python
# coding=utf-8

from lib.modules.Application import Application
from lib.modules.Base import Base
from lib.uilocators import uilocators
from lib.utils import constant
import logging as logger
import os
import time
import requests
import json

class TestApplicationIndustrylibrary(Application):
    def test_open_industry_library(self):
        self.open_application_default()
    def select_industry_library(self):
        self.selib.click_element(uilocators.nav_applicaiton_tab_faq)
        self.selib.click_element(uilocators.app_industry_library)
    def verify_industry_field(self,text):
        assert self.wait_page_contains(text, 10)
    def get_question(self):
        self.click_locator(uilocators.industry_qa_span)
        question = self.get_text_from_webelements(uilocators.industry_question_text)
        return question

    def verify_available(self):
        # question = self.get_question()
        question = '发起测试命中率是多少'
        self.open_industry_button()
        source = self.get_sv_response_source_industry(question)
        print(source)
        assert source == 'common_sense_qa',"打开功能失败，答案来自第三方闲聊库"
    def verify_not_available(self):
        # question = self.get_question()
        question = '苹果多少钱一斤'
        # self.click_locator(uilocators.industry_qa_span_button)
        self.off_industry_button()
        source = self.get_sv_response_source_industry(question)
        assert source != 'common_sense_qa', "关闭功能失败，答案来自问答库"
    def off_industry_button(self):
        interface = Base(constant.SV_USER, constant.SV_PWD)
        # interface.get_sv_authinfo(121)  # 登录拿到所有的登陆后的authinfo 默认是121
        interface.get_sv_authinfo(constant.dont_modify_agent_id)
        url = "/v2/ux/agents/"+str(constant.dont_modify_agent_id)+"/faq/manage/types/4/off?typeid=4"
        para = {"params": {'page': 1, 'pagesize': 10}}
        interface.sv_request(url=url, method='GET', parameter=para, pattern='')
    def open_industry_button(self):
        interface = Base(constant.SV_USER, constant.SV_PWD)
        # interface.get_sv_authinfo(121)  # 登录拿到所有的登陆后的authinfo 默认是121
        interface.get_sv_authinfo(constant.dont_modify_agent_id)
        url = "/v2/ux/agents/"+str(constant.dont_modify_agent_id)+"/faq/manage/types/4/on?typeid=4"
        para = {"params": {'page': 1, 'pagesize': 10}}
        interface.sv_request(url=url, method='GET', parameter=para, pattern='')

    def get_sv_response_source_industry(self,question):
        interface = Base(constant.SV_USER, constant.SV_PWD)
        # interface.get_sv_authinfo(121)
        interface.get_sv_authinfo(constant.dont_modify_agent_id)
        sv_response = interface.question_test(question)
        if sv_response:
            response_text =json.loads(sv_response['answer'])['source']
            return response_text
        else:
            print("Sv has no any result")
            return False
