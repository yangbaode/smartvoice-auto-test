#!/usr/bin/env python
# coding=utf-8

from lib.modules.ServiceManagement import ServiceManagement
from lib.utils import constant
from lib.uilocators import uilocators
import time

class TestServiceManagement(ServiceManagement):

    def login_sv(self,user=constant.SV_USER, password=constant.SV_PWD):
        self.login_smartvoice(user=user, password=password)

    def logout_sv(self):
        self.close_chrome_browser()

    def test_application_service_management(self):
        # CV-9297
        self.goto_application_by_name(constant.agent_name_beller)
        self.enter_service_management_page()
        assert (self.wait_element_visible(uilocators.nav_applicaiton_intention_service_management_selfdefine_service) and self.wait_element_visible(uilocators.nav_applicaiton_intention_service_management_system_service))

    def test_application_service_management_view_custom_service_details(self):
        # CV-9298
        self.create_domain("autotest","This is for auto test")
        self.goto_application_by_name(constant.agent_name_beller)
        self.enter_service_management_page()
        self.wait_and_click_element_at_coordinates_if_available(uilocators.selfdefine_service_details_btn)
        res1 = self.wait_element_visible(uilocators.selfdefine_service_description_info)
        print("res1 is %s"%res1)
        res2 = self.wait_element_visible(uilocators.selfdefine_service_details_cancel_btn)
        print("res2 is %s" % res2)
        self.delete_domain_by_domain_name('autotest')
        assert (res1 and res2)

    def test_application_service_management_start_deactivate_custom_services(self):
        # CV-9299
        self.create_domain("autotest", "This is for auto test")
        self.goto_application_by_name(constant.agent_name_beller)
        self.enter_service_management_page()
        self.wait_and_click_element_at_coordinates_if_available(uilocators.selfdefine_service_open_btn)
        time.sleep(3)
        res1 = self.wait_element_visible(uilocators.selfdefine_service_close_btn)
        print("res1 is %s" % res1)
        self.wait_and_click_element_at_coordinates_if_available(uilocators.selfdefine_service_close_btn)
        time.sleep(3)
        res2 = self.wait_element_visible(uilocators.selfdefine_service_open_btn)
        print("res2 is %s" % res2)
        self.delete_domain_by_domain_name('autotest')
        assert (res1 and res2)

    def test_application_service_management_view_system_service_details(self):
        # CV-9300
        self.goto_application_by_name(constant.agent_name_beller)
        self.enter_service_management_page()
        self.wait_and_click_element_at_coordinates_if_available(uilocators.system_service_detail_btn%"weather")
        assert self.wait_element_visible(uilocators.system_service_detail_weather_info)

    def test_application_service_management_start_deactivate_system_services(self):
        # CV-9301
        self.enable_domain_by_name("0","currency")
        ret1 = self.get_domain_status_by_name("0","currency")
        print(ret1)
        assert ret1
        ret2 = self.get_sv_response_tts_text("1美元兑换人民币")
        print(ret2)
        assert ("1美元=" in ret2 or "1人民币=" in ret2)
        self.disenable_domain_by_name("0", "currency")
        ret3 = self.get_domain_status_by_name("0", "currency")
        print(ret3)
        assert not ret3
        ret4 = self.get_sv_response_tts_text("1美元兑换人民币")
        print(ret4)
        self.enable_domain_by_name("0", "currency")
        assert "1美元=" not in ret4

    def test_application_service_management_search(self):
        # CV-9302
        self.create_domain("autotest", "This is for auto test")
        self.goto_application_by_name(constant.agent_name_beller)
        self.enter_service_management_page()
        self.selib.input_text(uilocators.system_service_search_input,"This is for auto test")
        self.wait_and_click_element_at_coordinates_if_available(uilocators.system_service_search_input_search_icon)
        ret1 = self.wait_element_visible(uilocators.selfdefine_service_details_btn)
        self.delete_domain_by_domain_name('autotest')
        assert ret1
        self.selib.input_text(uilocators.system_service_search_input, "weather")
        ret2 = self.wait_element_visible(uilocators.system_service_weather)
        assert ret2

    def test_application_service_system_chinese_environment(self):
        # CV-9303
        self.enable_domain_by_name("0", "system")
        ret1 = self.get_sv_response_source("查询当前音量")
        ret2 = self.get_sv_response_source("大点声")
        ret3 = self.get_sv_response_source("小点声")
        ret4 = self.get_sv_response_source("静音")
        ret5 = self.get_sv_response_source("取消静音")
        # self.disenable_domain_by_name("0", "system")
        assert (
                ret1 == "system_service" and ret2 == "system_service" and ret3 == "system_service" and ret4 == "system_service" and ret5 == "system_service")

    def test_application_service_system_english_environment(self):
        # CV-9304
        self.enable_domain_by_name("0", "system")
        ret1 = self.get_sv_response_source("show current volume")
        ret2 = self.get_sv_response_source("volume up")
        ret3 = self.get_sv_response_source("volume down")
        ret4 = self.get_sv_response_source("mute")
        ret5 = self.get_sv_response_source("cancel mute")
        self.disenable_domain_by_name("0", "system")
        assert (
                ret1 == "system_service" and ret2 == "system_service" and ret3 == "system_service" and ret4 == "system_service" and ret5 == "system_service")

    def test_application_service_system_japanese_environment(self):
        # CV-9305
        self.enable_domain_by_name("0", "system")
        ret1 = self.get_sv_response_source("現在の音量を取得する")
        ret2 = self.get_sv_response_source("ボリュームアップしてください")
        ret3 = self.get_sv_response_source("ボリュームダウン")
        ret4 = self.get_sv_response_source("静かに")
        # self.disenable_domain_by_name("0", "system")
        assert (
                ret1 == "system_service" and ret2 == "system_service" and ret3 == "system_service" and ret4 == "system_service")

    def test_application_service_mobile_move(self):
        # CV-9306
        self.enable_domain_by_name("0", "move")
        ret1 = self.get_sv_response_source("向右一米")
        # self.disenable_domain_by_name("0", "move")
        assert ret1 =="system_service"

    def test_application_services_common_actions_and_dance_dance_chinese(self):
        # CV-9307
        self.enable_domain_by_name("0", "dance_pepper")
        # ret1 = self.get_sv_response_action("跳个舞吧")
        # ret2 = self.get_sv_response_action("跳舞")
        ret1 = self.get_sv_response_action_dance("跳个舞吧")
        ret2 = self.get_sv_response_action_dance("跳舞")
        ret3 = self.get_sv_response_action("停止")
        ret4 = self.get_sv_response_action("碰个拳吧")
        ret5 = self.get_sv_response_action("我们一起合影吧")
        ret6 = self.get_sv_response_action("合个影吧")
        ret7 = self.get_sv_response_action("拍个照吧")
        ret8 = self.get_sv_response_action("拥抱一下")
        ret9 = self.get_sv_response_action("握握手")
        ret10 = self.get_sv_response_action("握个手吧")
        ret11 = self.get_sv_response_action_dance_text("跳个舞吧")
        ret12 = self.get_sv_response_action_dance_text("跳舞")
        # self.disenable_domain_by_name("0", "dance_pepper")
        print("----",ret1,ret2,ret3,ret4,ret5,ret6,ret7,ret8,ret9,ret10,ret11,ret12)
        assert (
                ret1 == "dance" and ret2 == "dance" and ret3 == "dance" and ret4 == "dance" and ret5 == "dance"
                and ret6 == "dance" and ret7 == "dance" and ret8 == "dance" and ret9 == "dance" and ret10 == "dance" and ret11 == "表演即将开始" and ret12 == "表演即将开始")

    def test_application_services_common_actions_and_dance_dance_english(self):
        # CV-9308
        self.enable_domain_by_name("0", "dance_pepper")
        # ret1 = self.get_sv_response_action("please dance")
        ret1 = self.get_sv_response_action_dance("please dance")
        ret2 = self.get_sv_response_action("shake hands")
        ret3 = self.get_sv_response_action("give a hug")
        ret4 = self.get_sv_response_action("fistbump")
        # ret5 = self.get_sv_response_action_dance_text("please dance")#回复是中文，开发说不是问题  and ret5 == "I am going to dance"
        # ret5 = self.get_sv_response_action("naughty")  #该字段有问题，没有返回值，SV为给回复，FO未给答复
        # self.disenable_domain_by_name("0", "dance_pepper")
        assert (
                ret1 == "dance" and ret2 == "dance" and ret3 == "dance" and ret4 == "dance")

    def test_application_services_common_actions_and_dance_dance_japanese(self):
        # CV-9309
        self.enable_domain_by_name("0", "dance_pepper")
        # ret1 = self.get_sv_response_action("踊ってください")
        ret1 = self.get_sv_response_action_dance("踊ってください")
        ret2 = self.get_sv_response_action("握手 しよう")
        ret3 = self.get_sv_response_action("ハグ しよう")
        #ret4 = self.get_sv_response_action("いたずら") #该字段有问题，没有返回值，SV为给回复，FO未给答复
        ret5 = self.get_sv_response_action("グータッチ しよう")
        # ret6 = self.get_sv_response_action_dance_text("踊ってください")#回复是中文，开发说不是问题   and ret6 == "踊ります"
        # self.disenable_domain_by_name("0", "dance_pepper")
        assert (
                ret1 == "dance" and ret2 == "dance" and ret3 == "dance" and ret5 == "dance")

    def test_application_service_system_action(self):
        # CV-9310
        self.enable_domain_by_name("0", "dance_pepper")
        # ret1 = self.get_sv_response_action("跳个舞吧")
        ret1 = self.get_sv_response_action_dance("跳个舞吧")
        ret2 = self.get_sv_response_action("停止")
        ret3 = self.get_sv_response_action("碰个拳吧")
        ret4 = self.get_sv_response_action("我们一起合影吧")
        ret5 = self.get_sv_response_action("拥抱一下")
        ret6 = self.get_sv_response_action("握握手")
        ret7 = self.get_sv_response_action_dance_text("跳个舞吧")
        # self.disenable_domain_by_name("0", "dance_pepper")
        assert (
                ret1 == "dance" and ret2 == "dance" and ret3 == "dance" and ret4 == "dance" and ret5 == "dance" and ret6 == "dance" and ret7 == "表演即将开始")

    def test_application_service_exchange_ratecurrency_chinese(self):
        # CV-9311
        self.enable_domain_by_name("0", "currency")
        ret1 = self.get_sv_response_tts_text("人民币兑美元汇率")
        time.sleep(3)
        ret2 = self.get_sv_response_tts_text("人民币兑英镑汇率")
        time.sleep(3)
        ret3 = self.get_sv_response_tts_text("人民币兑日元汇率")
        # self.disenable_domain_by_name("0", "currency")
        assert (
                "1美元=" in ret1 and "1英镑=" in ret2 and "1人民币=" in ret3)

    def test_application_service_exchange_ratecurrency_english(self):
        # CV-9312
        self.enable_domain_by_name("0", "currency")
        time.sleep(2)
        ret1 = self.get_sv_response_tts_text("dollars to rmb")
        time.sleep(2)
        ret2 = self.get_sv_response_tts_text("pound sterling to rmb")
        time.sleep(2)
        ret3 = self.get_sv_response_tts_text("jpy to rmb")
        # self.disenable_domain_by_name("0", "currency")
        assert (
                "1USD=" in ret1 and "1GBP=" in ret2 and "1CNY=" in ret3)

    def test_application_service_stock(self):
        # CV-9313
        self.enable_domain_by_name("0", "stock")
        ret1 = self.get_sv_response_tts_text("苹果股票近期走势")
        ret2 = self.get_sv_response_tts_text("苹果现在股价多少")
        # self.disenable_domain_by_name("0", "stock")
        assert (
                "股票名称:苹果，股票编号:aapl" in ret1 and "股票名称:苹果，股票编号:aapl" in ret2)

    def test_application_service_music_music(self):
        # CV-9314
        self.enable_domain_by_name("0", "music")
        ret1 = self.get_sv_response_action("唱一首名为大海的歌曲")
        # self.disenable_domain_by_name("0", "music")
        assert (ret1 == "music")

    def test_application_service_music_stop_while_playing(self):
        # CV-9315
        self.enable_domain_by_name("0", "music")
        ret1 = self.get_sv_response_action("唱一首歌")
        ret2 = self.get_sv_response_action("停止唱歌")
        # self.disenable_domain_by_name("0", "music")
        assert (ret1 == "music")

    def test_application_service_music_music_english(self):
        # CV-9316
        self.enable_domain_by_name("0", "music_en")
        ret1 = self.get_sv_response_action("sing a song")
        # self.disenable_domain_by_name("0", "music_en")
        assert (ret1 == "music")

    def test_application_service_music_music_tw(self):
        # CV-9317
        self.enable_domain_by_name("0", "music_tw")
        ret1 = self.get_sv_response_action("随便来首歌")
        # self.disenable_domain_by_name("0", "music_tw")
        assert (ret1 == "music")

    def test_application_service_translation_service_translate(self):
        # CV-9318
        self.enable_domain_by_name("0", "translate")
        # ret1 = self.get_sv_response_tts_text("翻译下hello")
        ret1 = self.get_sv_response_tts_text("翻译下workspace")
        print(ret1)
        time.sleep(1)
        # ret2 = self.get_sv_response_tts_text("翻译一下hello好吗")
        ret2 = self.get_sv_response_tts_text("翻译一下workspace好吗")
        print(ret2)
        time.sleep(1)
        # ret3 = self.get_sv_response_tts_text("翻译下hello吧")
        ret3 = self.get_sv_response_tts_text("翻译下workspace吧")
        print(ret3)
        # self.disenable_domain_by_name("0", "translate")
        # assert (ret1 == "你好" and ret2 == "你好" and ret3 == "你好")
        assert (ret1 == "工作区" and ret2 == "工作区" and ret3 == "工作区")

    def test_application_service_encyclopedia_search(self):
        # CV-9319
        self.enable_domain_by_name("0", "search")
        ret1 = self.get_sv_response_tts_text("了解一下中国移动")
        print(ret1)
        ret2 = self.get_sv_response_tts_text("知道什么是中国移动不")
        print(ret2)
        # self.disenable_domain_by_name("0", "search")
        assert ("CMCC的全称为" in ret1 and "CMCC的全称为" in ret2)

    def test_application_service_motor_vehicle_number_limit_query_service_trafficrestr(self):
        # CV-9321
        self.enable_domain_by_name("0", "trafficrestr")
        ret1 = self.get_sv_response_tts_text("今天成都限号")
        print(ret1)
        # self.disenable_domain_by_name("0", "trafficrestr")
        assert (("限行尾号" in ret1 ) or ("不限行" in ret1 )) #添加不限行判断

    def test_application_service_date_time_lunar_query_service_times(self):
        # CV-9322
        self.enable_domain_by_name("0", "times")
        date_now = self.get_datetime()
        ret1 = self.get_sv_response_tts_text("今天是几号")
        print(ret1)
        # self.disenable_domain_by_name("0", "times")
        assert (ret1 ==str(date_now))

    def test_application_service_computing_service_compute(self):
        # CV-9323
        self.enable_domain_by_name("0", "compute")
        ret1 = self.get_sv_response_tts_text("1加1等于几")
        ret2 = self.get_sv_response_tts_text("计算1加1结果")
        ret3 = self.get_sv_response_tts_text("算算1加1是多少")
        # self.disenable_domain_by_name("0", "compute")
        assert (ret1 == "2" and ret2 == "2" and ret3 == "2")

    def test_application_service_weather_inquiry_weather_chinese(self):
        # CV-9324
        self.enable_domain_by_name("0", "weather")
        ret1 = self.get_sv_response_tts_text("今天兰州天气")
        ret2 = self.get_sv_response_tts_text("兰州今天怎么样")
        ret3 = self.get_sv_response_tts_text("看下兰州今天的天气")
        # self.disenable_domain_by_name("0", "weather")
        assert ("兰州" in ret1 and "兰州" in ret2 and "兰州" in ret3)

    def test_application_service_weather_query_weather_do_not_add_place_names(self):
        # CV-9325
        self.enable_domain_by_name("0", "weather")
        ret1 = self.get_sv_response_tts_text("今天天气怎么样")
        # self.disenable_domain_by_name("0", "weather")
        # assert ("温" in ret1 and "月" in ret1)
        assert ("温" in ret1)

    def test_application_service_weather_query_weather_english(self):
        # CV-9326
        self.enable_domain_by_name("0", "chitchat")
        ret1 = self.get_sv_response_tts_text("How is new york weather")
        # self.disenable_domain_by_name("0", "chitchat")
        assert ("The weather is" in ret1)

    def test_application_service_weather_query_weather_japanese(self):
        # CV-9327
        self.enable_domain_by_name("0", "weather_jp")
        ret1 = self.get_sv_response_tts_text("天気 はどれくらいですか")
        # self.disenable_domain_by_name("0", "weather_jp")
        assert ("の天気" in ret1)

    def test_application_service_review_storytelling(self):
        # CV-9329
        self.enable_domain_by_name("0", "storytelling")
        self.storytelling_sync("勿删自动化测试评")#先审核同步
        ret1 = self.get_sv_response_action("我要听评书勿删自动化测试评")
        ret2 = self.get_sv_response_action("我想听评书勿删自动化测试评")
        ret3 = self.get_sv_response_action("播放评书勿删自动化测试评")
        # self.disenable_domain_by_name("0", "storytelling")
        print("response-----ret1,ret2,ret3::",ret1,ret2,ret3)
        # assert (ret1 == "music" and ret2 == "music" and ret3 == "music")
        assert (ret1 == "storytelling" and ret2 == "storytelling" and ret3 == "storytelling")

    def test_application_service_drama_drama(self):
        # CV-9330
        self.enable_domain_by_name("0", "drama")
        self.drama_sync("勿删自动化测试戏")#先审核同步
        ret1 = self.get_sv_response_action("我要听一段戏曲勿删自动化测试戏")
        time.sleep(15)
        ret2 = self.get_sv_response_action("我想听一段戏曲勿删自动化测试戏")
        time.sleep(15)
        ret3 = self.get_sv_response_action("我要听戏曲勿删自动化测试戏")
        # self.disenable_domain_by_name("0", "drama")
        # assert (ret1 == "music" and ret2 == "music" and ret3 == "music")
        assert (ret1 == "drama" and ret2 == "drama" and ret3 == "drama")

    def test_application_service_cross_talk_service(self):
        # CV-9331
        self.enable_domain_by_name("0", "crosstalk")
        self.crosstalk_sync("勿删自动化测试相")#先审核同步
        ret1 = self.get_sv_response_action("给我播放一段相声勿删自动化测试相")
        ret2 = self.get_sv_response_action("播放相声勿删自动化测试相")
        ret3 = self.get_sv_response_action("我想听段相声勿删自动化测试相")
        # self.disenable_domain_by_name("0", "crosstalk")
        # assert (ret1 == "music" and ret2 == "music" and ret3 == "music")
        assert (ret1 == "crosstalk" and ret2 == "crosstalk" and ret3 == "crosstalk")

    def test_application_service_poetry_service_poetry(self):
        # CV-9332
        self.enable_domain_by_name("0", "poetry")
        self.poetry_sync("冬柳")#先审核同步
        time.sleep(3)
        ret2 = self.get_sv_response_tts_text("念一下冬柳这首诗")
        ret1 = self.get_sv_response_tts_text("念一下冬柳的内容")
        # ret1 = self.get_sv_response_tts_text("说一下冬柳的内容")
        # ret2 = self.get_sv_response_tts_text("念一下冬柳这首诗")
        ret3 = self.get_sv_response_tts_text("读一下冬柳这一首诗")
        print("response--------------:",ret1,ret2,ret3)
        # for num in range(11):
        #     ret1 = self.get_sv_response_tts_text("念一下冬柳的内容")
        #     # ret1 = self.get_sv_response_tts_text("说一下冬柳的内容")
        #     ret2 = self.get_sv_response_tts_text("念一下冬柳这首诗")
        #     ret3 = self.get_sv_response_tts_text("读一下冬柳这一首诗")
        # self.disenable_domain_by_name("0", "poetry")
        assert ("柳汀斜对野人窗" in ret1 and "柳汀斜对野人窗" in ret2 and "柳汀斜对野人窗" in ret3)

    def test_application_service_joke_joke_chinese(self):
        # CV-9333
        self.enable_domain_by_name("0", "joke")
        ret1 = self.get_sv_response_source("给我讲个笑话")
        ret2 = self.get_sv_response_source("在说个笑话吧")
        ret3 = self.get_sv_response_source("逗我笑一下")
        # self.disenable_domain_by_name("0", "joke")
        assert (ret1 =="system_service" and ret2 =="system_service" and ret3 =="system_service")

    def test_application_service_joke_joke_english(self):
        # CV-9334
        self.enable_domain_by_name("0", "chitchat")
        ret1 = self.get_sv_response_source("tell me a joke")
        # self.disenable_domain_by_name("0", "chitchat")
        assert (ret1 == "third_chitchat")

    def test_application_service_story_story(self):
        # CV-9335
        self.enable_domain_by_name("0", "story")
        self.story_sync("鞋匠师傅")#先审核同步
        ret1 = self.get_sv_response_tts_text("讲个鞋匠师傅的故事")
        ret2 = self.get_sv_response_source("我想随便听一个故事")
        ret3 = self.get_sv_response_source("请随便的说个故事吧")
        # self.disenable_domain_by_name("0", "story")
        assert ("鞋匠师傅" in ret1   and ret2 == "system_service" and ret3 == "system_service")

    def test_application_service_flight_inquiry_flight_English(self):
        # CV-9337
        self.enable_domain_by_name("0", "chitchat")
        ret1 = self.get_sv_response_tts_text("please check the flight from Beijing to Shanghai today")
        ret2 = self.get_sv_response_tts_text("please check the flight from Beijing to Tokyo today")
        # self.disenable_domain_by_name("0", "chitchat")
        assert ("flight from Beijing to Shanghai" in ret1 and "Beijing to Tokyo" in ret2)

    def test_application_service_food_service_food(self):
        # CV-9338
        self.enable_domain_by_name("0", "food")
        ret1 = self.get_sv_response_tts_text("推荐一下望京附近有什么好吃的食物")
        time.sleep(5)
        ret2 = self.get_sv_response_tts_text("推荐下周围有哪些好吃的小吃")
        time.sleep(5)
        ret3 = self.get_sv_response_tts_text("去哪里吃宵夜")
        self.disenable_domain_by_name("0", "food")
        assert ("为您找到" in ret1 and "为您找到" in ret2 and "为您找到" in ret3)

    def test_application_service_news_news(self):
        # CV-9339
        self.enable_domain_by_name("0", "news")
        ret1 = self.get_sv_response_source("今天最新的新闻有哪些")
        ret2 = self.get_sv_response_source("最近的资讯有哪些")
        ret3 = self.get_sv_response_source("今日快报")
        # self.disenable_domain_by_name("0", "news")
        assert (
                ret1 == "system_service" and ret2 == "system_service" and ret3 == "system_service")

    def test_application_service_chat(self):
        # CV-9340
        self.enable_domain_by_name("0", "chitchat")
        ret1 = self.get_sv_response_source("香山公园的最高峰多高啊")
        # self.disenable_domain_by_name("0", "chitchat")
        assert (
                ret1 == "third_chitchat")

    def test_application_service_customer_smart_mode_match_approximate_questions_and_answer_automatically(self):
        # CV-9341
        self.add_qa("自定义问答","你叫什么名","我叫黄小达")
        time.sleep(2)
        ret1 = self.get_sv_response_source("你叫什么名")
        ret2 = self.get_sv_response_tts_text("你叫什么名")
        self.del_qa("自定义问答", "你叫什么名", "我叫黄小达")
        print("response source,result answer:",ret1,ret2)
        assert (ret1 == "user_qa" and ret2 == "我叫黄小达")

    def test_application_service_artificial_pattern_matching_approximation_problem(self):
        # CV-9342
        self.add_qa("自定义问答", "你叫啥名", "我叫黄晓达")
        time.sleep(2)
        ret1 = self.get_sv_response_source("你叫什么名")
        ret2 = self.get_sv_response_tts_text("你叫什么名")
        self.del_qa("自定义问答", "你叫啥名", "我叫黄晓达")
        assert (ret1 == "user_qa" and ret2 == "我叫黄晓达")

    def test_application_swearing_sensitive_words_filtering(self):
        # CV-9343
        self.enable_domain_by_name("0", "chitchat")
        ret1 = self.get_sv_response_tts_text("操的")
        # self.disenable_domain_by_name("0", "chitchat")
        assert ("操的" not in ret1)

    def test_platform_management_crosstalk_drama_crosstalk_storytelling_news_music_story_joke_synchronization(self):
        # CV-10387
        self.enable_domain_by_name("0", "crosstalk")
        self.goto_entity_page()
        self.selib.input_text(uilocators.system_service_search_input,"crosstalk_title")
        self.wait_and_click_element_at_coordinates_if_available(uilocators.system_service_search_input_search_icon)
        ret1 = self.wait_element_visible(uilocators.crosstalk_title)
        self.selib.input_text(uilocators.system_service_search_input, "crosstalk_performer")
        self.wait_and_click_element_at_coordinates_if_available(uilocators.system_service_search_input_search_icon)
        ret2 = self.wait_element_visible(uilocators.crosstalk_performer)
        ret3 = self.get_sv_response_action("给我播放一段相声勿删自动化测试相")
        # self.disenable_domain_by_name("0", "crosstalk")
        # assert (ret1 and ret2 and ret3 == "music")
        assert (ret1 and ret2 and ret3 == "crosstalk")

    def test_platform_management_crosstalk_drama_crosstalk_storytelling_news_music_story_joke_close_synchronization(self):
        # CV-10388
        self.enable_domain_by_name("0", "crosstalk")
        # self.crosstalk_sync("勿删自动化测试相")  # 先审核同步
        self.goto_entity_page()
        self.selib.input_text(uilocators.system_service_search_input, "crosstalk_title")
        self.wait_and_click_element_at_coordinates_if_available(uilocators.system_service_search_input_search_icon)
        ret1 = self.wait_element_visible(uilocators.crosstalk_title)
        self.selib.input_text(uilocators.system_service_search_input, "crosstalk_performer")
        self.wait_and_click_element_at_coordinates_if_available(uilocators.system_service_search_input_search_icon)
        ret2 = self.wait_element_visible(uilocators.crosstalk_performer)
        ret3 = self.get_sv_response_source("给我播放一段相声不审核的相声勿删")
        # ret3 = self.get_sv_response_source("给我播放一段相声长塞北")
        # self.disenable_domain_by_name("0", "crosstalk")
        assert (ret1 and ret2 and ret3 != "system_service")

    def test_application_service_music_music_random_play(self):
        # CV-10389
        self.enable_domain_by_name("0", "music_en")
        ret1 = self.get_sv_response_action("sing a song")
        # self.disenable_domain_by_name("0", "music_en")
        assert (ret1 == "music")

    def test_application_service_music_music_supports_songs_by_artist_name(self):
        # CV-10390
        self.enable_domain_by_name("0", "music_en")
        ret1 = self.get_sv_response_action("sing a song who")
        ret2 = self.get_sv_response_source("sing a song who")
        # self.disenable_domain_by_name("0", "music_en")
        assert (ret1 == "music" and ret2 == "system_service")

    def test_application_service_story_story_english(self):
        # CV-10392
        self.enable_domain_by_name("0", "story_en")
        ret1 = self.get_sv_response_source("Please tell a story")
        # self.disenable_domain_by_name("0", "story_en")
        assert (ret1  == "system_service")

    def test_application_service_joke(self):
        # CV-10394
        self.enable_domain_by_name("0", "joke")
        ret1 = self.get_sv_response_source("id是"+constant.ServiceManage_joke_id+"的笑话")
        ret2 = self.get_sv_response_tts_text("id是"+constant.ServiceManage_joke_id+"的笑话")
        # self.disenable_domain_by_name("0", "joke")
        assert (ret1 =="system_service" and "没听明白" not in ret2)

    def test_application_service_news_news_context(self):
        # CV-10807
        self.enable_domain_by_name("0", "news")
        ret1 = self.get_sv_response_source("听听最近的关于军事的相关新闻")
        ret2 = self.get_sv_response_source("念一下详细信息")
        # self.disenable_domain_by_name("0", "news")
        assert (ret1 == "system_service" and ret2 == "system_service")

    def test_application_service_today_in_histoday(self):
        # CV-10921
        self.enable_domain_by_name("0", "histoday")
        ret1 = self.get_sv_response_source("今天历史上都发生了什么事")
        # self.disenable_domain_by_name("0", "histoday")
        assert (ret1 == "system_service")

    def test_NLP_library_crawling_content_order_customized_service_userQA_FAQ_systemservice_chatchat_defaultanswer(self):
        #CV-10401
        self.create_domain("autotest","This is for create define domain")
        self.enable_domain_by_DomainId("autotest")
        self.create_domain_intents("autotest","autotest1","北京天气","这是自定义服务的回复")
        self.add_qa("自定义问答","北京天气","这是用户QA的回复")
        self.open_industry_button(constant.FaqTypeId)  #FAQ
        self.enable_domain_by_name("0", "weather")  #weather
        self.enable_domain_by_name("0", "chitchat")  #闲聊
        self.add_welcome_repeat_default_words("默认回答","这是默认问答的回复")  #默认回答
        time.sleep(5)
        ret1 = self.get_sv_response_source("北京天气")
        ret2 = self.get_sv_response_tts_text("北京天气")
        self.delete_domain_by_domain_name("autotest")
        time.sleep(5)
        ret3 = self.get_sv_response_source("北京天气")
        ret4 = self.get_sv_response_tts_text("北京天气")
        self.del_qa("自定义问答", "北京天气", "这是用户QA的回复")
        time.sleep(5)
        ret5 = self.get_sv_response_source("北京天气")
        ret6 = self.get_sv_response_tts_text("北京天气")
        self.close_industry_button(constant.FaqTypeId)  # FAQ
        time.sleep(5)
        ret7 = self.get_sv_response_source("北京天气")
        ret8 = self.get_sv_response_tts_text("北京天气")
        self.disenable_domain_by_name("0", "weather")
        time.sleep(5)
        ret9 = self.get_sv_response_source("北京天气")
        ret10 = self.get_sv_response_tts_text("北京天气")
        self.disenable_domain_by_name("0", "chitchat")
        time.sleep(5)
        ret11 = self.get_sv_response_source("北京天气")
        ret12 = self.get_sv_response_tts_text("北京天气")
        self.del_welcome_repeat_default_words("默认回答","这是默认问答的回复")

        self.enable_domain_by_name("0", "weather")
        self.enable_domain_by_name("0", "chitchat")
        print("result-----------:",ret1,ret2,ret3,ret4,ret5,ret6,ret7,ret8,ret9,ret10,ret11,ret12)
        assert (ret1=="user_service" and ret2 =="这是自定义服务的回复" and ret3 =="user_qa" and ret4 =="这是用户QA的回复"
        and ret5 =="common_sense_qa" and ret6=="这是FAQ的回答" and ret7 =="system_service" and "北京" in ret8 and ret9=="third_chitchat"
        and "北京" in ret10 and ret11=="user_default_qa" and ret12=="这是默认问答的回复")

    def test_application_service_news_news_algorithm_enhancement(self):
        #CV-13757
        self.enable_domain_by_name("0", "news")
        ret1 = self.get_sv_response_source("今天最新的新闻有哪些")
        ret2 = self.get_sv_response_time("今天最新的新闻有哪些")
        # self.disenable_domain_by_name("0", "news")
        assert (ret1 == "system_service" and ret2 < 0.1)

    def test_application_service_news_news_context_algorithm_enhancement(self):
        #CV-13758
        self.enable_domain_by_name("0", "news")
        ret1 = self.get_sv_response_source("今天最新的新闻有哪些")
        ret2 = self.get_sv_response_time("今天最新的新闻有哪些")
        ret3 = self.get_sv_response_source("念一下详情")
        ret4 = self.get_sv_response_time("念一下详情")
        # self.disenable_domain_by_name("0", "news")
        assert (ret1 == "system_service" and ret2 < 0.1 and ret3 == "system_service" and ret4 < 0.1)