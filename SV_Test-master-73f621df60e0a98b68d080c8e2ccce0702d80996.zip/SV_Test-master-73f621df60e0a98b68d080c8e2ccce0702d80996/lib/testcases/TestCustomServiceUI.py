#!/usr/bin/env python
# coding=utf-8

from lib.modules.CustomServiceUI import CustomServiceUI
from lib.utils import constant
from lib.uilocators import uilocators
import time

class TestCustomServiceUI(CustomServiceUI):

    def login_sv(self,user=constant.SV_USER, password=constant.SV_PWD):
        self.login_smartvoice(user=user, password=password)

    def logout_sv(self):
        self.close_chrome_browser()

    def test_domain_create_NameVerification(self):
        #self.goto_application_by_name('baldwin')
        self.goto_application_by_name(constant.agent_name)
        self.open_item_in_intent(1)
        self.create_domain()
        result = self.enterandedit_domainname("----")
        if result == "只能输入英文和下划线，并且必须以英文开头":
            #assert True
            result = self.enterandedit_domainname("aaaaaaaaaaaaaaaaaaaaaaaaa")
            if result == "请输入20个字符以内的内容":
                #测试服务描述
                result = self.enterandedit_domaininfo("123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901")
                if result == "请输入200个字符以内的内容":
                    print("服务类型检测测试通过")
                    assert True
                else:
                    print("服务描述异常")
                    assert False
            else:
                print("测试失败，服务名能输入大于20个字符的内容")
                assert False
        else:
            print("执行失败，服务名能够输入非英文下划线内容")
            assert False
