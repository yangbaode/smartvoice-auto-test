#!/usr/bin/env python
# coding=utf-8

from lib.modules.SystemManagement import SystemManagement
import logging as logger
import os
from lib.utils import constant
import json
import random
import string

class TestSystemManagement(SystemManagement):
    ROBOT_LIBRARY_SCOPE = 'TEST SUITE'
    ROBOT_LIBRARY_VERSION = "0.1"

    def __init__(self):
        SystemManagement.__init__(self, constant.SV_ADMIN, constant.SV_ADMIN_PWD)

    def test_list_all_account(self):
        result = self.list_all_customer_admin_account(pattern='$..username')[0]
        if result:
            assert len(result) == 10, '默认列取10条失败'
        assert result, '列取为空'

    def test_list_account_check_item(self):
        result = self.list_all_customer_admin_account(pattern='$..telephone')[0]
        if result:
            assert len(result) > 0, '默认列取电话号码失败'
        assert result, '列取电话号码为空'
        result = self.list_all_customer_admin_account(pattern='$..mail')[0]
        if result:
            assert len(result) > 0, '默认列取mail失败'
        assert result, '列取mail为空'
        result = self.list_all_customer_admin_account(pattern='$..realname')[0]
        if result:
            assert len(result) > 0, '默认列取realname失败'
        assert result, '列取realname为空'
        result = self.list_all_customer_admin_account(pattern='$..active')[0]
        if result:
            assert len(result) > 0, '默认列取active失败'
        assert result, '列取active为空'

    def test_add_customer_account(self):
        ret = self.add_account('auto.customer@cloudminds.com')
        print(ret)
        if 'error' in ret.keys():
            if 'username or mail already exists' == ret['error']:
                print('已经存在!')
                return

        check = self.get_account_by_username('auto.customer@cloudminds.com')
        logger.info(check)
        assert check, '查询刚刚创建的account失败'

    def test_edit_customer_account(self):
        realname = ''.join(random.sample(string.ascii_letters + string.digits, 50))
        mail = '{}@cloudminds.com'.format(''.join(random.sample(string.ascii_letters + string.digits, 25)))
        telephone = "139{}".format(''.join(random.sample(string.digits, 8)))
        modifies = {'realname': realname, 'mail': mail, 'telephone': telephone}
        r = self.modify_account('auto.customer@cloudminds.com', modifies=modifies)
        print(r)

        check = self.get_account_by_username('auto.customer@cloudminds.com')
        assert check['realname'] == realname, '检查realname修改失败'
        assert check['mail'] == mail, 'mail检查失败'
        assert check['telephone'] == telephone, 'telephone检查失败'

    def test_disable_account(self):
        account = self.get_account_by_username('auto.customer@cloudminds.com')
        if account['active'] == 0:
            print('已经处于disable状态,先打开在做关闭的case')
            assert self.set_account_active_status('auto.customer@cloudminds.com', 1)==1, '先打开在做关闭的case失败'

        assert self.set_account_active_status('auto.customer@cloudminds.com', 0)==0, '关闭账号失败'

    def test_enable_account(self):
        account = self.get_account_by_username('auto.customer@cloudminds.com')
        if account['active'] == 1:
            print('已经处于enable状态,先关闭再做打开操作e')
            assert self.set_account_active_status('auto.customer@cloudminds.com', 0)==0, '关闭account失败'

        assert self.set_account_active_status('auto.customer@cloudminds.com', 1)==1, '开启账号失败'

