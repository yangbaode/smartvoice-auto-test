#!/usr/bin/env python
# coding=utf-8

from lib.modules.Application import Application
from lib.modules.Base import Base
from lib.uilocators import uilocators
import SeleniumLibrary
from lib.utils import constant
import logging as logger
import os
import time

class TestMsgCenter(Application):
    def test_open_msgCenter(self):
        self.open_message_center()
        # assert self.wait_element_visible(uilocators.nav_message_center, 10)
    def add_msg_action(self):
        #self.selib.click_element(uilocators.new_msg_btn)
        self.click_locator(uilocators.new_msg_btn)
    def save_msg_action(self):
        self.selib.click_element(uilocators.new_msg_btn)
        self.selib.input_text(uilocators.msg_name_input, 'sv_ym_name')
        self.selib.input_text(uilocators.msg_content_input, 'sv_ym_content')
        self.selib.click_element(uilocators.new_msg_save_btn)
    def del_msg_action(self,msgname):
        self.open_del_msg_action(msgname)
        self.confirm_del_msg_action()
    def open_edit_msg_action(self):
        self.selib.click_element("//tr[@class='ant-table-row ng-star-inserted'][contains(.,'sv_ym_name')]/*/button[@class='ant-btn ant-btn-primary'][2]")
    def close_edit_msg_action(self):
        self.selib.click_element(uilocators.close_edit_msg_btn)
    def edit_msg_action(self):
        self.open_edit_msg_action()
        self.selib.input_text(uilocators.msg_edit_name_input, 'sv_ym_name_edit')
        self.selib.input_text(uilocators.msg_edit_content_input, 'sv_ym_content_edit')
        self.confirm_save_msg_action()
    def confirm_save_msg_action(self):
        self.selib.click_element(uilocators.new_msg_save_btn)
    def open_del_msg_action(self,msgname):
        del_btn = "//tr/td[text()='{}']/../td/button[3]".format(msgname)
        self.click_locator(del_btn)
    def confirm_del_msg_action(self):
        self.selib.click_element(uilocators.del_msg_btn)
    def open_assigned_msg_action(self,msgname):
        assign_btn = "//tr/td[text()='{}']/../td/button[1]".format(msgname)
        self.click_locator(assign_btn)
    def verify_msg_field(self, text):
        assert self.wait_page_contains(text, 10)
    def verify_assigned_action(self):
        self.click_locator(uilocators.msg_assigned_button)
        text = self.selib.get_text(uilocators.msg_message_text)
        if(text == '请选择指派人员'):
            assert 1==1
        else:
            assert 1==0
    def close_assigned_win(self):
        self.click_locator(uilocators.msg_assigned_cancel_button)


