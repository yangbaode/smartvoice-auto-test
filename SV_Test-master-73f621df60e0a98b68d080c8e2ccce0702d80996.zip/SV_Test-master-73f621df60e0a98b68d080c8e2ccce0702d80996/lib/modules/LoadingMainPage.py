# !/usr/bin/env python
# -*- coding: utf-8 -*-
from lib.utils.logger import logger
from lib.utils import constant
from lib.modules.Base import Base
import requests
import json


class LoadingMainPage(Base):
    def __init__(self, user, password, agent_id=None):
        Base.__init__(self, user, password)
        self.get_sv_authinfo(agent_id=agent_id)


    def is_complete(self):
        headers = {'Connection': 'keep-alive',
         'Content-Type':'application/json',
         'Accept':'application/json, text/plain, */*',
         'authinfo': self.authinfo}
        url = '/v2/ux/user/info/iscomplete'
        r = requests.get(constant.SERVER +url, headers=headers, verify=False)
        print(r.text)
        return r.json()['iscomplete']

    def statistics_hittimes_agent(self, para, pattern=None):
        url = "/v2/ux/statistics/hittimes/agent"
        return self.sv_request(url, 'GET', parameter=para, pattern=pattern)

    def statistics_hittimes_domain(self, para, pattern=None):
        url = "/v2/ux/statistics/hittimes/domain"
        return self.sv_request(url, 'GET', parameter=para, pattern=pattern)

    def get_agent_num(self):
        url = "/v2/ux/statistics/totalagent"
        return self.sv_request(url, 'GET')[0]['total']