from lib.utils.logger import logger
from lib.utils import constant
from lib.modules.Base import Base
from lib.modules.UiBase import UiBase
from lib.uilocators import uilocators
import requests
import json
import datetime,jsonpath
import urllib
import urllib3
import time

class CustomServiceUI(UiBase):
    def goto_application_by_name(self,name):
        '''
        function:通过应用名跳转到对应页面
        :param name:应用名
        :return:
        '''
        self.wait_element_visible(uilocators.nav_applicaiton_info,5)
        self.wait_and_click_element_at_coordinates_if_available(uilocators.nav_applicaiton)
        self.wait_and_click_element_at_coordinates_if_available(uilocators.nav_applicaiton_beller%name)

    def open_item_in_intent(self, index):
        '''
        打开意图中的条目, 1为自定义服务,2为服务管理, 3为实体
        :param index: 1为自定义服务,2为服务管理, 3为实体
        :return:
        '''
        self.wait_element_visible(uilocators.nav_applicaiton_tab_intent)
        self.click_locator(uilocators.nav_applicaiton_tab_intent)
        self.selib.mouse_over(uilocators.nav_applicaiton_tab_intent)
        time.sleep(0.5)
        self.click_by_js("(//ul/li[@nz-menu-item])[{}]".format(index))

    def create_domain(self):
        '''
        创建服务
        :return:
        '''
        self.wait_element_present(uilocators.domain_icon, 5)
        self.click_by_js(uilocators.domain_icon)
        self.wait_element_present(uilocators.domain_service_create, 5)
        self.click_by_js(uilocators.domain_service_create)

    #服务名输入特殊字符
    def enterandedit_domainname(self, strings):
        self.enter_text(uilocators.new_domain_name, strings)
        time.sleep(0.5)
        ret = self.selib.get_text(uilocators.lab_domain_createname)
        return  ret

    #服务描述输入
    def enterandedit_domaininfo(self, strings):
        self.enter_text(uilocators.new_domaininfo, strings)
        time.sleep(0.5)
        ret = self.selib.get_text(uilocators.lab_domaininfo_createname)
        print("11111111111111111111111111111",ret)
        return  ret