# !/usr/bin/env python
# -*- coding: utf-8 -*-
from lib.utils.logger import logger
from lib.modules.UiBase import UiBase
from lib.uilocators import uilocators
from lib.utils import constant
import time
import xlrd

class Application(UiBase):
    def open_application_default(self):
        self.wait_element_present(uilocators.nav_application, 5)
        self.click_by_js(uilocators.nav_application)

    def open_application_navi(self, navi_text):
        '''
        可以打开应用和应用列表
        :param navi_text: 
        :return: 
        '''
        # 可以打开应用和应用列表
        navi = "//ul[@class='left-bar-nav']//a[text()='{}']".format(navi_text)
        self.wait_element_present(navi, 5)
        self.click_by_js(navi)
    def open_message_center(self):
        self.wait_element_present(uilocators.nav_message_center, 5)
        self.click_by_js(uilocators.nav_message_center)
    def open_application_tag(self):
        self.wait_element_present(uilocators.nav_application, 5)
        self.click_by_js(uilocators.nav_application)
    def test_open_app_entity(self):
        self.wait_element_present(uilocators.nav_application_center, 5)
        self.click_by_js(uilocators.nav_message_center)
    def open_industry_library(self):
        self.wait_element_present(uilocators.nav_industry_library, 5)
        self.click_by_js(uilocators.nav_industry_library)
    def open_item_in_intent(self, index):
        '''
        打开意图中的条目, 1为自定义服务,2为服务管理, 3为实体
        :param index: 1为自定义服务,2为服务管理, 3为实体
        :return: 
        '''
        self.wait_element_visible(uilocators.nav_applicaiton_tab_intent)
        self.click_locator(uilocators.nav_applicaiton_tab_intent)
        self.selib.mouse_over(uilocators.nav_applicaiton_tab_intent)
        time.sleep(0.5)
        self.click_by_js("(//ul/li[@nz-menu-item])[{}]".format(index))

    def open_item_in_faq(self, index):
        '''
        在FAQ中打开条目,
        :param index: 1为问答分类,2,行业库管理,3为标签管理,4为问题标注
        :return: 
        '''
        #打开问答中的条目, 1为问答分类,2,行业库管理,3为标签管理,4为问题标注
        self.wait_element_visible(uilocators.nav_applicaiton_tab_faq)
        self.click_locator(uilocators.nav_applicaiton_tab_faq)
        self.selib.mouse_over(uilocators.nav_applicaiton_tab_faq)
        time.sleep(0.5)
        self.click_by_js("(//ul/li[@nz-menu-item])[{}]".format(index))

    def check_item_in_excel(self, expected_str, excel_file):
        '''
        检查excel中的内容包含
        :param expected_str: 
        :param excel_file: 
        :return: 
        '''
        try:
            data = xlrd.open_workbook(excel_file)
            table = data.sheets()[0]
            nrows = table.nrows  #获取该sheet中的有效行数
            for row in range(nrows):
                values = table.row_values(row)   #返回由该行中所有单元格的数据组成的列表
                if expected_str in values:
                    return True
            return False
        except Exception as ex:
            print(ex)
            print('read excel failed.')
            return False

    def open_application_list(self):
        '''
        打开应用列表
        :return: 
        '''
        app_list = "//a[text()='{}']".format(uilocators.nav_application_list_str)
        if self.wait_element_present(uilocators.app_search_input, 1):
            print('already in search menu')
        elif self.wait_element_present(app_list, 1):
            self.click_by_js(app_list)
            time.sleep(1)
            self.wait_element_disapear("//*[@class='ant-spin-nested-loading']", 40)
        else:
            self.open_application_default()
            time.sleep(1)
            self.click_by_js(app_list)
            time.sleep(1)
            self.wait_element_disapear("//*[@class='ant-spin-nested-loading']", 40)

        assert self.wait_element_present(uilocators.app_search_input, 2), '不在applist界面,无法搜索'

    def search_application(self, app_name):
        '''
        在应用列表中搜索应用
        :param app_name: 被搜索的应用名称
        :return: 
        '''
        self.open_application_list()
        self.selib.input_text(uilocators.app_search_input, app_name)
        self.click_by_js(uilocators.app_search_icon)
        time.sleep(1)
        #self.wait_element_disapear("//*[contains(@class,'loading')]", 30)
        appname = self.get_text_from_webelements(uilocators.app_list_table_appname)
        assert app_name in appname

    def open_applicaiton_in_applist(self, app_name):
        '''
        在应用列表中打开应用
        :param app_name: 
        :return: 
        '''
        self.search_application(app_name)
        elements = self.get_elements(uilocators.app_list_table_appname)
        if not elements:
            print('no %s found' % app_name)
            return False
        for ele in elements:
            name = ele.get_attribute('innerText')
            print(type(name))
            if name == app_name:
                try:
                    self.click_webelement_by_js(ele)
                    return True
                except:
                    logger.error('click {} failed'.format(name))
                    return False

    def edit_application_in_applist(self, app_name, kwargs):
        '''
        编辑应用, 在应用列表中编辑
        :param app_name: 
        :param kwargs: 是个字典,可以包括name,lat,lon,gateway,description, check, check为discription检查的内容
        :return: 
        '''
        ret = False
        self.search_application(app_name)
        edit_btn = "//td[text()='{}']/../td[6]/button[1]".format(app_name)
        self.click_locator(edit_btn)
        ret = None
        if 'name' in kwargs.keys():
            self.enter_text(uilocators.new_app_name, kwargs['name'])
        if 'lat' in kwargs.keys():
            self.enter_text(uilocators.new_app_lat, kwargs['lat'])
        if 'lon' in kwargs.keys():
            self.enter_text(uilocators.new_app_lon, kwargs['lon'])
        if 'gateway' in kwargs.keys():
            self.enter_text(uilocators.new_app_getway, kwargs['gateway'])
        if 'description' in kwargs.keys():
            self.enter_text(uilocators.new_app_description, kwargs['description'])
        if 'check' in kwargs.keys():
            if 'lon' in kwargs['check'].keys():
                ret = self.get_value_by_js(uilocators.new_app_lon)
                print(ret, kwargs['check']['lon'])
            if 'description' in kwargs['check'].keys():
                ret = self.get_value_by_js(uilocators.new_app_lon)
                print(ret, kwargs['check']['description'])
        self.click_locator(uilocators.new_app_save_btn)
        return  ret

    def get_app_status_in_applist(self, app_name):
        '''
        在应用列表总获取app是否enable
        :param app_name: 应用名称
        :return: bool
        '''
        status_btn = "//td[text()='{}']/../td/div/button/span".format(app_name)
        text = self.selib.get_text(status_btn)
        if "启用" in text or "啓用" in text or 'Enable' in text or '有効にする' in text:
            return False
        if "停用" in text or 'Disable' in text or '無効にする' in text:
            return True

    def set_app_status_in_applist(self, app_name, status):
        '''
        在应用列表中设置app状态,
        :param app_name: 
        :param status: 设置状态如果状态为启用True, 设置状态为未启用False
        :return: 返回bool, 如果启用状态为True, 未启用状态为False
        '''
        self.search_application(app_name)
        status_btn = "//td[text()='{}']/../td/div/button/span".format(app_name)
        ret = self.get_app_status_in_applist(app_name)
        if ret != status:
            self.click_by_js(status_btn)
        time.sleep(2)
        return self.get_app_status_in_applist(app_name)







