from lib.utils.logger import logger
from lib.utils import constant
from lib.modules.Base import Base
from lib.modules.UiBase import UiBase
from lib.uilocators import uilocators
import requests
import json
import datetime
import jsonpath
import re

class ServiceManagement(UiBase):

    def __init__(self):
        UiBase.__init__(self)
        self.interface = Base(constant.SV_USER, constant.SV_PWD)
        print(self.interface.get_sv_authinfo())
        self.agentid = self.interface.add_new_application(constant.agent_name_beller)
        # self.agentid = self.interface.add_new_application('新接口测试')
        # self.agentidUI = self.interface.add_new_application('beller')

    def goto_application_by_name(self,name):
        '''
        function:通过应用名跳转到对应页面
        :param name:应用名
        :return:
        '''

        self.wait_element_visible(uilocators.nav_applicaiton_info,5)
        self.wait_and_click_element_at_coordinates_if_available(uilocators.nav_applicaiton)
        self.wait_and_click_element_at_coordinates_if_available(uilocators.nav_applicaiton_beller%name)

    def enter_service_management_page(self):
        '''
        function:进入系统服务管理页面
        :return:
        '''
        self.wait_element_visible(uilocators.nav_applicaiton_intention,5)
        self.wait_and_click_element_at_coordinates_if_available(uilocators.nav_applicaiton_intention)
        self.wait_and_click_element_at_coordinates_if_available(uilocators.nav_applicaiton_intention_service_management)

    def goto_entity_page(self):
        '''
        function:进入意图-实体页面
        :return:
        '''
        self.wait_element_visible(uilocators.nav_applicaiton_info, 5)
        self.wait_and_click_element_at_coordinates_if_available(uilocators.nav_applicaiton)
        self.wait_element_visible(uilocators.nav_applicaiton_intention,5)
        self.wait_and_click_element_at_coordinates_if_available(uilocators.nav_applicaiton_intention)
        self.wait_and_click_element_at_coordinates_if_available(uilocators.nav_applicaiton_intention_entity)

#====================================api==========================================
    def get_domain_id_by_domain_name(self, domain_name):
        '''
        function:通过自定义服务名获取自定义服务id（domain id）
        :param domain_name: domain名（自定义服务名） str类型
        :return:
        '''

        self.interface.get_sv_authinfo(self.agentid) # 登录拿到所有的登陆后的authinfo
        url = "/v2/ux/agents/{}/domains/".format(self.agentid)
        para = {"params": {'page': 1, 'pagesize': 10}}
        pattern = "$..data[?(@.domainname== '{}')].id".format(domain_name)
        ret = self.interface.sv_request(url=url, method='GET', parameter=para, pattern=pattern)
        if ret[0]:
            return ret[0][0]
        return -1

    def create_domain(self, domain_name, domain_info,release=""):
        '''
        function:创建自定义服务
        :param domain_name: 服务名 str类型
        :param domain_info: 服务描述  str类型
        :param release: 服务开启/关闭状态，默认为关闭状态 str类型
        :return:
        '''
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        # self.interface.get_sv_authinfo(self.agentidUI)  # 登录拿到所有的登陆后的authinfo
        if release=="":
            release = 1
        url = "/v2/ux/agents/{}/domains/".format(self.agentid)
        data = {"domainname":domain_name,"domaininfo":domain_info,"status":"","type":"","url":"","release":release}

        r = requests.post(constant.SERVER + url, headers=self.interface.headers, json=data, verify=False)
        if r.status_code != 201:
            print("create domain faild!!!")
            return r.text
        return r.status_code == 201

    def enable_domain_by_DomainId(self, domain_name):
        '''
        通过自定义服务名，开启服务
        :param domain_name: 自定义服务名 str类型
        :return:
        '''
        domain_id = self.get_domain_id_by_domain_name(domain_name)
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        url = "/v2/ux/agents/{}/domains/{}/enable".format(self.agentid,domain_id)
        para = {"params": {'domainid': domain_id}}
        pattern = "$.[*]"
        ret = self.interface.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret[0]:
            return True
        else:
            return False

    # 自定义服务-意图-新建
    def create_domain_intents(self,domain_name,intentname,quely,prompt):
        '''
        创建自定义服务意图
        :param domain_name:自定义服务名 str类型
        :param intentname: 自定义服务意图 str类型
        :param quely: 问题 str类型
        :param prompt: 答案 str类型
        :return:
        '''
        domain_id = self.get_domain_id_by_domain_name(domain_name)
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        url = "/v2/ux/agents/{}/domains/{}/intents/".format(self.agentid, domain_id)
        datas = {"id": 0, "agentid": self.agentid, "domainid": int(domain_id), "intentname": intentname,
                 "inputcontext": "", "outputcontext": "", "examplelist": [
                {"type": "quote", "text": quely, "labellist": [{"text": quely}],
                 "textIsEmpty": False}], "paramlist": [], "prompt": prompt}
        jsons = json.dumps(datas)
        r = requests.post(constant.SERVER + url, headers=self.interface.headers, data=jsons, verify=False)
        if r.status_code != 201:
            return False
        return True

    def get_intents_id_by_domain_name(self, domain_name,intentname):
        '''
        通过自定义服务名获取自定义意图id
        :param domain_name: 自定义服务名 str类型
        :param intentname: 意图名 str类型
        :return:
        '''
        domain_id = self.get_domain_id_by_domain_name(domain_name)
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        url = "/v2/ux/agents/{}/domains/{}/intents".format(self.agentid,domain_id)
        para = {"params": {'page': 1, 'pagesize': 10}}
        pattern = "$..data[?(@.intentname=='{}')].id".format(intentname)
        ret = self.interface.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret[0]:
            return ret[0][0]
        return -1

    #自定义服务-意图-删除
    def delete_domain_intents(self, domain_name,intentname):
        '''
        通过自定义服务名和意图名，删除对应意图
        :param domain_name:自定义服务名
        :param intentname:自定义意图名
        :return:
        '''
        domain_id = self.get_domain_id_by_domain_name(domain_name)
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agentid,domain_id,self.get_intents_id_by_domain_name(domain_name,intentname))
        r = requests.delete(constant.SERVER + url, headers=self.interface.headers, verify=False)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204

    def delete_domain_by_domain_id(self, domain_id):
        '''
        function:通过domain id删除自定义服务
        :param domain_id: domain id  str类型
        :return:
        '''
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        url = "/v2/ux/agents/{}/domains/{}".format(self.agentid,domain_id)
        r = requests.delete(constant.SERVER + url, headers=self.interface.headers, verify=False)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204

    def delete_domain_by_domain_name(self, domain_name):
        '''
        function:通过自定义服务名(domain名字)，删除自定义服务
        :param domain_name: domain名，就是自定义服务名  str类型
        :return:
        '''
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        domain_id = self.get_domain_id_by_domain_name(domain_name)
        url = "/v2/ux/agents/{}/domains/{}".format(self.agentid,domain_id)
        r = requests.delete(constant.SERVER + url, headers=self.interface.headers, verify=False)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204

    def get_domain_id_by_name(self, domain_type, domain_name):
        '''
        function:通过title名获取服务管理中的domainId
        :param domain_type: str类型；   0：系统服务； 1：自定义服务
        :param domain_name: 系统服务名 str类型
        :return:返回DomainId
        '''
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        url = "/v2/ux/agents/services"
        para = {"params": {'agentid': self.agentid, 'domaintype': domain_type}}
        pattern = "$..[?(@.name == '{}')].id".format(domain_name)
        ret = self.interface.sv_request(url, 'GET', parameter=para, pattern=pattern)
        print(ret)
        if ret[0]:
            return ret[0][0]
        return -1

    def get_domain_status_by_name(self, domain_type, domain_name):
        '''
        function:通过title名获取服务管理中子项的服务开启/关闭状态
        :param domain_type: str类型；   0：系统服务； 1：自定义服务
        :param domain_name: 系统服务名  str类型
        :return:返回DomainId
        '''
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        url = "/v2/ux/agents/services"
        para = {"params": {'agentid': self.agentid, 'domaintype': domain_type}}
        pattern = "$..[?(@.name == '{}')].enabled".format(domain_name)
        ret = self.interface.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret[0]:
            return ret[0][0]
        return -1

    def enable_domain_by_name(self, domain_type, domain_name):
        '''
        function:开启服务管理中子项开关
        :param domain_type: str类型；   0：系统服务； 1：自定义服务
        :param domain_name: 系统服务名  str类型
        :return:
        '''
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        url = "/v2/ux/agents/{}/domains/{}/enable".format(self.agentid, self.get_domain_id_by_name(domain_type, domain_name))
        # r = requests.get(constant.SERVER + url, headers=self.interface.headers, params={'domainid': 45}, verify=False)
        r = requests.get(constant.SERVER + url, headers=self.interface.headers, verify=False)
        return r.status_code == 200

    def disenable_domain_by_name(self, domain_type, domain_name):
        '''
        function:关闭服务管理中子项开关
        :param domain_type: domain类型；   0：系统服务； 1：自定义服务   str类型
        :param domain_name: 系统服务名  str类型
        :return:
        '''
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        url = "/v2/ux/agents/{}/domains/{}/disable".format(self.agentid, self.get_domain_id_by_name(domain_type, domain_name))
        data = {'domainid': 45}
        r = requests.post(constant.SERVER + url, headers=self.interface.headers, json=data, verify=False)
        return r.status_code == 200

    def get_sv_response_tts_text(self,question):
        '''
        function:获取sv问答返回文本
        :param question:问题，str类型
        :return:
        '''
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        sv_response = self.interface.question_test(question)
        # print(sv_response)
        if sv_response:
            tts_response_text =json.loads(sv_response['answer'])['tts'][0]['text']
            return tts_response_text
        else:
            print("Sv has no any result")
            return False

    def get_sv_response_source(self,question):
        '''
        function:获取sv问答返回source
        :param question:问题，str类型
        :return:
        '''
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        sv_response = self.interface.question_test(question)
        # print(sv_response)
        if sv_response:
            response_text =json.loads(sv_response['answer'])['source']
            return response_text
        else:
            print("Sv has no any result")
            return False

    def get_sv_response_action(self,question):
        '''
        function:获取sv问答返回活动
        :param question:问题，str类型$.hitlog.domain
        :return:
        '''
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        sv_response = self.interface.question_test(question)
        print(sv_response)
        if sv_response:
            response_text = json.loads(sv_response['answer'])["hitlog"]["domain"]
            return response_text
        else:
            print("Sv has no any result")
            return False
    #跳个舞吧，跳舞，SV返回内容与其他动作不同，修改如下
    def get_sv_response_action_dance(self,question):
        '''
        function:获取sv问答返回活动
        :param question:问题，str类型
        :return:
        '''
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        sv_response = self.interface.question_test(question)
        print(sv_response)
        if sv_response:
            response_text = json.loads(sv_response['answer'])["tts"][1]["action"]['name']
            return response_text
        else:
            print("Sv has no any result")
            return False
    def get_sv_response_action_dance_text(self,question):
        '''
        function:获取sv问答返回活动
        :param question:问题，str类型
        :return:
        '''
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        sv_response = self.interface.question_test(question)
        print(sv_response)
        if sv_response:
            response_text = json.loads(sv_response['answer'])["tts"][0]["text"]
            return response_text
        else:
            print("Sv has no any result")
            return False
    def get_sv_response_time(self,question):
        '''
        function:获取sv问答返回耗时
        :param question:问题，str类型
        :return: int型
        '''
        authinfo = self.interface.get_sv_authinfo(self.agentid)
        authinfo = json.loads(authinfo)
        url = '/v2/ux/agents/{}/smartqa/query'.format(authinfo['agentid'])
        para = {'params': {'question': question}}
        try:
            waste_time = requests.get(constant.SERVER + url, headers=self.interface.headers, params=para)
            return int(waste_time.elapsed.total_seconds())
        except:
            pass


    def get_datetime(self):
        '''
        function:获取当前日期  （2019-08-07）
        :return:
        '''
        return datetime.date.today()

    def get_agent_PID(self):
        '''
        获取agent的Pid
        :return:
        '''
        try:
            self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
            url = '/v2/ux/agents/{}/qa/types/list'.format(self.agentid)
            response = requests.get(constant.SERVER + url, headers=self.interface.headers, timeout=10, verify=False)
            print('response text: ', response.text, '\n')
            if "The agent don't belongs to this user" in response.text:
                print('不存在该agent id 在这个用户下面', response.text)
                return False
            else:
                dict_response = response.json()
                print('dict_response:', dict_response, '\n', type(dict_response))
                PID = dict_response[0]['id']
                print('Agent PID: ', PID)
                return PID
        except Exception as e:
            print(e)

    def get_agent_QA_dirname_types(self, dirname_type_value):
        '''
        获取问答文件夹名的类型id
        :param dirname_type_value:
        :return:
        '''
        try:
            self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
            typeid = self.get_agent_PID()
            url = '/v2/ux/agents/{}/qa/types/getsubtype?typeid={}'.format(self.agentid, typeid)
            response = requests.get(constant.SERVER + url, headers=self.interface.headers, timeout=10, verify=False)
            print('response text: ', response.text, '\n')
            dict_response = response.json()
            print('dict_response:', dict_response, '\n', type(dict_response))
            for i in range(len(dict_response)):
                name = dict_response[i]['name']
                typeID = dict_response[i]['id']
                print(name, ':', typeID)
                if str(dirname_type_value) == str(name):
                    print('打印该目录类的ID，及目录名称：', name, ':=:', typeID)
                    return typeID
                else:
                    print('继续寻找......  ')
            return False
        except Exception as e:
            print(e)

    def get_tag_INFO(self):
        '''
        获取tag info
        :return:
        '''
        try:
            self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
            url= '/v2/ux/agents/{}/qa/tag/?page=1&pagesize=10'.format(self.agentid)
            response = requests.get(constant.SERVER+url, headers=self.interface.headers, timeout=10, verify=False)
            print('response text: ', response.text)
            dict_response = response.json()
            return dict_response
        except Exception as e:
            print(e)

    def get_tag_ID(self, tagName):
        '''
        获取tag名
        :param tagName: tag名 str类型
        :return:
        '''
        try:
            tag_info = self.get_tag_INFO()
            if tag_info:
                tag_id = jsonpath.jsonpath(tag_info, expr='$.data[?(@.tag==\'{}\')].id'.format(tagName))
                print('tag_id: ', tag_id)
                return tag_id[0]
            else:
                print('不存在该标签', tag_info)
                return False
        except Exception as e:
            print(e)

    def add_qa(self, dirname, question, answer, question1='', answer1='', keywords= '', tag1='', tag2=''):
        '''
        添加自定义问答对
        :param dirname:文件夹名 str类型
        :param question:问题 str类型
        :param answer:答案 str类型
        :param question1: 问题1 str类型
        :param answer1:答案1 str类型
        :param keywords:关键字 str类型
        :param tag1:类型1 str类型
        :param tag2:类型2 str类型
        :return:
        '''
        try:
            self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
            dirname_value = self.get_agent_QA_dirname_types(dirname)
            print('dirname_value: ', dirname_value)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/'.format(self.agentid, dirname_value)
            data = {"tagids": [],"typeid": dirname_value, "questions": [{"question": question, "keyword": [keywords]}],
                    "answers": [answer], "emoji": "", "language": "", "groupname": ""}
            tag_value = []
            if tag1:
                tag_ID1 = self.get_tag_ID(tag1)
                tag_value = [tag_ID1]
                data['tagids'] = tag_value
                print('data tag:', data['tagids'] )
            if tag2:
                tag_ID2 = self.get_tag_ID(tag2)
                tag_value.append(tag_ID2)
                data['tagids'] = tag_value
                print('data tag:', data['tagids'])
            print('data tag id:', data['tagids'] )
            question_list = [{"question": question}]
            answers_list = [answer]
            if keywords:
                question_list = [{"question": question, "keyword": [keywords]}]
            if question1:
                question_list.append({"question": question1})
                data['questions'] = question_list
            if answer1:
                answers_list.append(answer1)
                data['answers'] = answers_list
            else:
                data['answers'] = [answer]
            print('data: ', data)
            response = requests.post(constant.SERVER + url, headers=self.interface.headers, json=data, timeout=10, verify=False)
            print('response text: ', response.text, '\n', response.status_code)
            if response.text == '' and response.status_code == 201:
                print('添加QA成功，')
                return True
            else:
                print('添加失败，', response.text)
                return False
        except Exception as e:
            print(e)

    def get_qa_info(self,dirname, question, answer):
        '''
        获取自定义问答中的信息
        :param dirname: 自定义问答文件夹名
        :param question: 问题
        :param answer: 答案
        :return:
        '''
        try:
            self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
            dirname_value = self.get_agent_QA_dirname_types(dirname)
            print('dirname_value: ', dirname_value)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/?page=1&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agentid,
                                                                                                      dirname_value,
                                                                                                      dirname_value)
            response = requests.get(constant.SERVER + url, headers=self.interface.headers, timeout=10, verify=False)
            print('response text: ', response.text, '\n')
            dict_response = response.json()
            total_pages = dict_response['pagination']['pagecount']
            total_items = dict_response['pagination']['itemcount']
            print('total_pages: ', total_pages, '\n', 'total_items: ', total_items)
            url1 = ['/v2/ux/agents/{}/qa/{}/qgroup/?page={}&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agentid,
                                                                                                         dirname_value,
                                                                                                         page,
                                                                                                         dirname_value)
                    for page in range(1, total_pages + 1)]
            print('url: ', url1)
            for ul in range(len(url1)):
                print(url1[ul])
                response1 = requests.get(constant.SERVER + url1[ul], headers=self.interface.headers, timeout=10, verify=False)
                print('response1 text: ', response1.text, '\n')
                dict_response1 = response1.json()
                print('dict_response1:', dict_response1, '\n', type(dict_response1))
                print('=== 开始Python处理JSON数据 ===')
                data1 = dict_response1['data']
                print('data1: ', data1, '\n', type(data1), len(data1))
                for i in range(len(data1)):
                    question_value = data1[i]['questions'][0]['question']
                    uuid_value = data1[i]['uuid']
                    for a in range(len(data1[i]['answers'])):
                        print(data1[i]['answers'][a])
                        answer_value = data1[i]['answers'][a]['answer']
                        print('问题：', question_value, ', 答案：', answer_value, ', uuid:', uuid_value)
                        if question_value == question and answer_value == answer:
                            print('找到正确答案，', data1[i])
                            print('data[i]: ', data1[i], '\n', type(data1[i]), '\n', len(data1[i]))
                            return data1[i]
                        else:
                            print('没有找到，继续寻找... ... ')
            return False
        except Exception as e:
            print(e)

    def get_qa_uuid(self,dirname, question, answer):
        '''
        获取问答的uuid
        :param dirname: 自定义问答文件夹名
        :param question: 问题
        :param answer: 答案
        :return:
        '''
        try:
            qa_info = self.get_qa_info(dirname, question, answer)
            if qa_info:
                print('qa_info:', qa_info)
                uuid = qa_info['uuid']
                print('打印uuid： ', uuid)
                return uuid
            else:
                print('没有找到这个QA，', qa_info)
                return False
        except Exception as e:
            print(e)

    def del_qa(self,dirname, question, answer):
        '''
        删除自定义问答
        :param dirname: 自定义问答文件夹名
        :param question: 问题
        :param answer: 答案
        '''
        try:
            self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
            dirname_value = self.get_agent_QA_dirname_types(dirname)
            print('dirname_value: ', dirname_value)
            qa_uid = self.get_qa_uuid(dirname, question, answer)
            print('qa_uid: ', qa_uid)
            if qa_uid:
                url = '/v2/ux/agents/{}/qa/{}/qgroup/{}'.format(self.agentid, dirname_value, qa_uid)
                print('url: ', url)
                response = requests.delete(constant.SERVER + url, headers=self.interface.headers, timeout=10, verify=False)
                print('response text: ', response.text, '\n', response.status_code)
                if response.text == '' and response.status_code == 204:
                    print('删除QA成功，')
                    return True
                else:
                    print('删除失败，')
                    return False
            else:
                print('已经不存在该QA了，', qa_uid)
                return False
        except Exception as e:
            print(e)

    def add_welcome_repeat_default_words(self, dirname, answer, answer1='',tag1='',tag2='', payload=''):
        '''
        删除问答中的默认回答、重复问题回答、迎宾语、开机语等问答
        :param dirname:自定义问答文件名
        :param answer:问题1
        :param answer1:问题2
        :param tag1:类型1
        :param tag2:类型2
        :param payload:
        :return:
        '''
        try:
            self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
            dirname_value = self.get_agent_QA_dirname_types(dirname)
            print('dirname_value: ', dirname_value)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/'.format(self.agentid, dirname_value)
            data = {"tagids":[],"typeid":dirname_value,"answers":[answer],"questions":[],"emoji":"😉",
                    "language":"","groupname":"","payload":payload}
            if answer1:
                data['answers'] = [answer, answer1]
            tag = []
            if tag1:
                tag_ID1 = self.get_tag_ID(tag1)
                tag.append(tag_ID1)
            if tag2:
                tag_ID2 = self.get_tag_ID(tag2)
                tag.append(tag_ID2)
            data['tagids'] = tag
            if payload:
                data['payload'] = payload
            print('data: ', data)
            response = requests.post(constant.SERVER + url, headers=self.interface.headers, json=data, timeout=10, verify=False)
            print('response text: ', response.text, '\n', response.status_code)
            if response.text == '' and response.status_code ==201:
                print('新增 %s 回答， 成功，' % dirname, response.text)
                return True
            else:
                print('增加失败')
                return False
        except Exception as e:
            print(e)

    def get_welcome_repeat_default_words_uuid(self, dirname, answer):
        try:
            self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
            dirname_value = self.get_agent_QA_dirname_types(dirname)
            print('dirname_value: ', dirname_value)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/?page=1&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agentid,
                                                                                                      dirname_value,
                                                                                                      dirname_value)
            response = requests.get(constant.SERVER + url, headers=self.interface.headers, timeout=10, verify=False)
            print('response text: ', response.text, '\n')
            dict_response = response.json()
            total_pages = dict_response['pagination']['pagecount']
            total_items = dict_response['pagination']['itemcount']
            print('total_pages: ', total_pages, '\n', 'total_items: ', total_items)
            url1 = ['/v2/ux/agents/{}/qa/{}/qgroup/?page={}&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agentid,
                                                                                                         dirname_value,
                                                                                                         page,
                                                                                                         dirname_value)
                    for page in range(1, total_pages + 1)]
            print('url: ', url1)
            for ul in range(len(url1)):
                print(url1[ul])
                response1 = requests.get(constant.SERVER + url1[ul], headers=self.interface.headers, timeout=10, verify=False)
                print('response1 text: ', response1.text, '\n')
                dict_response1 = response1.json()
                print('dict_response1:', dict_response1, '\n', type(dict_response1))
                print('=== 开始Python处理JSON数据 ===')
                data1 = dict_response1['data']
                print('data1: ', data1, '\n', type(data1), len(data1))
                for i in range(len(data1)):
                    print(data1[i])
                    answer_value = data1[i]['answers'][0]['answer']
                    uuid = data1[i]['uuid']
                    if answer == answer_value:
                        print('找到 %s, ' % dirname , answer_value, '\n', uuid)
                        return uuid
                    else:
                        print('继续寻找...')
                return False
            return False
        except Exception as e:
            print(e)

    def del_welcome_repeat_default_words(self, dirname, answer):
        '''
        删除问答中的默认回答、重复问题回答、迎宾语、开机语等问答
        :param dirname:自定义问答文件名
        :param answer:问题
        :return:
        '''
        try:
            self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
            dirname_value = self.get_agent_QA_dirname_types(dirname)
            print('dirname_value: ', dirname_value)
            uid = self.get_welcome_repeat_default_words_uuid(dirname, answer)
            if uid:
                url = '/v2/ux/agents/{}/qa/{}/qgroup/{}'.format(self.agentid,dirname_value,uid)
                response = requests.delete(constant.SERVER + url, headers=self.interface.headers, timeout=10, verify=False)
                print('response text: ', response.text, '\n', response.status_code)
                if response.text == '' and response.status_code ==204:
                    print('删除成功，', response.text)
                    return True
                else:
                    print('删除失败')
                    return False
            else:
                print('不存在该 %s' % dirname, uid)
                return False
        except Exception as e:
            print(e)

    def close_industry_button(self,typeid):
        '''
        关闭FAQ中子项问答的开关
        :param typeid: 子项的id, str类型
        :return:
        '''
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        url = "/v2/ux/agents/{}/faq/manage/types/{}/off?typeid={}".format(self.agentid,typeid,typeid)
        para = {"params": {'page': 1, 'pagesize': 10}}
        self.interface.sv_request(url=url, method='GET', parameter=para, pattern='')

    def open_industry_button(self,typeid):
        '''
        打开FAQ中子项问答的开关
        :param typeid: 子项的id, str类型
        :return:
        '''
        self.interface.get_sv_authinfo(self.agentid)  # 登录拿到所有的登陆后的authinfo
        url = "/v2/ux/agents/{}/faq/manage/types/{}/on?typeid={}".format(self.agentid,typeid,typeid)
        para = {"params": {'page': 1, 'pagesize': 10}}
        self.interface.sv_request(url=url, method='GET', parameter=para, pattern='')

    #baldwin add 20191119,问答测试前添加审核，同步，否则如为同步审核，问答测试会失败
    def get_login_cms_cookie(self):
        url = constant.CMS_SERVER+'/login'
        # token = self.create_get_token()
        headers = {'Content-Type': 'application/x-www-form-urlencoded','Cookie':'lang=zh-CN; JSESSIONID=71CB81B50EEFA54FB294CB066B813841; smartompsessionid=6c5173db3e1dca3d04ce0e2ca7759ebc'}
        print('初始化完毕')
        data = {'username': constant.CMS_USER, 'pwd': constant.CMS_PWD, 'captcha': '5555','captcha_id':'iSr3iZxgTbMA1h3','keep_pwd':'on'}
        print('data:-----', data)
        response = requests.post(url, headers=headers, params=data, verify=False)
        print("response---1--:",response,response.text)
        print("response---2--:", response.request._cookies._cookies[(constant.CMS_SERVER).split(':')[1][2:]]['/']['smartompsessionid'].value)
        new_token = response.request._cookies._cookies[(constant.CMS_SERVER).split(':')[1][2:]]['/']['smartompsessionid'].value
        # headers['Content-Type'] = 'text/html; charset=utf-8'
        Cookie_value = 'smartompsessionid={};lang=zh-CN'.format(new_token)
        headers['Cookie'] = Cookie_value
        print('CMS 登录成功 ... ')
        print("token",new_token)
        print("headers---",headers)
        # return new_token
        return headers
    def story_get_storyid(self,storyname):
        url = constant.CMS_SERVER + '/story/list'
        data = 'title={}&content=&type=0&p=1'.format(storyname)
        headers = self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        response = requests.post(url, headers=headers, params=data, verify=False)
        print("ssss", response, response.text)
        if response.status_code == 200:
            print(response.text)
            if 'title=' in response.text:
                print("搜索成功!!\n", response.text)
                r1 = re.search('title="ID:', response.text).span()
                print("jsonnn----:",r1)
                return response.text[r1[1]+1:r1[1]+5]#baldwin 修改，之前+4，其实还有问题，如果将来id达到5位的话，就还需要变，时间紧，暂时这样
            else:
                print("不存在此故事！！\n", response.text)
                return False
        else:
            print(response.status_code)
            return False

    #故事审核
    def story_sync(self,storyname):
        id = self.story_get_storyid(storyname)
        print("id------:",id,id[0])
        url = constant.CMS_SERVER + '/story/auditstoryajax'
        data = 'status=yes&id={}'.format(id)
        headers = self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        response = requests.post(url, headers=headers, params=data, verify=False)
        print("ssss",response,response.text)
        if "success" in response.text:
            print('审核成功')
            return True
        else:
            print('审核失败', response.text)
            return False


    def drama_get_dramaid(self,dramaname):
        url = constant.CMS_SERVER + '/news/list'
        data = 'query=title:{}'.format(dramaname)
        headers = self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        response = requests.get(url, headers=headers, params=data, verify=False)
        print("ssss", response, response.text)
        if response.status_code == 200:
            print(response.text)
            if 'title=' in response.text:
                print("搜索成功!!\n", response.text)
                r1 = re.search('title="ID:', response.text).span()
                print("jsonnn----:",r1)
                return response.text[r1[1]+1:r1[1]+4]#baldwin 修改，之前+4，其实还有问题，如果将来id达到5位的话，就还需要变，时间紧，暂时这样
            else:
                print("不存在此戏曲！！\n", response.text)
                return False
        else:
            print(response.status_code)
            return False
    #戏曲审核
    def drama_sync(self,dramaname):
        id = self.drama_get_dramaid(dramaname)
        print("id------------:",id)
        url = constant.CMS_SERVER + '/news/approvalajax'
        data = 'status=yes&id={}'.format(id)
        headers = self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        response = requests.post(url, headers=headers, params=data, verify=False)
        print("xxxx", response, response.text)
        if 'yes' in response.text:
            print('审核成功')
            return True
        else:
            print('审核失败', response.text)
            return False


    def crosstalk_get_crosstalkid(self,crosstalkname):
        url = constant.CMS_SERVER + '/news/list'
        data = 'query=title:{}'.format(crosstalkname)
        headers = self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        response = requests.get(url, headers=headers, params=data, verify=False)
        print("ssss", response, response.text)
        if response.status_code == 200:
            print(response.text)
            if 'title=' in response.text:
                print("搜索成功!!\n", response.text)
                r1 = re.search('title="ID:', response.text).span()
                print("jsonnn----:",r1)
                return response.text[r1[1]+1:r1[1]+4]#baldwin 修改，之前+4，其实还有问题，如果将来id达到5位的话，就还需要变，时间紧，暂时这样
            else:
                print("不存在此戏曲！！\n", response.text)
                return False
        else:
            print(response.status_code)
            return False
    #相声审核
    def crosstalk_sync(self,crosstalkname):
        id = self.crosstalk_get_crosstalkid(crosstalkname)
        url = constant.CMS_SERVER + '/news/approvalajax'
        data = 'status=yes&id={}'.format(id)
        headers = self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        response = requests.post(url, headers=headers, params=data, verify=False)
        print("xxxsss", response, response.text)
        if 'yes' in response.text:
            print('审核成功')
            return True
        else:
            print('审核失败', response.text)
            return False



    def poetry_get_poetryid(self,poetryname):
        url = constant.CMS_SERVER + '/poetry/list'
        data = 'query=title:{}'.format(poetryname)
        headers = self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        response = requests.get(url, headers=headers, params=data, verify=False)
        print("ssss", response, response.text)
        if response.status_code == 200:
            print(response.text)
            if 'title=' in response.text:
                print("搜索成功!!\n", response.text)
                r1 = re.search('title="ID:', response.text).span()
                print("jsonnn----:",r1)
                return response.text[r1[1]+1:r1[1]+4]#baldwin 修改，之前+4，其实还有问题，如果将来id达到5位的话，就还需要变，时间紧，暂时这样
            else:
                print("不存在此戏曲！！\n", response.text)
                return False
        else:
            print(response.status_code)
            return False
    #诗词审核
    def poetry_sync(self,poetryname):
        id = self.poetry_get_poetryid(poetryname)
        url = constant.CMS_SERVER + '/poetry/approvalpoetryajax'
        data = 'status=yes&id={}'.format(id)
        headers =self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        response = requests.post(url, headers=headers, params=data, verify=False)
        if 'yes' in response.text:
            print('审核成功')
            return True
        else:
            print('审核失败', response.text)
            return False




    def storytelling_get_storytellingid(self,storytellingname):
        url = constant.CMS_SERVER + '/news/list'
        data = 'query=title:{}'.format(storytellingname)
        headers = self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        response = requests.get(url, headers=headers, params=data, verify=False)
        print("ssss", response, response.text)
        if response.status_code == 200:
            print(response.text)
            if 'title=' in response.text:
                print("搜索成功!!\n", response.text)
                r1 = re.search('title="ID:', response.text).span()
                print("jsonnn----:",r1)
                return response.text[r1[1]+1:r1[1]+4]#baldwin 修改，之前+4，其实还有问题，如果将来id达到5位的话，就还需要变，时间紧，暂时这样
            else:
                print("不存在此戏曲！！\n", response.text)
                return False
        else:
            print(response.status_code)
            return False
    #评书审核
    def storytelling_sync(self,storytellingname):
        id = self.storytelling_get_storytellingid(storytellingname)
        url = constant.CMS_SERVER + '/news/approvalajax'
        data = 'status=yes&id={}'.format(id)
        headers =self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        print("审核headers---:",url,headers,data)
        response = requests.post(url, headers=headers, params=data, verify=False)
        if 'yes' in response.text:
            print('审核成功')
            return True
        else:
            print('审核失败', response)
            return False
