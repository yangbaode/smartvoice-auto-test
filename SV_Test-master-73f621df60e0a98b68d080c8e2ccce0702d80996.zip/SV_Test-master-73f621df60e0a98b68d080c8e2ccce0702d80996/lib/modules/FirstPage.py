from lib.modules.UiBase import UiBase
from lib.uilocators import uilocators
from lib.utils import constant
import time

class FirstPage(UiBase):
    
    

    def forgot_password(self):
        self.create_chrome_webdriver(constant.SERVER)
        self.wait_element_present(uilocators.login_page_forgot_password, 20)
        self.click_by_js(uilocators.login_page_forgot_password)
        self.wait_element_present(uilocators.login_page_forgot_code)
        self.selib.input_text("//nz-input[@formcontrolname='username']/input", constant.SV_USER)
        self.selib.input_text(uilocators.login_page_forgot_code, '55555555555')
    
    def go_to_information_center(self):
        self.wait_element_present(uilocators.nav_information_center, 15)
        self.click_by_js(uilocators.nav_information_center)
    
    def hittimes_by(self, duration='day'):
        if duration == 'month':
            self.selib.click_element(uilocators.info_summary_month_btn)
        elif duration == 'day':
            self.selib.click_element(uilocators.info_summary_day_btn)
        else:
            print('make sure all are in day or month')