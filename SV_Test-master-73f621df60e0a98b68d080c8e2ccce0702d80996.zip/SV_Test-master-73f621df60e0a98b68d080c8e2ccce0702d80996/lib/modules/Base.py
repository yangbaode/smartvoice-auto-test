# !/usr/bin/env python
# -*- coding: utf-8 -*-

from lib.utils import constant
import requests
import json
import jsonpath
import time
import datetime
import urllib.parse
from lib.utils.logger import logger
from lib.utils.JiraTool import JiraTool
from robot.libraries.BuiltIn import BuiltIn


class Base(object):
    def __init__(self, user, password):
        self.user = user
        self.password = password
        self.authinfo = {}
        self.headers = {'Accept': 'application/json, text/plain, */*','Proxy-Connection':'keep-alive', 'authinfo': self.authinfo}

    def login(self):
        logger.info("login process")
        headers = {'Connection': 'keep-alive',
         'Content-Type':'application/json',
         'Accept':'application/json, text/plain, */*'}
        url = '/v2/ux/user/login'
        data ={"username":self.user,"password":self.password}
        r = requests.post(constant.SERVER +url, headers=headers, json=data, timeout=15, verify=False)
        return r.json()

    def get_sv_authinfo(self, agent_id=None):
        '''
        登录方法,获取登录信息, 这是所有测试的基础, 后面的方法直接进行请求而无需关注登录
        :param agent_id: 传入的agentid,如果为空则是默认的agent id=121
        :return: 返回authinfo json, 同时会更改self.header和self.authinfo, 以便后面的方法直接进行请求而无需关注登录
        '''
        login_result = self.login()
        userid = login_result['userid']
        if not agent_id:
            agent_id = login_result['agentid']
        sessionid = login_result['sessionid']
        authtoken = login_result['authtoken']
        role = login_result['role']
        isadmin = login_result['isadmin']
        authinfo = {"userid": userid,
                    "authtoken": "{}".format(authtoken),
                    "sessionid": sessionid,
                    "agentid": agent_id,
                    "manualsel": True,
                    "userName": self.user,
                    "role": role,
                    "isadmin": isadmin,
                    "masteruserid": login_result['masteruserid'],
                    "lang": "zh-CN"}
        #print(self.authinfo)
        self.authinfo = json.dumps(authinfo)
        self.headers = {'Accept': 'application/json, text/plain, */*','Proxy-Connection':'keep-alive', 'authinfo': self.authinfo}
        return self.authinfo


    def sv_request(self, url, method, parameter={}, pattern="", timeout=25):
        """通用SV请求,可以用jsonpath规则搜索返回, 注,必须是返回json的response才可以用
        :param  url 请求的url
        :param  method  请求的类型, 为POST和GET两种目前
        :param  parameter   请求所携带的参数, 格式 为 dict, {'json': {'key1':value1, 'key2', value2}} 或 {'data': {}}
        :param  pattern 为jsonpath查找的pattern, 可选,如果没有这个参数将返回response.json()

        :return   元组: result,消耗时间   result为:response.json() 或 jsonpath查询的结果(是个list)
        """
        data = ""
        json_str = ""
        params = ""
        if 'json' in parameter.keys():
            json_str = parameter['json']
        if 'data' in parameter.keys():
            data = parameter['data']
        if 'params' in parameter.keys():
            params = parameter['params']
        r = None
        start = time.time()
        if method == 'POST':
            if json_str:
                r = requests.post(constant.SERVER + url, headers=self.headers, json=json_str, timeout=timeout, verify=False)
            elif data:
                r = requests.post(constant.SERVER + url, headers=self.headers, data=data,timeout=timeout, verify=False)
            else:
                print('method parameters error')
        elif method == "GET":
            if params:
                print("request parameters---:",constant.SERVER + url,self.headers,params)
                r = requests.get(constant.SERVER + url, headers=self.headers, params=params, timeout=timeout, verify=False)
            else: #params = None
                r = requests.get(constant.SERVER + url, headers=self.headers, verify=False)
        else:
            print('method only support POST and GET')
            logger.error('method only support POST and GET')
        duration = time.time() - start
        result = r
        # print('request result--:',r.text)
        try:
            result = r.json()
            if pattern:
                result = jsonpath.jsonpath(result, pattern)
            #print("URL:{} method:{} takes {} seconds, search {} with result:{}".format(url, method, duration, pattern, result))
            logger.debug(
                "URL:{} method:{} takes {} seconds, search {} with result:{}".format(url, method, duration, pattern, result))
            return result, duration
        except Exception as ex:
            print(ex)
            print(r.text)
            return result, duration

    def get_date_delta(self, days=0, detail=False):
        """获取当前日期,days=0, 如果days=-1就代表一天前的日期,正数就是多少天后"""
        delta = datetime.timedelta(days=abs(days))
        now = datetime.datetime.now()
        want_date = now
        if days < 0:
            want_date = now - delta
        else:
            want_date = now + delta
        if detail:
            return want_date.strftime("%Y-%m-%d %H:%M:%S")
        return want_date.strftime("%Y-%m-%d")

    def get_current_month(self):
        '''获取格式为:2019-07'''
        now = datetime.datetime.now()
        return now.strftime("%Y-%m")

    def verify_qa_answer(self, response_json, expected):
        '''
        验证qa问题返回结果
        :param response_json: 
        :param expected: 期望结果,用&&隔开,有1个计算pass
        :return: 
        '''
        js = json.loads(response_json['answer'])
        print('回答内容:', js)
        if expected in js['source']:
            #如果输入为source判断
            return True
        tts = js['tts'] #判断tts内容
        for e in expected.split("&&"):
            if e in str(tts):
                return True
        return False

    def put_result_to_jira(self):
        """在jira打结果,必须是teardown里面调用,否则出错
        系统中必须首先声明如下系统变量
        export JIRA_USER='alex.qi'
        export JIRA_PASSWORD='mypassword'
        export TEST_VERSION=v2.0
        export CYCLE_NAME="v2.0 test suite"
        #Case标题格式:  CV-12923,CV-23434 场测试名称
        """
        try:
            if constant.test_version=="" and constant.testcycle_name=="":
                print('Please check test version testcycle_name is empty??')
                return False

            if constant.jira_user=="" and constant.jira_pwd=="":
                print('Please check Jira user/password is empty??')
                return False

            test_name = BuiltIn().get_variable_value("${TEST NAME}")
            test_key = test_name.split()[0]
            if '-' not in test_key:
                print('no key found in test_key', test_key)
                return False
            test_status = BuiltIn().get_variable_value("${TEST STATUS}")
            jira = JiraTool(constant.jira_user, constant.jira_pwd)
            jira.login()
            for key in test_key.split(','):
                jira.set_execution_status(key, test_status, constant.test_version, constant.testcycle_name)
        except Exception as ex:
            print(ex)
            print('failed excute: stutus')

    def question_test(self, question):
        '''
        应用界面下的问答测试
        :param question: 问答
        :return: response json
        '''
        # questions = urllib.parse.quote(question)
        authinfo = json.loads(self.authinfo)
        # url = '/v2/ux/agents/{}/smartqa/query'.format(authinfo['agentid'])
        url = '/v2/ux/agents/{}/smartqa/query?question={}&hariVersion=v3'.format(constant.agent_id1,question)
        para = {'params': {'question': question,'hariVersion': 'v3'}}
        result = ""
        try:
            # result, _ = self.sv_request(url, 'GET', parameter=para, timeout=15)
            result, _ = self.sv_request(url, 'GET', timeout=15)
        except:
            pass
        return result

    def get_agentId_by_name(self, agent_name):
        '''
        提供agent名称,返回agentid
        :param agent_name: 
        :return: 
        '''
        url = '/v2/ux/agents/'
        para = {'params': {'keyword': agent_name, 'page': 1, 'pagesize': 10}}
        pattern = "$..data..[?(@.agentname=='{}')].id".format(agent_name)
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern, timeout=30)
        if ret:
            return ret[0][0]
        else:
            return -1

    def get_agentid_by_agentname(self, agent_name):
        verify_url = "/v2/ux/agents/select"
        pattern = "$..[?(@.agentname=='{}')].id".format(agent_name)
        ret = self.sv_request(verify_url, 'GET', pattern=pattern, timeout=10)
        if ret[0]:
            return ret[0][0]

    def get_agentname_by_id(self, agent_id):
        verify_url = "/v2/ux/agents/select"
        pattern = "$..[?(@.id=={})].agentname".format(agent_id)
        ret = self.sv_request(verify_url, 'GET', pattern=pattern, timeout=10)
        print(ret)
        if ret[0]:
            return ret[0][0]

    def add_new_application(self, agent_name, language='中文简体', timezone='UTC', longitude='116',
                            latitude='40', description='', gatewayurl=''):
        url = "/v2/ux/agents/add"
        data = {"json": {'agentname': agent_name, 'language': language, 'timezone': timezone, "longitude": longitude,
                'latitude': latitude, 'description': description, "gatewayurl": gatewayurl}}
        self.sv_request(url, 'POST', parameter=data, timeout=10)
        return self.get_agentid_by_agentname(agent_name)

