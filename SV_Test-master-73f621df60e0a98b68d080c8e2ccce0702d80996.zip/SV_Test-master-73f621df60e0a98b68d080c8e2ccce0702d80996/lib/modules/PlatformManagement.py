from requests_toolbelt import MultipartEncoder

from requests.cookies import RequestsCookieJar
from lib.modules.UiBase import UiBase
from lib.modules.Base import Base
from lib.uilocators import uilocators as pm
from selenium.webdriver.common.action_chains import ActionChains
from robot.libraries.BuiltIn import BuiltIn
import SeleniumLibrary
from lib.utils import constant
import time
import os
import json
import requests
import re
import xlrd
from urllib3 import encode_multipart_formdata
from lib.utils.logger import logger

class PlatformManagement(UiBase):

    # 笑话审核
    def story_joke(self, id):
        url = constant.CMS_SERVER + '/joke/auditjokeajax'
        data = 'status=yes&id={}'.format(id)
        headers = self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        response = requests.post(url, headers=headers, params=data, verify=False)
        print("ssss", response, response.text)
        if "success" in response.text:
            print('审核成功')
            return True
        else:
            print('审核失败', response.text)
            return False

    #故事审核
    def story_sync(self,id):
        url = constant.CMS_SERVER + '/story/auditstoryajax'
        data = 'status=yes&id={}'.format(id)
        headers = self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        response = requests.post(url, headers=headers, params=data, verify=False)
        print("ssss",response,response.text)
        if "success" in response.text:
            print('审核成功')
            return True
        else:
            print('审核失败', response.text)
            return False

    #戏曲审核
    def drama_sync(self,id):
        url = constant.CMS_SERVER + '/news/approvalajax'
        data = 'status=yes&id={}'.format(id)
        headers = self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        response = requests.post(url, headers=headers, params=data, verify=False)
        print("xxxx", response, response.text)
        if 'yes' in response.text:
            print('审核成功')
            return True
        else:
            print('审核失败', response.text)
            return False
    #相声审核
    def crosstalk_sync(self,id):
        url = constant.CMS_SERVER + '/news/approvalajax'
        data = 'status=yes&id={}'.format(id)
        headers = self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        response = requests.post(url, headers=headers, params=data, verify=False)
        print("xxxsss", response, response.text)
        if 'yes' in response.text:
            print('审核成功')
            return True
        else:
            print('审核失败', response.text)
            return False
    #诗词审核
    def poetry_sync(self,id):
        url = constant.CMS_SERVER + '/poetry/approvalpoetryajax'
        data = 'status=yes&id={}'.format(id)
        headers =self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        response = requests.post(url, headers=headers, params=data, verify=False)
        if 'yes' in response.text:
            print('审核成功')
            return True
        else:
            print('审核失败', response.text)
            return False
    #评书审核
    def storytelling_sync(self,id):
        url = constant.CMS_SERVER + '/news/approvalajax'
        data = 'status=yes&id={}'.format(id)
        headers =self.get_login_cms_cookie()
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        print("审核headers---:",url,headers,data)
        response = requests.post(url, headers=headers, params=data, verify=False)
        if 'yes' in response.text:
            print('审核成功')
            return True
        else:
            print('审核失败', response)
            return False

    def get_login_cms_cookie(self):
        url = constant.CMS_SERVER+'/login'
        token = self.create_get_token()
        headers = {'Content-Type': 'application/x-www-form-urlencoded','Cookie':'lang=zh-CN; JSESSIONID=71CB81B50EEFA54FB294CB066B813841; smartompsessionid=6c5173db3e1dca3d04ce0e2ca7759ebc'}
        print('初始化完毕')
        data = {'username': constant.CMS_USER, 'pwd': constant.CMS_PWD, 'captcha': '5555','captcha_id':'iSr3iZxgTbMA1h3','keep_pwd':'on'}
        print('data:-----', data)
        response = requests.post(url, headers=headers, params=data, verify=False)
        print("response---1--:",response,response.text)
        print("response---2--:", response.request._cookies._cookies[(constant.CMS_SERVER).split(':')[1][2:]]['/']['smartompsessionid'].value)
        new_token = response.request._cookies._cookies[(constant.CMS_SERVER).split(':')[1][2:]]['/']['smartompsessionid'].value
        # headers['Content-Type'] = 'text/html; charset=utf-8'
        Cookie_value = 'smartompsessionid={};lang=zh-CN'.format(new_token)
        headers['Cookie'] = Cookie_value
        print('CMS 登录成功 ... ')
        print("token",new_token)
        print("headers---",headers)
        # return new_token
        return headers


    def open_platformmanagement_navi(self):
        self.wait_element_visible(pm.nav_platform_management, 10)
        # print('111111111111111111')
        self.selib.click_element(pm.nav_platform_management)
    def open_skillmanagement(self):
        self.wait_element_visible(pm.top_bar_skill_management,5)
        self.selib.click_element(pm.top_bar_skill_management)
    def open_hit_counts(self):
        self.wait_element_visible(pm.top_bar_statistics, 10)
        self.selib.click_element(pm.top_bar_statistics)
        self.selib.click_element(pm.dropdown_hit_counts)
    def open_response_time(self):
        self.selib.click_element(pm.top_bar_statistics)
        self.selib.click_element(pm.dropdown_response_time)
    def open_sensitive_words(self):
        self.wait_element_visible(pm.top_bar_sensitive_words,5)
        self.selib.click_element(pm.top_bar_sensitive_words)
    def get_thead_text(self, item_num):  #skill=8  hit=7  sensitive=3
        #获取表头文字
        self.wait_element_visible(pm.skill_thead, 5)
        thead = []
        for i in range(1, item_num):
            ii = pm.skill_thead + "/th"+'[%d]' % i
            thead.append(self.selib.get_text(ii))
            item_num += 1
        return thead
    def get_skill_search_items(self):
        #获取技能管理搜索项名称
        skill_name = self.selib.get_text(pm.skill_name)
        data_resource = self.selib.get_text(pm.data_resource)
        skill_status = self.selib.get_text(pm.skill_status)
        online_start_time = self.selib.get_text(pm.online_start_time)
        online_end_time = self.selib.get_text(pm.online_end_time)
        lista = [skill_name, data_resource, skill_status, online_start_time, online_end_time]
        return lista
    def get_hits_search_items(self):
        #获取命中次数搜索项名称
        hits_skill_name = self.selib.get_text(pm.hits_skill_name)
        hits_data_resource = self.selib.get_text(pm.hits_data_resource)
        hits_service = self.selib.get_text(pm.hits_service)
        hits_user_name = self.selib.get_text(pm.hits_user_name)
        hits_agent_id = self.selib.get_text(pm.hits_agent_id)
        hits_agent_name = self.selib.get_text(pm.hits_agent_name)
        hits_start_time = self.selib.get_text(pm.hits_start_time)
        hits_end_time = self.selib.get_text(pm.hits_end_time)
        group_username = self.selib.get_text(pm.group_username)
        group_agent_id = self.selib.get_text(pm.group_agent_id)
        group_agent_name = self.selib.get_text(pm.group_agent_name)
        lista = [hits_skill_name, hits_data_resource, hits_service, hits_user_name, hits_agent_id, hits_agent_name, hits_start_time,  \
                hits_end_time, group_username, group_agent_id, group_agent_name]
        return lista
    def input_skill_name(self, para):
        #技能管理和命中次数页面通用
        self.selib.input_text(pm.skillname_input,para)
    def select_data_resource(self, opt_id):
        #技能管理和命中次数页面通用
        self.selib.click_element(pm.data_resource_selector)
        self.selib.click_element(pm.dropdown_selection+'[%d]'%(opt_id))     #1--all,2-self,3-thirdparty
    # def hits_select_data_resource(self, opt_id):
    #     #命中次数页面
    #     self.selib.click_element(pm.data_resource_selector)
    #     self.selib.click_element(pm.dropdown_selection+'['+opt_id+']')     #1--all,2-self,3-thirdparty
    def select_skill_status(self, opt_id):
        self.selib.click_element(pm.skill_status_selector)
        self.selib.click_element(pm.dropdown_selection+'[%d]'%(opt_id))     #1--all,2-enabled,3-disabled
    def input_online_time_start(self, starttime):
        self.selib.click_element(pm.start_time_control)
        self.selib.input_text(pm.time_input, starttime)              #格式:2019-08-08 11:38:31
        self.selib.click_element(pm.time_confirm)
    def input_online_time_end(self, endtime):
        self.selib.click_element(pm.end_time_control)
        self.selib.input_text(pm.time_input, endtime)                  #格式:2019-08-08 11:38:31
        self.selib.click_element(pm.time_confirm)
    def click_search_button(self):
        self.selib.click_element(pm.skill_search_button)
    def click_search_reset_button(self):
        self.selib.click_element(pm.skill_search_reset)
    def get_search_results(self):
        row1_skill_name = self.selib.get_text("//tbody/tr[1]/td[1]")      #tr的编号为行号，td编号是列号
        row1_skill_description = self.selib.get_text("//tbody/tr[1]/td[2]")
        row1_data_resource = self.selib.get_text("//tbody/tr[1]/td[3]")
        row1_skill_status = self.selib.get_text("//tbody/tr[1]/td[4]")
        row1_online_time = self.selib.get_text("//tbody/tr[1]/td[5]")
        row1_subscp_app_num = self.selib.get_text("//tbody/tr[1]/td[6]")
        lista = [row1_skill_name, row1_skill_description, row1_data_resource, row1_skill_status, row1_online_time]  #row1_subscp_app_num]
        return lista
    def get_total_num(self):
        #获取列表总条数
        num = self.selib.get_text(pm.total_num)#   共 31 条
        num = num[2:-2]
        return num
    def click_results_operation(self):
        self.selib.click_element("//tbody/tr[1]/td[7]/span")   #点击操作
    def click_contents_maintenance(self):
        self.selib.click_element("//tbody/tr[1]/td[7]/a")      #点击内容维护
    def get_skill_details(self):
        #获取技能详情数据
        details_skill_name = self.selib.get_text(pm.details_skill_name)
        details_data_resource = self.selib.get_text(pm.details_data_resource)
        details_skill_status = self.selib.get_text(pm.details_skill_status)
        details_online_time = self.selib.get_text(pm.details_online_time)
        details_skill_description = self.selib.get_text(pm.details_skill_description)
        details_subscp_app_num = self.selib.get_text(pm.details_subscp_app_num)
        details_service = self.selib.get_text(pm.details_service)
        lista = [details_skill_name, details_data_resource, details_skill_status, details_online_time, details_skill_description, details_service]
        return lista
    def click_review(self):
        #详情页点击审核
        self.selib.click_element(pm.details_review)
    def get_review_results(self):
        #获取审核结果
        review_skill_name = self.selib.get_text(pm.review_skill_name)
        review_service = self.selib.get_text(pm.review_service)
        review_response_time = self.selib.get_text(pm.review_response_time)
        review_response_results = self.selib.get_text(pm.review_response_results)
        lista = [review_skill_name, review_service, review_response_time, review_response_results]
        return lista

    # def login_with_interface(self, user, pwd):
    #     interface = Base(user, pwd)
    #     interface.get_sv_authinfo()
    #     return interface

    def get_skills(self):
        url = "/v2/ux/skill/"
        interface = self.login_with_interface()
        para = {"params": {'page': 1, 'pagesize': 1000, 'domainname': "", 'type': '', 'status': ''}}
        pattern = "$..Data"
        ret = interface.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret:
            return ret[0][0]
        return []

    def get_skill_id(self, domainname):
        all_skills = self.get_skills()
        for skill in all_skills:
            if skill['domainname'] == domainname:
                return skill['id']

        return -1

    def get_skill_agentid(self, domainname):
        all_skills = self.get_skills()
        for skill in all_skills:
            if skill['domainname'] == domainname:
                return skill['agentid']

        return -1

    def get_service_info_by_name(self, service_name):
        interface = Base(constant.SV_USER, constant.SV_PWD)
        interface.get_sv_authinfo()
        url = "/v2/ux/agents/services"
        para = {'params': {'agentid': constant.ADMIN_AGENT_ID, 'domaintype': 0}}
        pattern = "$..[?(@.name=='{}')]".format(service_name)
        ret = interface.sv_request(url, 'GET', parameter=para, pattern=pattern)
        print('current service info:', ret[0][0])
        return ret[0][0]

    def set_status_for_service(self, service_name, status):
        service_info = self.get_service_info_by_name(service_name)
        interface = Base(constant.SV_USER, constant.SV_PWD)
        interface.get_sv_authinfo()
        service_id = service_info['id']
        print(service_id)
        service_status = service_info['enabled']
        print(service_status)
        print('current status is :', service_status)
        if service_status == status:
            return True
        if status == 'disabled':
            url = "/v2/ux/agents/{}/domains/{}/disable".format(constant.ADMIN_AGENT_ID, service_id)
            print(url)
            para = {'json': {'domainid': service_id}}
            try:
                interface.sv_request(url, 'POST', parameter=para)
            except:
                pass
        if status == 'enabled':
            url = "/v2/ux/agents/{}/domains/{}/enable".format(constant.ADMIN_AGENT_ID, service_id)
            print(url)
            para = {'params': {'domainid': service_id}}
            try:
                interface.sv_request(url, 'GET', parameter=para)
            except:
                pass
        service_info = self.get_service_info_by_name(service_name)
        return service_info['enabled']
    def get_service_info(self, service_name):
        '''
        通过服务名获取服务相关信息
        :param service_name: 服务名
        :return:
        '''
        interface = Base(constant.SV_ADMIN, constant.SV_ADMIN_PWD)
        aa = interface.get_sv_authinfo()
        print(aa)
        url = "/v2/ux/agents/{}/domains".format(constant.ADMIN_AGENT_ID)
        para = {'params':{'page': 1, 'pagesize': 50}}
        pattern= "$.[?(@.domainname=='{}')]".format(service_name)
        print(url)
        print(para)
        ret = interface.sv_request(url, method='GET', parameter=para, pattern=pattern)
        return ret
    # def get_service_agent_id(self,service_name, agent_name):
    #     service_info = self.get_service_info_by_name(service_name)
    #     service_status = service_info['enabled']
    #     service_id = service_info['id']
    #     interface = Base(constant.SV_USER, constant.SV_PWD)
    #     interface.get_sv_authinfo()
    #     url = "/v2/ux/skill/{}/agents".format(service_id)
    #     para = {'params':{'domainid': service_id, 'page': 1, 'pagesize': 100}}
    #     pattern= "$.[?(@.agentname=='{}')].userid".format(agent_name)
    #     if not service_status:
    #         try:
    #             print("1111")
    #             ret = interface.sv_request(url, 'GET', parameter=para, pattern=pattern)
    #             return ret[0][0]
    #         except:
    #             pass
    #     else:
    #         ret = interface.sv_request(url, 'GET', parameter=para, pattern=pattern)
    #         return ret[0][0]

    def bl_get_sv_response_source(self, question):
        '''
        function:获取sv问答返回source
        :param question:问题，str类型
        :return:
        '''
        interface = Base(constant.SV_USER, constant.SV_PWD)
        interface.get_sv_authinfo(constant.agent_id1)
        sv_response = interface.question_test(question)
        # print(sv_response)
        if sv_response:
            response_text = json.loads(sv_response['answer'])['source']
            return response_text
        else:
            print("Sv has no any result")
            return False
    def get_sv_response_text(self, question):
        '''
        function:获取sv问答返回text
        :param question:问题，str类型
        :return:
        '''
        interface = Base(constant.SV_USER, constant.SV_PWD)
        interface.get_sv_authinfo()
        sv_response = interface.question_test(question)
        print(sv_response)
        # print(sv_response)
        if sv_response:
            response_text = json.loads(sv_response['answer'])['tts'][0]['text']
            return response_text
        else:
            print("Sv has no any result")
            return False
    def get_sv_response_url(self, question):
        '''
        function:获取sv问答返回text
        :param question:问题，str类型
        :return:
        '''
        interface = Base(constant.SV_USER, constant.SV_PWD)
        interface.get_sv_authinfo()
        sv_response = interface.question_test(question)
        print(sv_response)
        # print(sv_response)
        if sv_response:
            response_text = json.loads(sv_response['answer'])['tts'][0]['action']['param']['url']
            return response_text
        else:
            print("Sv has no any result")
            return False
    def get_response_time_by_min(self, starttime, endtime):
        '''
        平台管理-获取分钟维度的响应数据
        :param starttime:  格式：2019-07-27 00:00:00
        :param endtime:          2019-07-29 23:59:59
        :return:
        '''
        interface = Base(constant.SV_USER, constant.SV_PWD)
        interface.get_sv_authinfo()
        url = "/v2/ux/statistics/responsetime/domain"
        para = {'params':{'level': 'minute', 'startdate': starttime, 'enddate': endtime}}
        pattern= "$..responsetime"
        ret = interface.sv_request(url, method='GET', parameter=para, pattern=pattern)
        return ret

    def get_response_time_by_hour(self, starttime, endtime):
        '''
        平台管理-获取小时维度的响应数据
        :param starttime:  格式：2019-07-27 00:00:00
        :param endtime:          2019-07-29 23:59:59
        :return:
        '''
        interface = Base(constant.SV_USER, constant.SV_PWD)
        interface.get_sv_authinfo()
        url = "/v2/ux/statistics/responsetime/domain"
        para = {'params':{'level': 'hour', 'startdate': starttime, 'enddate': endtime}}
        pattern= "$..responsetime"
        ret = interface.sv_request(url, method='GET', parameter=para, pattern=pattern)
        return ret
    def get_response_time_by_day(self, starttime, endtime):
        '''
        平台管理-获取天维度的响应数据
        :param starttime:  格式：2019-07-27 00:00:00
        :param endtime:          2019-07-29 23:59:59
        :return:
        '''
        interface = Base(constant.SV_USER, constant.SV_PWD)
        interface.get_sv_authinfo()
        url = "/v2/ux/statistics/responsetime/domain"
        para = {'params':{'level': 'day', 'startdate': starttime, 'enddate': endtime}}
        pattern= "$..responsetime"
        ret = interface.sv_request(url, method='GET', parameter=para, pattern=pattern)
        return ret

    def get_statistime_by_hour(self, starttime, endtime):
        '''
        平台管理-获取统计时间
        :param starttime:  格式：2019-07-27 00:00:00
        :param endtime:          2019-07-29 23:59:59
        :return:
        '''
        interface = Base(constant.SV_USER, constant.SV_PWD)
        interface.get_sv_authinfo()
        url = "/v2/ux/statistics/responsetime/domain"
        para = {'params':{'level': 'hour', 'startdate': starttime, 'enddate': endtime}}
        pattern= "$..statistime"
        ret = interface.sv_request(url, method='GET', parameter=para, pattern=pattern)
        return ret[0]
    def get_sv_session_id(self):
        interface = Base(constant.SV_OPERATOR, constant.SV_OPERATOR_PWD)
        itf = interface.get_sv_authinfo()
        it = json.loads(itf)
        session_id = it['sessionid']
        return session_id
    def get_sv_session(self):
        session = requests.Session()
        logger.info("login SV")
        headers = {'Connection': 'keep-alive',
         'Content-Type':'application/json',
         'Accept':'application/json, text/plain, */*'}
        url = '/v2/ux/user/login'
        session.headers = headers
        data ={"username":constant.SV_OPERATOR,"password":constant.SV_OPERATOR_PWD}
        # cookie_jar = RequestsCookieJar()
        # cookie_jar.set("BAIDUID", "B1CCDD4B4BC886BF99364C72C8AE1C01:FG=1", domain="baidu.com")
        res = session.post(constant.SERVER +url, headers=headers, json=data, timeout=15, verify=False)  #, cookies=cookie_jar

        print(res.text)
        print(type(session))
        print(res.headers)
        print(session.headers)
        print(res.request.headers)
        print(res.cookies)

        logger.info("login CMS")
        # constant.CMS_SERVER = "http://10.155.0.135:32170"
        url = constant.CMS_SERVER + "/news/list"
        headers1 = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Proxy-Connection': 'keep-alive'}
        data = {'title': "一曲相思"}
        r = session.post(url, headers=headers1, data=data)   #
        print(r.text)

    def create_get_token(self):
        interface = Base(constant.SV_OPERATOR, constant.SV_OPERATOR_PWD)
        auth_info = interface.get_sv_authinfo()
        headers = {'Accept': 'application/json, text/plain, */*','Proxy-Connection':'keep-alive', 'authinfo': auth_info}
        url = "/v2/ux/platform/token"
        r = requests.get(constant.SERVER + url, headers=headers, verify=False)
        if r.status_code == 200:
            self.cms_token = r.json()["token"]
            print(self.cms_token)
            return self.cms_token
        else:
            print(r.status_code)
            print('get cms token fail')
            return None
    def get_smartompsessionid(self):
        cms_token = self.create_get_token()
        interface = Base(constant.SV_OPERATOR, constant.SV_OPERATOR_PWD)
        auth_info = interface.get_sv_authinfo()
        headers = {'Accept': 'application/json, text/plain, */*', 'Proxy-Connection': 'keep-alive',
                             'authinfo': auth_info}

        url = constant.CMS_SERVER+"/index/index?jump=/joke/list?lang=zh-CN&token={}".format(cms_token)
        r = requests.get(url, headers=headers, verify=False)
        cms_host = constant.CMS_SERVER[7:-6]
        if r.status_code == 200:
            print(r.cookies._cookies)
            smartompsessionid = r.cookies._cookies[cms_host]['/']['smartompsessionid'].value
            print(smartompsessionid)
            return smartompsessionid
        else:
            print('get smartompsessionid fail')
            return None

    def cms_add_joke(self, session_id, content):
        '''
        CMS新增笑话接口
        para: content
        '''
        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"% session_id}
        print(headers)
        url = constant.CMS_SERVER + "/joke/add"
        data={'tag': '冷','content': content,
                        'id':'',
                        'submit':'',
                        'status':'on',
                        'is_change':''}
        r = requests.post(url, headers=headers, data=data)
        print(r.status_code)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~添加成功!" in r.text:
                print("新增笑话成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)

    def cms_search_joke(self, session_id, title):
        '''
        CMS搜索笑话接口
        para: title
        '''
        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/joke/list"
        data={'title': title,
              'tag':'',
              'p':'1'}
        r = requests.post(url, headers=headers, data=data)
        if r.status_code == 200:
            if 'title=' in r.text:
                print("搜索成功!!\n", r.text)
                r1 = re.search('title="ID:', r.text).span()
                return r.text[r1[1]+1:r1[1]+5]
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    def cms_delete_joke(self, session_id, id):
        '''
        CMS删除笑话接口
        para: joke_id     --  删除前需要搜索数据获取其id，作为参数
        '''
        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/joke/del/id/" + str(id)   # 需要通过搜索接口获取id
        r = requests.get(url, headers=headers)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~删除成功！" in r.text:
                print("删除笑话成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)

    def cms_edit_joke(self, session_id, id, content):
        '''
        CMS编辑笑话接口
        para: joke_id
              content
        '''
        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/joke/edit/id/"+str(id)
        data={'tag': '冷',
              'content': content,
              'id': id,
              'submit': '',
              'status': 'on',
              'is_change': 'no'}
        r = requests.post(url, headers=headers, data=data)
        print(r.status_code)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~修改成功!" in r.text:
                print("修改笑话成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    def cms_add_story(self, session_id, title, content):
        '''
        CMS新增故事接口
        para: title
             content
        '''
        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/story/add"
        data={'id': '',
              'title': title,
              'type': '亲情故事',
              'content': content,
              'submit':'',
              'status':'on',
              'is_change':''}
        r = requests.post(url, headers=headers, data=data)
        print(r.status_code)
        if u"恭喜 ^ _ ^ ! ~添加成功!" in r.text:
            print("新增故事成功!!\n", r.text)
            return r.text
        elif "Please enter your account name" in r.text:
            print("用户未登录！！\n", r.text)
    def cms_search_story(self, session_id, title):
        '''
        CMS搜索故事接口
        para: title
        '''
        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/story/list"
        data={'title': title,
              'content':'',
              'tag':'0',
              'p':'1'}
        r = requests.post(url, headers=headers, data=data)
        if r.status_code == 200:
            if 'title=' in r.text:
                print("搜索成功!!\n", r.text)
                r1 = re.search('title="ID:', r.text).span()
                print("story-id-----:",r1)
                print("id------------:",r.text[r1[1]+1:r1[1]+5],r.text[r1[1]+1:r1[1]+4])
                return r.text[r1[1]+1:r1[1]+5]
            # if 'cid=' in r.text:
            #     print("搜索故事成功!!\n", r.text)
            #     r1 = re.search('cid=', r.text).span()
            #     return r.text[r1[1]:r1[1] + 4]
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    def cms_edit_story(self, session_id, id, title, content):
        '''
        CMS编辑故事接口
        para: id
              content
        '''
        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/story/edit/id/"+str(id)
        data={'id': id,
              'title': title,
              'content': content,
              'submit': '',
              'status': 'on',
              'is_change': 'no'}
        r = requests.post(url, headers=headers, data=data)
        print(r.status_code)
        if r.status_code == 200:
            if r.status_code == 200:
                if u"恭喜 ^ _ ^ ! ~修改成功!" in r.text:
                    print("修改故事成功!!\n", r.text)
                    return r.text
                elif "Please enter your account name" in r.text:
                    print("用户未登录！！\n", r.text)
    def cms_delete_story(self, session_id, id):
        '''
        CMS删除故事接口
        para: story_id     --  删除前需要搜索数据获取其id，作为参数
        '''
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Proxy-Connection': 'keep-alive',
            "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/story/del/id/" + str(id)  # 需要通过搜索接口获取id
        r = requests.get(url, headers=headers)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~删除成功！" in r.text:
                print("删除故事成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    def cms_add_poetry(self, session_id, title, content):
        '''
        CMS新增诗词接口
        para: title
             content
        '''
        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/poetry/add"
        data={'id': '',
              'authorid': '',
              'title': title,
              'name': '',
              'dynasty': '',
              'type':'',
              'tagname': '',
              'content': content,
              'phrase':'',
              'translate': '',
              'submit':'',
              'status':'on',
              'is_change':''}
        r = requests.post(url, headers=headers, data=data)
        print("+++++++++++++",r.status_code)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~添加成功!" in r.text:
                print("新增诗词成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)

    def cms_search_poetry(self, session_id, title):
        '''
        CMS搜索诗词接口
        para: title
        '''
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Proxy-Connection': 'keep-alive',
            "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/poetry/list"
        data = {'title': title}
        r = requests.post(url, headers=headers, data=data)
        if r.status_code == 200:
            if 'title=' in r.text:
                print("搜索成功!!\n", r.text)
                r1 = re.search('title="ID:', r.text).span()
                return r.text[r1[1]+1:r1[1]+5]
            # if 'cid=' in r.text:
            #     print("搜索笑话成功!!\n", r.text)
            #     r1 = re.search('cid=', r.text).span()
            #     return r.text[r1[1]:r1[1] + 4]
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    def cms_edit_poetry(self, session_id, id, title, content):
        '''
        CMS编辑诗词接口
        para: id
              content
        '''
        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/poetry/edit/id/"+str(id)
        print("------------:",id, title, content)
        data={'id': id,
              'authorid': '0',
              'title': title,
              'name': '',
              'dynasty': '',
              'type':'',
              'tagname': '',
              'content': content,
              'phrase':'',
              'translate': '',
              'submit':'',
              'status':'on',
              'is_change':'no'}
        r = requests.post(url, headers=headers, data=data)
        print(r.status_code)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~修改成功!" in r.text:
                print("修改诗词成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    def cms_delete_poetry(self, session_id, id):
        '''
        CMS删除诗词接口
        para: id     --  删除前需要搜索数据获取其id，作为参数
        '''
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Proxy-Connection': 'keep-alive',
            "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/poetry/del/id/" + str(id)  # 需要通过搜索接口获取id
        r = requests.get(url, headers=headers)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~删除成功！" in r.text:
                print("删除诗词成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    #baldwin 重新写诗词添加，搜索，编辑，删除函数，及token获取方式，现在运营账号没有权限审核，全部在admin下操作
    def get_adminlogin_cms_token(self):
        url = constant.CMS_SERVER+'/login'
        token = self.create_get_token()
        headers = {'Content-Type': 'application/x-www-form-urlencoded','Cookie':'lang=zh-CN; JSESSIONID=71CB81B50EEFA54FB294CB066B813841; smartompsessionid=6c5173db3e1dca3d04ce0e2ca7759ebc'}
        print('初始化完毕')
        data = {'username': constant.CMS_USER, 'pwd': constant.CMS_PWD, 'captcha': '5555','captcha_id':'iSr3iZxgTbMA1h3','keep_pwd':'on'}
        print('data:-----', data)
        response = requests.post(url, headers=headers, params=data, verify=False)
        print("response---1--:",response,response.text)
        print("response---2--:", response.request._cookies._cookies[(constant.CMS_SERVER).split(':')[1][2:]]['/']['smartompsessionid'].value)
        new_token = response.request._cookies._cookies[(constant.CMS_SERVER).split(':')[1][2:]]['/']['smartompsessionid'].value
        return new_token


    def sv_cms_add_poetry(self, token, title, content):
        '''
        CMS新增诗词接口
        para: title
             content
        '''
        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%token}
        url = constant.CMS_SERVER + "/poetry/add"
        data={'id': '',
              'authorid': '',
              'title': title,
              'name': '',
              'dynasty': '',
              'type':'',
              'tagname': '',
              'content': content,
              'phrase':'',
              'translate': '',
              'submit':'',
              'status':'on',
              'is_change':''}
        r = requests.post(url, headers=headers, data=data)
        print("+++++++++++++",r.status_code)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~添加成功!" in r.text:
                print("新增诗词成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)

    def sv_cms_search_poetry(self, token, title):
        '''
        CMS搜索诗词接口
        para: title
        '''
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Proxy-Connection': 'keep-alive',
            "Cookie": "lang=zh-CN; smartompsessionid=%s"%token}
        url = constant.CMS_SERVER + "/poetry/list"
        data = {'title': title}
        r = requests.post(url, headers=headers, data=data)
        if r.status_code == 200:
            if 'title=' in r.text:
                print("搜索成功!!\n", r.text)
                r1 = re.search('title="ID:', r.text).span()
                return r.text[r1[1]+1:r1[1]+5]
            # if 'cid=' in r.text:
            #     print("搜索笑话成功!!\n", r.text)
            #     r1 = re.search('cid=', r.text).span()
            #     return r.text[r1[1]:r1[1] + 4]
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    def sv_cms_edit_poetry(self, token, id, title, content):
        '''
        CMS编辑诗词接口
        para: id
              content
        '''
        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%token}
        url = constant.CMS_SERVER + "/poetry/edit/id/"+str(id)
        print("------------:",id, title, content)
        data={'id': id,
              'authorid': '0',
              'title': title,
              'name': '',
              'dynasty': '',
              'type':'',
              'tagname': '',
              'content': content,
              'phrase':'',
              'translate': '',
              'submit':'',
              'status':'on',
              'is_change':'no'}
        r = requests.post(url, headers=headers, data=data)
        print(r.status_code)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~修改成功!" in r.text:
                print("修改诗词成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    def sv_cms_delete_poetry(self, token, id):
        '''
        CMS删除诗词接口
        para: id     --  删除前需要搜索数据获取其id，作为参数
        '''
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Proxy-Connection': 'keep-alive',
            "Cookie": "lang=zh-CN; smartompsessionid=%s"%token}
        url = constant.CMS_SERVER + "/poetry/del/id/" + str(id)  # 需要通过搜索接口获取id
        r = requests.get(url, headers=headers)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~删除成功！" in r.text:
                print("删除诗词成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    #baldwin 重新构造诗词相应功能
    def cms_add_crosstalk(self, session_id, title, author, keyword, audio_link):
        '''
        CMS新增相声接口
        para: title
             content
        '''
        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/news/add"
        cms_host = constant.CMS_SERVER[7:] + '/'
        data={'status': 'on',
              'is_change': 'on',
              'submit':'',
              'id':'',
              'host': cms_host,
              'title': title,
              'author': author,
              'keyword': keyword,
              'time_span': '1',
              'videourl': '',
              'v_localHide':'',
              'video_link':'',
              'audiourl': '',
              'a_localHide':'',
              'audio_link': audio_link,
              'departmentID': '12',
              'categoryId': '12',
              'categoryName': '相声',
              'categoryNameOld': '请选择分类',
              'categoryIdOld':'',
              'describe': '1',
              'img_url': '',
        }
        r = requests.post(url, headers=headers, data=data)
        print(r.status_code)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~添加成功!" in r.text:
                print("新增相声成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    def cms_edit_crosstalk(self, session_id, id, title, author, audio_link1, audio_link2):
        '''
        CMS修改相声接口
        para: title
             content
        '''
        headers = {   #'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/news/edit/id/"+str(id)
        cms_host = constant.CMS_SERVER[7:] + '/'
        data={'status': 'on',
              'is_change': 'on',
              'submit':'',
              'id': id,
              'host': cms_host,
              'title': title,
              'author': author,
              'keyword': '',
              'time_span': '1',
              'videourl': '',
              'v_localHide':'',
              'video_link':'',
              'audiourl': '',
              'a_localHide': audio_link1,
              'audio_link': audio_link2,
              'departmentID': '12',
              'categoryId': '12',
              'categoryName': '相声',
              'categoryNameOld': '相声',
              'categoryIdOld':'12',
              'describe': '1',
              'img_url': '',
        }
        r = requests.post(url, headers=headers, data=data)
        print(r.status_code)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~修改成功!" in r.text:
                print("修改相声成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)

    def cms_edit_storytelling(self, session_id, id, title, author, audio_link1, audio_link2):
        '''
        CMS修改评书接口
        para: title
             content
        '''
        headers = {   #'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/news/edit/id/"+str(id)
        cms_host = constant.CMS_SERVER[7:] + '/'
        data={'status': 'on',
              'is_change': 'on',
              'submit':'',
              'id': id,
              'host': cms_host,
              'title': title,
              'author': author,
              'keyword': '',
              'time_span': '1',
              'videourl': '',
              'v_localHide':'',
              'video_link':'',
              'audiourl': '',
              'a_localHide': audio_link1,
              'audio_link': audio_link2,
              'departmentID': '13',
              'categoryId': '13',
              'categoryName': '评书',
              'categoryNameOld': '评书',
              'categoryIdOld':'13',
              'describe': '1',
              'img_url': '',
        }
        print("==========",url,headers,data)
        r = requests.post(url, headers=headers, data=data)
        print(r.status_code)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~修改成功!" in r.text:
                print("修改成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    def cms_edit_drama(self, session_id, id, title, author, audio_link1, audio_link2):
        '''
        CMS修改戏曲接口
        para: title
             content
        '''


        headers = {   #'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/news/edit/id/"+str(id)
        cms_host = constant.CMS_SERVER[7:] + '/'
        data={'status': 'on',
              'is_change': 'on',
              'submit':'',
              'id': id,
              'host': cms_host,
              'title': title,
              'author': author,
              'keyword': '',
              'time_span': '1',
              'videourl': '',
              'v_localHide':'',
              'video_link':'',
              'audiourl': '',
              'a_localHide': audio_link1,
              'audio_link': audio_link2,
              'departmentID': '8',
              'categoryId': '8',
              'categoryName': '戏曲',
              'categoryNameOld': '戏曲',
              'categoryIdOld':'8',
              'describe': '1',
              'img_url': '',
        }
        r = requests.post(url, headers=headers, data=data)
        print(r.status_code)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~修改成功!" in r.text:
                print("修改成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    def cms_add_audio(self,id):

        '''
        # CMS相声添加音频
        smartompsessionid已写死
        para: id
              content
        '''
        print(id)
        dir = os.path.abspath(os.path.join(os.getcwd()))
        print(dir)
        file_path = dir + os.sep + 'testdata' + os.sep + 'Songs About You.mp3'
        print(file_path)
        # file_payload = {'file': ('Songs About You.mp3', open(file_path, 'rb'))}
        file_payload = {'file': open(file_path, 'rb')}
        print('file_payload: ', file_payload)
        m = MultipartEncoder(file_payload)

        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=172ae191e784c894d410646a184535cb"}
        headers['Content-Type'] = m.content_type
        url = constant.CMS_SERVER + "/news/edit/id/"+str(id)
        data={'Content-Disposition': 'form-data; name="audiourl"; filename="Songs About You.mp3"',
              'Content-Type': 'audio/mp3'}
        r = requests.post(url, headers=headers, files=file_payload, data=data, verify=False)
        print(r.status_code)
        print(r.text)
        # if r.status_code == 200:
        #     print("添加音频成功!", r.text)
        #     return r.text
        # else:
        #     print("添加音频失败！", r.text)
        #     return r.text
    def cms_delete_crosstalk(self, session_id, id):
        '''
        CMS删除相声接口
        para: id     --  删除前需要搜索数据获取其id，作为参数
        '''
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Proxy-Connection': 'keep-alive',
            "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/news/del/id/" + str(id)  # 需要通过搜索接口获取id
        r = requests.get(url, headers=headers)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~删除成功！" in r.text:
                print("删除成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)



    def cms_search_crosstalk(self, session_id, title):
        '''
        CMS搜索相声接口
        para: title
        '''
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Proxy-Connection': 'keep-alive',
            "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        # para = {'title': title}
        url = constant.CMS_SERVER+'/news/list?query=title:{}'.format(title)
        print(url)
        r = requests.get(url, headers=headers)
        if r.status_code == 200:
            print(r.text)
            if 'title=' in r.text:
                print("搜索成功!!\n", r.text)
                r1 = re.search('title="ID:', r.text).span()
                print("jsonnn----:",r1)
                return r.text[r1[1]+1:r1[1]+5]#baldwin 修改，之前+4，其实还有问题，如果将来id达到5位的话，就还需要变，时间紧，暂时这样
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
        else:
            print(r.status_code)
    def cms_add_storytelling(self, session_id, title, author, keyword):
        '''
        CMS新增评书接口-不带音频
        para: title
             content
        '''
        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id
                   }
        url = constant.CMS_SERVER + "/news/add"
        cms_host = constant.CMS_SERVER[7:] + '/'
        data={'status': 'on',
              'is_change': '',
              'submit':'',
              'id':'',
              'host': cms_host,
              'title': title,
              'author': author,
              'keyword': keyword,
              'time_span': '1',
              'videourl': '',
              'v_localHide':'',
              'video_link':'',
              'audiourl': '',
              'a_localHide':'',
              'audio_link':'',
              'departmentID': '13',
              'categoryId': '13',
              'categoryName': '评书',
              'categoryNameOld': '请选择分类',
              'categoryIdOld':'',
              'describe': '1',
              'img_url': '',
        }
        r = requests.post(url, headers=headers, data=data)
        print(r.status_code)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~添加成功!" in r.text:
                print("新增成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    def cms_add_drama(self, session_id, title, author, keyword):
        '''
        CMS新增戏剧接口-不带音频
        para: title
             content
        '''


        headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'Proxy-Connection': 'keep-alive',
                             "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/news/add"
        cms_host = constant.CMS_SERVER[7:] + '/'
        data={'status': 'on',
              'is_change': '',
              'submit':'',
              'id':'',
              'host': cms_host,
              'title': title,
              'author': author,
              'keyword': keyword,
              'time_span': '1',
              'videourl': '',
              'v_localHide':'',
              'video_link':'',
              'audiourl': '',
              'a_localHide':'',
              'audio_link':'',
              'departmentID': '9',
              'categoryId': '9',
              'categoryName': '评剧',
              'categoryNameOld': '请选择分类',
              'categoryIdOld':'',
              'describe': '1',
              'img_url': '',
        }
        r = requests.post(url, headers=headers, data=data)
        print(r.status_code)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~添加成功!" in r.text:
                print("新增成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    def cms_search_storytelling(self, session_id, title):
        '''
        CMS搜索评书接口
        para: title
        '''
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Proxy-Connection': 'keep-alive',
            "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/news/list"
        data = {'title': title}
        r = requests.post(url, headers=headers, data=data)
        if r.status_code == 200:
            if 'data-id=' in r.text:
                print("搜索成功!!\n", r.text)
                r1 = re.search('data-id=', r.text).span()
                return r.text[r1[1] + 1:r1[1] + 5]
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    def cms_delete_storytelling(self, session_id, id):
        '''
        CMS删除评书接口
        para: id     --  删除前需要搜索数据获取其id，作为参数
        '''
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Proxy-Connection': 'keep-alive',
            "Cookie": "lang=zh-CN; smartompsessionid=%s"%session_id}
        url = constant.CMS_SERVER + "/news/del/id/" + str(id)  # 需要通过搜索接口获取id
        r = requests.get(url, headers=headers)
        if r.status_code == 200:
            if u"恭喜 ^ _ ^ ! ~删除成功！" in r.text:
                print("删除成功!!\n", r.text)
                return r.text
            elif "Please enter your account name" in r.text:
                print("用户未登录！！\n", r.text)
    # def login_cms(self):
    #     url = "http://10.155.0.135:32170/login"
    #     # session_ismartompsessionid=225189deae0cb3ba41aad7dffc6217fc"
    #     headers = {"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3"
    #                , "Cookie": "lang=zh-CN; smartompsessionid=172ae191e784c894d410646a184535cb"}
    #     data = {"username": "admin", "pwd": "123456", "captcha": "7718", "captcha_id": "g1eISOZJcuf7IoO", "imagefield": "登录"}
    #     r = requests.post(url, data=json.dumps(data), headers=headers)
    #     print(r.status_code)
    #     print(r.text)
    def cms_storytelling_add_audio(self, id):

        '''
        # CMS评书添加音频
        smartompsessionid已写死
        para: id
        '''
        # print(id)
        dir = os.path.abspath(os.path.join(os.getcwd()))
        # print(dir)
        file_path = dir + os.sep + 'testdata' + os.sep + 'Songs_About_You.mp3'
        print(file_path)
        files = {
                 # 'name': (None, 'audiourl'),
                 # 'filename': (None, 'Songs_About_You.mp3'),
                 'file': ('Songs_About_You.mp3', open(file_path, 'rb'), 'audio/mp3')}

        # files = {'audiourl':('Songs_About_You.mp3', open(file_path, 'rb'), 'audio/mp3')}
        # m = MultipartEncoder(files)
        headers = {"Cookie": "lang=zh-CN; smartompsessionid=172ae191e784c894d410646a184535cb"}  # , 'Content-Type': m.content_type
        url = constant.CMS_SERVER + "/news/edit/id/" + str(id)
        r = requests.post(url, files=files, headers=headers)
        print(r.status_code)
        print(r.text)
        # if r.status_code == 200:
        #     print("添加音频成功!", r.text)
        #     return r.text
        # else:
        #     print("添加音频失败！", r.text)
        #     return r.text
    def remove_file(self, filepath):
        my_file = filepath
        if os.path.exists(my_file):
            # 删除文件，可使用以下两种方法。
            os.remove(my_file)
            # os.unlink(my_file)
        else:
            pass
    def check_xls(self, filepath):
        data = xlrd.open_workbook(filepath)
        table = data.sheets()[0]
        # ncols = table.ncols
        # print(ncols)
        username_col = table.col_values(5, start_rowx=0, end_rowx=None)
        agentid_col = table.col_values(6, start_rowx=0, end_rowx=None)
        agentname_col = table.col_values(7, start_rowx=0, end_rowx=None)
        # print(username_col[0])
        # print(agentid_col[0])
        # print(agentname_col[0])
        return [username_col, agentid_col, agentname_col]

    # def hit_check_search_export(self):



    # def getalllist():
    #     """
    #         cms
    #     """
    #     SERVER_CMS = 'http://10.155.0.135:32170'
    #     headers = {'Accept': 'application/json, text/plain, */*', 'Proxy-Connection': 'keep-alive',
    #                'Cookie': 'smartompsessionid=3cfc53b3c29050923998abbc72b5469c; lang=zh-CN'}
    #     url = '/category/getalllist'
    #     print(' 请求信息头 :   ', headers, '   请求接口路径  ', url)
    #     data = {}
    #     response = session.post(SERVER_CMS + url, headers=headers, json=data, verify=False)
    #     if response.status_code == 200:
    #         print("获取cms列表成功   ", ' 成功!! ', response.text)
    #         return True
    #     else:
    #         print("获取cms列表失败  ", ' 失败!! ')
    #         return False







