# !/usr/bin/env python
# -*- coding: utf-8 -*-
from lib.utils.logger import logger
from lib.utils import constant
from lib.modules.Base import Base
import requests
import json


class AccountManagement(Base):
    def __init__(self, user, password):
        Base.__init__(self, user, password)
        self.get_sv_authinfo()

    def new_account(self, account):
        url = '/v2/ux/slaves/'
        # data = {"groupids": [],
        #         "user": {"mail": "", "password": "Pepper1113", "realname": "automation1", "telephone": "13488821231",
        #                  "username": "automation1@cloudminds.com"}}
        ret_create = requests.post(constant.SERVER+url, headers=self.headers, json=account, verify=False, timeout=15)
        print(ret_create.text, ret_create.status_code)
        assert ret_create.status_code == 201

    def get_user_list(self, keyword="", page=1, pagesize=10):
        url = "/v2/ux/slaves/"
        pattern = "$.data"
        para = {'params': {'keyword': keyword, 'page': "{}".format(page), 'pagesize': '{}'.format(pagesize)}}
        print(para)
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret[0]:
            print('current user list: ' + str(ret[0][0]))
            return ret[0][0]
        return []

    def get_user_by_name(self, username):
        """
        通过名称获取user信息
        :param username: 
        :return: None if no, else, return a dict below
          {
            "id": 236,
            "username": "yanan@cloudminds.com",
            "password": "33a38cd0eeaa443f5d771622c3bc8441",
            "role": "slave",
            "realname": "刘",
            "mail": "yanan@cloudminds.com",
            "active": 1
          }
        """
        user_list = self.get_user_list(keyword=username)
        if not user_list:
            print('No user {} in the list'.format(username))
            logger.error('No user {} in the list'.format(username))
            return None
        for user in user_list:
            if user['user']["username"] == username:
                return user

    def set_user_status(self, username, status):
        user = self.get_user_by_name(username)
        if not user:
            logger.error('No user get')
            return -1

        user_id = user['user']['id']
        url = ""
        if status == 0:
            url = '/v2/ux/slaves/{}/disable'.format(user_id)
        elif status == 1:
            url = '/v2/ux/slaves/{}/enable'.format(user_id)
        else:
            print('error:::: type should be in 1/0 ')

        ret = requests.post(constant.SERVER+url, headers=self.headers, timeout=15)
        print(ret.status_code)

    def edit_user(self, username, content={}):
        user = self.get_user_by_name(username)
        print('The user is be edited:', user)
        if not user:
            logger.error('No user get')
            return -1

        user_id = user['user']['id']
        url = "/v2/ux/slaves/{}".format(user_id)
        if 'mail' in content.keys():
            user['user']['mail'] = content['mail']
        if 'password' in content.keys():
            user['user']['password'] = content['password']
        if 'realname' in content.keys():
            user['user']['realname'] = content['realname']
        if 'telephone' in content.keys():
            user['user']['telephone'] = content['telephone']
        if 'groupids' in content.keys():
            user['user']['groupids'] = content['groupids']
        user['user']['password'] = '' # 密码留空
        user['user']['username'] = ''  # 用户名留空
        print(user)
        # account = {"groupids": [],
        #            "user": {"mail": "automation@cloudminds.com", "password": "Pepper1113", "realname": "automation",
        #                     "telephone": "13488821231", "username": "automation@cloudminds.com"}}
        ret = requests.patch(constant.SERVER+url, json=user, headers=self.headers, timeout=10)
        return ret.status_code

    def delete_user(self, username):
        user = self.get_user_by_name(username)
        if not user:
            logger.error('No user get')
            return -1

        user_id = user['user']['id']
        url = "/v2/ux/slaves/{}".format(user_id)
        ret = requests.delete(constant.SERVER+url, headers=self.headers, timeout=10)
        return ret.status_code

    def get_group_by_name(self, group_name):
        """
        Get group information(dict) by group name
        :param group_name: 
        :return: group or None
        {
          "group": {
            "id": 77,
            "name": "tian",
            "info": "tian",
            "pid": 107
          },
          "agentid": 0,
          "agent": {
            "id": 339,
            "name": "pepper"
          },
          "authority": {
            "customdomain": true,
            "domainmanage": true,
            "qatype": true,
            "qamark": true,
            "faq": false,
            "faqmanage": true,
            "chitchat": false,
            "train": false
          }
        },
        """
        groups = self.get_group_list(pagesize='100000')
        if not groups:
            print('Cant get any groups')
            return
        for group in groups:
            if group['group']['name'] == group_name:
                print('current group', group)
                return group

    def get_group_list(self, keyword='', page='1', pagesize='10'):
        """
        get group list by keyword
        :param keyword:  default is empty, == all
        :param page: default 1
        :param pagesize: default is 10
        :return: 
        """
        url = "/v2/ux/groups/"
        para = {'params': {'keyword': keyword, 'page': page, 'pagesize': pagesize}}
        ret, _ = self.sv_request(url, 'GET', parameter=para, pattern='$.data')
        if ret:
            return ret[0]
        return []

    def get_agent(self, agent_name):
        url = '/v2/ux/agents/'
        para = {"params": {'keyword': '', 'page': '1', 'pagesize': '10000000000'}}
        ret, _ = self.sv_request(url, 'GET', parameter=para, pattern="$.data[?(@.agentname=='{}')]".format(agent_name))
        if ret:
            print('The agent is', ret[0][0])
            return ret[0][0]
        return []

    def new_group(self, group, agent, authority):
        """
        Create New Group with group dict, agent dict, authority dict
        :param group: 
        :param agent: 
        :param authority: 
        :return: 
        """
        url = '/v2/ux/groups/'
        agent_id = self.get_agentId_by_name(agent)
        if agent_id == -1:
            print("can't get agent id with name: " + agent)
            return False
        if not isinstance(group, dict):
            print("group should be in dict type, with 'info', 'name' keys ")
            return False
        if not isinstance(authority, dict):
            print("authority not in dict with 'chitchat/customdomain/domainmanage/faq/faqmanage/qamark/qatype/train'")
            return False
        data = {'agentid': agent_id, "group": group, 'authority': authority}
        ret = requests.post(constant.SERVER+url, json=data, headers=self.headers, verify=False, timeout=10)
        print('delete '+url, ret.status_code, ret.content)
        return ret.status_code

    def edit_group(self, group_name, group_info="", agent_id="", authority={}):
        group = self.get_group_by_name(group_name)
        if group:
            group_id = group["group"]["id"]
            url = "{}/v2/ux/groups/{}".format(constant.SERVER, group_id)

            if group_info:
                group["group"]["info"] = group_info
            if agent_id:
                group['agentid'] = agent_id
            if authority:
                if 'train' in authority.keys():
                    group['authority']['train'] = authority['train']
                if 'qatype' in authority.keys():
                    group['authority']['qatype'] = authority['qatype']
                if 'qamark' in authority.keys():
                    group['authority']['qamark'] = authority['qamark']
                if 'faqmanage' in authority.keys():
                    group['authority']['faqmanage'] = authority['faqmanage']
                if 'domainmanage' in authority.keys():
                    group['authority']['domainmanage'] = authority['domainmanage']
                if 'customdomain' in authority.keys():
                    group['authority']['customdomain'] = authority['customdomain']

            r = requests.patch(url, headers=self.headers, json=group, timeout=10)
            print('update {}, status code:{}, text:{}'.format(url, r.status_code, r.text))
            return r.status_code   # correct is 204
        print('Cant get group', group_name)
        return -1

    def delete_group(self, group_name):
        group = self.get_group_by_name(group_name)
        if group:
            group_id = group["group"]["id"]
            url = "{}/v2/ux/groups/{}".format(constant.SERVER, group_id)
            print(url)
            r = requests.delete(url, timeout=10, headers=self.headers, verify=False)
            return r.status_code  #should be 204
        print('Cannot get the group', group_name)
        return -1

