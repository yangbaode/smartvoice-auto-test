# -*- coding: utf-8 -*-
from lib.utils.logger import logger
from lib.utils import constant
from lib.modules.Base import Base

import requests
import json
from requests_toolbelt import MultipartEncoder
import os
import jsonpath
import random
import urllib.parse

class CustomService(Base):
    # strings questions=''
    def __init__(self, user, password, agent_id=None):
        Base.__init__(self, user, password)
        #self.authinfo = self.get_sv_authinfo(agent_id=549)
        #auth_info = self.get_sv_authinfo(agent_id=549)
        auth_info = self.get_sv_authinfo(agent_id=constant.agent_id1)
        self.agent_id = json.loads(auth_info)['agentid']

    #新建服务
    def create_domain(self, domain_name, domain_info="",release=""):
        """
        通过domain_name，domain_info，release创建服务：适用于非admin账号创建
        :param domain_name（必填），domain_info（非必填），release（非必填）
        :return:
        Status Code: 201 Created
        return  ture
        """
        if release=="":
            release = 1
        url = "/v2/ux/agents/{}/domains/".format(self.agent_id)
        data = {"domainname":domain_name,"domaininfo":domain_info,"status":"","type":"","url":"","release":release}
        r = requests.post(constant.SERVER + url, headers=self.headers, json=data, verify=False)
        if r.status_code != 201:
            return r.text
        return r.status_code == 201

    #获取服务的id号
    def get_domain_id_by_domain_name(self, domain_name):
        """
        通过domain_name，获取该服务的id
        :param domain_name（必填）
        :return:
        531
        """
        # print("domainname====",domain_name)
        # url = "/v2/ux/agents/{}/domains/".format(self.agent_id)
        # para = {"params": {'page': 1, 'pagesize': 10}}
        # pattern = "$..data[?(@.domainname== '{}')].id".format(domain_name)
        # ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        # print("ret--:",ret)
        # if ret:
        #     return ret[0][0]
        # return -1

        url = "/v2/ux/agents/{}/domains/?page=1&pagesize=10&keyword=".format(self.agent_id)
        ret = requests.get(constant.SERVER + url, headers=self.headers, verify=False)
        json_data = json.loads(ret.text)
        domainid = jsonpath.jsonpath(json_data, expr='$.data[0].id')
        return domainid[0]
    #获取服务的发布状态（release）
    def get_domain_release_by_domain_name(self, domain_name):
        """
        通过domain_name，获取该服务的发布状态
        :param domain_name（必填）
        :return:
        1 or 0
        """
        url = "/v2/ux/agents/{}/domains/".format(self.agent_id)
        para = {"params": {'page': 1, 'pagesize': 10}}
        pattern = "$..data[?(@.domainname== '{}')].release".format(domain_name)
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret:
            return ret[0][0]
        return -1
    #获取服务的domain_name
    def get_domain_name_by_domain_id(self, domain_id):
        """
        通过domain_id，获取该服务的domain_name
        :param domain_id（必填）
        :return:
         """
        url = "/v2/ux/agents/{}/domains/".format(self.agent_id)
        para = {"params": {'page': 1, 'pagesize': 10}}
        pattern = "$..data[?(@.id=={})].domainname".format(domain_id)
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret:
            return ret[0][0]
        return -1
    #获取服务的domain_info
    def get_domain_info_by_domain_id(self, domain_id):
        """
        通过domain_id，获取该服务的domain_info
        :param domain_id（必填）
        :return:
         """
        url = "/v2/ux/agents/{}/domains/".format(self.agent_id)
        para = {"params": {'page': 1, 'pagesize': 10}}
        pattern = "$..data[?(@.id=={})].domaininfo".format(domain_id)
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret:
            return ret[0][0]
        return -1

    #编辑服务
    def edit_domain(self,domain_name, domain_name_edit="",domain_info_edit="",release_edit=""):
        #domain_name为将要编辑的服务名称，后面三个参数分别为编辑修改的服务名称，服务描述，服务发布状态
        id = self.get_domain_id_by_domain_name(domain_name)
        if domain_name_edit=="":
            domainname=domain_name
        else:
            domainname=domain_name_edit
        domain_info = self.get_domain_info_by_domain_id(id)
        if domain_info_edit=="":
            domaininfo=domain_info
        else:
            domaininfo=domain_info_edit
        release_info = self.get_domain_release_by_domain_name(domain_name)
        if release_edit=="":
            release=release_info
        else:
            release=release_edit
        url = "/v2/ux/agents/{}/domains/".format(self.agent_id)
        data = {"domainname":domainname,"domaininfo":domaininfo,"type":"","status":"","url":"","release":release,"id":id}
        r = requests.patch(constant.SERVER + url, headers=self.headers, json=data, verify=False)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204

    #删除服务-domain_id
    def delete_domain_by_domain_id(self, domain_id):
        """
            通过domain_id，删除服务
            :param domain_id（必填）
            :return:
             """
        url = "/v2/ux/agents/{}/domains/{}".format(self.agent_id,domain_id)
        r = requests.delete(constant.SERVER + url, headers=self.headers, verify=False)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204
    #删除服务-domain_name
    def delete_domain_by_domain_name(self,domain_name):
        """
            通过domain_name，删除服务
            :param domain_name（必填）
            :return:
             """
        domain_id = self.get_domain_id_by_domain_name(domain_name)
        url = "/v2/ux/agents/{}/domains/{}".format(self.agent_id,domain_id)
        r = requests.delete(constant.SERVER + url, headers=self.headers, verify=False)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204
    #服务导入_filetemplate模板下载
    def download_domain_filetemplate(self):
        url = "/v2/ux/agents/{}/domains/filetemplate".format(self.agent_id)
        para = {"params": ""}
        pattern = "$.[*].domainname"
        #pattern = "$.[*]"
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret:
            return ret[0][0]#返回默认的domain_name，用于之后删除使用
        return False

    # 服务导入
    def import_domain_filetemplate(self):
        url = "/v2/ux/agents/{}/domains/import".format(self.agent_id)
        headers = {'Connection': 'keep-alive',
                   'Content-Type': 'multipart/form-data;boundary=----WebKitFormBoundarytZ7uZVAa2Jgt9Z6u',
                   'Accept': 'application/json,text/plain, */*','authinfo':self.authinfo}
        filepath=os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'testdata/import-service-template.json')
        fileexit=os.path.exists(filepath)
        if fileexit:
            fin = open(filepath, 'rb')
            files = {"atta":("import-service-template.json",fin)}
            m = MultipartEncoder(files)
            headers['Content-Type'] = m.content_type
            try:
                r = requests.post(constant.SERVER+url,headers=headers,data=m)
            finally:
                fin.close()
            if r.status_code != 204:
                return r.text
            return r.status_code == 204
        else:
            return "file is not exit!"
    #服务导出
    #前提条件：本测试是以导入模板为基础，在进行导出测试的，并判断导出的意图中文是否乱码，测试之前须先导入模板，测试后再将此服务删除
    # def export_domain(self):
    #     url = "/v2/ux/agents/{}/domains/export".format(self.agent_id)
    #     para = {"params": ""}
    #     pattern = "$.[*]"
    #     ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
    #     json_data = ret[0]
    #     if json_data:
    #         domains = len(jsonpath.jsonpath(json_data, expr='$.[*].domainname'))
    #         if jsonpath.jsonpath(json_data, expr='$.[*].intentname'):
    #             intentnames = len(jsonpath.jsonpath(json_data, expr='$.[*].intentname'))
    #             Chinese_garbled_verification = jsonpath.jsonpath(json_data,expr='$.[?(@.domainname=="musicNew")].intentlist[0].prompt')
    #             print(Chinese_garbled_verification)
    #             if Chinese_garbled_verification[0]=="马上播放精彩音乐啦":
    #                 return domains,intentnames#返回导出的服务数及意图数
    #             else:
    #                 return "Chinese garbled in the intention!"
    #         else:
    #             return domains#只存在服务，无意图
    #     else:
    #         return "no domain!"#无服务意图

    #自定义服务-导出，若存在则返回服务总数，意图总数
    def export_domain(self):
        url = "/v2/ux/agents/{}/domains/export".format(self.agent_id)
        para = {"params": ""}
        pattern = "$.[*]"
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        json_data = ret[0]
        if json_data:
            domains = len(jsonpath.jsonpath(json_data, expr='$..[*].domainname'))
            if jsonpath.jsonpath(json_data, expr='$.[*].intentlist.[*].intentname'):
                intentnames = len(jsonpath.jsonpath(json_data, expr='$.[*].intentlist.[*].intentname'))
                return domains,intentnames#返回导出的服务数及意图数
            else:
                return domains,0#只存在服务，无意图
        else:
            return "no domain!"#无服务及意图

    #自定义服务-意图-新建
    def create_domain_intents(self, domain_id):
        url = "/v2/ux/agents/{}/domains/{}/intents/".format(self.agent_id,domain_id)
        intentname = "intentnameautotest"+str(random.randint(10000,99999))+str(random.randint(10000,99999))
        datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"inputcontext","outputcontext":"outputcontext","examplelist":[{"type":"quote","text":"how do you do?","labellist":[{"text":"how do you do?"}],"textIsEmpty":False}],"paramlist":[],"prompt":"prompt"}
        jsons = json.dumps(datas)
        r = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        if r.status_code != 201:
            #return r.text
            return False
        #return r.status_code == 201
        return intentname

    #自定义服务-意图-新建-复杂预料
    def create_domain_IntentsComplex(self, domain_id,intentname):
        print("==============",intentname)
        url = "/v2/ux/agents/{}/domains/{}/intents/".format(self.agent_id,domain_id)
        sysentityid = self.intents_get_entity_id_by_entity_name("sys.compute")
        datas = {"id": 0, "agentid": self.agent_id, "domainid": domain_id, "intentname": intentname, "inputcontext": "",
         "outputcontext": "OrderTicket", "examplelist": [{"type": "complex", "text": "我要订一张[哪吒{}|杀手之王]的电影票".format(intentname),
                                                          "labellist": [
                                                              {"text": "我要订一张[哪吒{}|杀手之王]的电影票".format(intentname), "entityid": None}],
                                                          "textIsEmpty": False}], "frontlist": [], "afterlist": [],
         "paramlist": [], "prompt": "致命罗密欧的电影票不够了"}
        jsons = json.dumps(datas)
        print("create----:",jsons)
        r = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        # r = requests.post(constant.SERVER + url, headers=self.headers, data=datas, verify=False)
        print("result create:",r.text,r.status_code)
        if r.status_code != 201:
            #return r.text
            return False
        #return r.status_code == 201
        return True
    #意图编辑，保存，编辑时不改变任何内容，只是用于提交一次，
    def domain_IntentsComplex_put(self,domain_id,intentname):
        intent_id = self.get_intents_id_by_domain_name(domain_id,intentname)
        #corpusid为原意图中语料的id
        corpusid = self.get_intentsOFCorpus_id(domain_id,intent_id)
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intent_id)
        datas = {"id":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"intentname":intentname,"inputcontext":"","outputcontext":"OrderTicket","prompt":"致命罗密欧的电影票不够了","action":"","paramlist":[],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":corpusid,"intentid":intent_id,"text":"我要订一张[哪吒{}|杀手之王]的电影票".format(intentname),"type":"complex","agentid":self.agent_id,"domainid":domain_id,"labellist":[{"text":"我要订一张[哪吒{}|杀手之王]的电影票".format(intentname)}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[]}
        jsons = json.dumps(datas)
        print('put  json---:',jsons)
        r = requests.put(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        print('return:', r)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204

    def domain_SV_QUESTION(self,question,intentsname):
        # questinos = urllib.parse.quote(question)
        url = '/v2/ux/agents/{}/smartqa/query?question=%E6%88%91%E8%A6%81%E8%AE%A2%E4%B8%80%E5%BC%A0%E5%93%AA%E5%90%92{}%E7%9A%84%E7%94%B5%E5%BD%B1%E7%A5%A8&hariVersion=v3'.format(constant.agent_id1,intentsname)
        # url = '/v2/ux/agents/{}/smartqa/query?question={}&hariVersion=v3'.format(constant.agent_id1,urllib.parse.quote(question))
        # url = '/v2/ux/agents/{}/smartqa/query?question={}&hariVersion=v3'.format(constant.agent_id1,question)
        # URL = urllib.parse.quote(constant.SERVER+'/v2/ux/agents/{}/smartqa/query?question={}&hariVersion=v3'.format(constant.agent_id1,question))
        # datas = {'question': question, 'hariVersion': 'v3'}

        # url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intent_id)
        # datas = {"id":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"intentname":intentname,"inputcontext":"","outputcontext":"OrderTicket","prompt":"致命罗密欧的电影票不够了","action":"","paramlist":[],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":corpusid,"intentid":intent_id,"text":"我要订一张[哪吒{}|杀手之王]的电影票".format(intentname),"type":"complex","agentid":self.agent_id,"domainid":domain_id,"labellist":[{"text":"我要订一张[哪吒{}|杀手之王]的电影票".format(intentname)}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[]}
        # jsons = json.dumps(datas)
        # print('put  json---:',jsons)
        print("request json---:",constant.SERVER + url,self.headers)
        # r = requests.get(constant.SERVER + url, headers=self.headers, params=datas, verify=False)
        r = requests.get(constant.SERVER + url, headers=self.headers, verify=False)
        # r = requests.get(URL, headers=self.headers, verify=False)
        print('return:', r,r.json())
        if r.status_code != 200:
            return r.text
        return r.json()




    def send_qa(self, question):
        '''
        返回 question， answer 与及 source_value
        '''
        try:
            url = '/v2/ux/agents/{}/smartqa/query?question={}&hariVersion=v3'.format(constant.agent_id1, question)
            print('url: ', url)
            if url:
                response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
                print('response text: ', response.text)
                dict_response = response.json()
                a = dict_response['answer']
                print('a: ', a, '\n', type(a))
                b = json.loads(a)
                question_text = b['asr']['text']
                print('question_text:', question_text)
                answer_text = b['tts'][0]['text']
                source_value = b['source']
                print('source_value:', source_value)
                print('answer_text:', answer_text)
                print('answer numbers:', len(b['tts']))
                # return question_text, answer_text, source_value
                return dict_response
        except Exception as e:
            print(e)

    #自定义服务-意图-新建-
    def create_domain_IntentsComplex_EDIT(self, domain_id,intentname):
        print("==============",intentname)
        url = "/v2/ux/agents/{}/domains/{}/intents/".format(self.agent_id,domain_id)
        sysentityid = self.intents_get_entity_id_by_entity_name("sys.compute")
        #intentname = "intentnameautotest"+str(random.randint(10000,99999))+str(random.randint(10000,99999))
        #datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"inputcontext","outputcontext":"outputcontext","examplelist":[{"type":"quote","text":"how do you do?","labellist":[{"text":"how do you do?"}],"textIsEmpty":False}],"paramlist":[],"prompt":"prompt"}
        datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"[算算]@sys.compute:compute[结果|是|得|等于|][多少|什么|几|]","labellist":[{"text":"[算算]"},{"paramname":"compute","entityname":"sys.compute","entityid":sysentityid,"text":"@sys.compute:compute"},{"text":"[结果|是|得|等于|][多少|什么|几|]"}],"textIsEmpty":False}],"paramlist":[{"paramname":"compute","entityname":"sys.compute","entityid":str(sysentityid),"required":False,"extendable":False,"prompt":"","isexistincorpus":True}],"prompt":""}
        # datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"","labellist":[{"text":"[保亮][算下]","entityid":None},{"paramname":"compute","entityname":"sys.compute","entityid":sysentityid,"text":"@sys.compute:compute"},{"text":"[结果|是|得|等于|][多少|什么|几|]","entityid":None}],"textIsEmpty":False}],"frontlist":[],"afterlist":[],"paramlist":[{"paramname":"compute","entityname":"sys.compute","entityid":sysentityid,"required":False,"extendable":False,"prompt":"","isexistincorpus":True}],"prompt":"今天我太累了，明天再说吧，再见！"}
        # datas = {"id": 0, "agentid": self.agent_id, "domainid": int(domain_id), "intentname": intentname,"inputcontext": "", "outputcontext": "", "examplelist": [{"type": "complex", "text": "", "labellist": [{"text": intentname+"[小白兔|小地鼠][尾巴|耳朵]很不错", "entityid": None}],"textIsEmpty": False}], "frontlist": [], "afterlist": [], "paramlist": [],"prompt": "嗯嗯嗯，是挺不错，挺舒服的，不冷不热！"}
        jsons = json.dumps(datas)
        r = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        if r.status_code != 201:
            #return r.text
            return False
        #return r.status_code == 201
        return True
    #自定义服务-意图-新建-复杂预料-上下文1
    def create_domain_IntentsComplex_Context1(self, domain_id,intentname):
        url = "/v2/ux/agents/{}/domains/{}/intents/".format(self.agent_id,domain_id)
        # datas = {"id":0,"agentid":self.agent_id,"domainid":self.agent_id,"intentname":intentname,"inputcontext":"","outputcontext":"意图1输出语境","examplelist":[{"type":"quote","text":"意图1语料","labellist":[{"text":"意图1语料"}],"textIsEmpty":False}],"paramlist":[],"prompt":"意图1回复"}
        datas = {"id":0,"agentid":self.agent_id,"domainid":domain_id,"intentname":intentname,"inputcontext":"","outputcontext":"OrderTicket","examplelist":[{"type":"complex","text":"我要订一张[哪吒{}|泰坦尼克号]的电影票".format(intentname),"labellist":[{"text":"我要订一张[哪吒{}|泰坦尼克号]的电影票".format(intentname),"entityid":None}],"textIsEmpty":False}],"frontlist":[],"afterlist":[],"paramlist":[],"prompt":"卧虎藏龙的电影票不够了"}
        jsons = json.dumps(datas)
        print("intents1111111:",jsons)
        r = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        if r.status_code != 201:
            return False
        return True

    #自定义服务-意图-新建-复杂预料-上下文2
    def create_domain_IntentsComplex_Context2(self, domain_id,intentname):
        url = "/v2/ux/agents/{}/domains/{}/intents/".format(self.agent_id,domain_id)
        # datas = {"id":0,"agentid":self.agent_id,"domainid":domain_id,"intentname":intentname,"inputcontext":"意图1输出语境","outputcontext":"","examplelist":[{"type":"quote","text":"意图2语料","labellist":[{"text":"意图2语料"}],"textIsEmpty":False}],"paramlist":[],"prompt":"意图2回复"}
        datas = {"id":0,"agentid":self.agent_id,"domainid":domain_id,"intentname":intentname,"inputcontext":"OrderTicket","outputcontext":"","examplelist":[{"type":"complex","text":"泰坦尼克号呢","labellist":[{"text":"泰坦尼克号呢","entityid":None}],"textIsEmpty":False}],"frontlist":[],"afterlist":[],"paramlist":[],"prompt":"泰坦尼克号的电影票很充足"}
        jsons = json.dumps(datas)
        print("intents222222222:", jsons)
        r = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        if r.status_code != 201:
            return False
        return True

    # 意图编辑，保存，编辑时不改变任何内容，只是用于提交一次，
    def domain_IntentsComplex_put_Context1(self, domain_id, intentname):
        intent_id = self.get_intents_id_by_domain_name(domain_id, intentname)
        # corpusid为原意图中语料的id
        corpusid = self.get_intentsOFCorpus_id(domain_id, intent_id)
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intent_id)
        datas = {"id":int(intent_id),"domainid":domain_id,"agentid":self.agent_id,"intentname":intentname,"inputcontext":"","outputcontext":"OrderTicket","prompt":"卧虎藏龙的电影票不够了","action":"","paramlist":[],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":int(corpusid),"intentid":int(intent_id),"text":"我要订一张[哪吒{}|泰坦尼克号]的电影票".format(intentname),"type":"complex","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"text":"我要订一张[卧虎藏龙{}|泰坦尼克号]的电影票".format(intentname)}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[]}
        jsons = json.dumps(datas)
        print('json1111111111:',jsons)
        r = requests.put(constant.SERVER + url, headers=self.headers, json=datas, verify=False)
        print('return:', r)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204

    # 意图编辑，保存，编辑时不改变任何内容，只是用于提交一次，
    def domain_IntentsComplex_put_Context2(self, domain_id, intentname):
        intent_id = self.get_intents_id_by_domain_name(domain_id, intentname)
        # corpusid为原意图中语料的id
        corpusid = self.get_intentsOFCorpus_id(domain_id, intent_id)
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intent_id)
        datas = {"id":int(intent_id),"domainid":domain_id,"agentid":self.agent_id,"intentname":intentname,"inputcontext":"OrderTicket","outputcontext":"","prompt":"泰坦尼克号的电影票很充足","action":"","paramlist":[],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[],"changedexamplelist":[{"id":int(corpusid),"intentid":int(intent_id),"text":"泰坦尼克号呢","type":"complex","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"text":"泰坦尼克号呢"}],"textIsEmpty":False}],"addexamplelist":[]}
        jsons = json.dumps(datas)
        print('json22222222222222:',jsons)
        r = requests.put(constant.SERVER + url, headers=self.headers, json=datas, verify=False)
        print('return:', r)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204


    #自定义服务-意图-新建-
    def create_domain_IntentsComplex_UseOfBrackets(self, domain_id,intentname):
        url = "/v2/ux/agents/{}/domains/{}/intents/".format(self.agent_id,domain_id)
        #intentname = "intentnameautotest"+str(random.randint(10000,99999))+str(random.randint(10000,99999))
        #datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"inputcontext","outputcontext":"outputcontext","examplelist":[{"type":"quote","text":"how do you do?","labellist":[{"text":"how do you do?"}],"textIsEmpty":False}],"paramlist":[],"prompt":"prompt"}
        #datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"[算算]@sys.compute:compute[结果|是|得|等于|][多少|什么|几|]","labellist":[{"text":"[算算]"},{"paramname":"compute","entityname":"sys.compute","entityid":263,"text":"@sys.compute:compute"},{"text":"[结果|是|得|等于|][多少|什么|几|]"}],"textIsEmpty":False}],"paramlist":[{"paramname":"compute","entityname":"sys.compute","entityid":"263","required":False,"extendable":False,"prompt":"","isexistincorpus":True}],"prompt":""}
        #datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"[今天][天气]很不错","labellist":[{"text":"[今天][天气]很不错"}],"textIsEmpty":False}],"paramlist":[],"prompt":""}
        # datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"[今天][天气]很不错","labellist":[{"text":"[今天][天气]很不错"}],"textIsEmpty":False}],"paramlist":[],"prompt":"UseOfBrackets"}
        # datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"","labellist":[{"text":"[小班1][中班1]总上课","entityid":None}],"textIsEmpty":False}],"frontlist":[],"afterlist":[],"paramlist":[],"prompt":"UseOfBrackets"}
        datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"OrderTicket","examplelist":[{"type":"complex","text":"她{}要订一张[卧虎藏龙|泰坦尼克号]的电影票".format(intentname),"labellist":[{"text":"她{}要订一张[卧虎藏龙|泰坦尼克号]的电影票".format(intentname),"entityid":None}],"textIsEmpty":False}],"frontlist":[],"afterlist":[],"paramlist":[],"prompt":"卧虎藏龙的电影票不够了"}
        jsons = json.dumps(datas)
        print("创建意图为：",jsons)
        r = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        if r.status_code != 201:
            #return r.text
            return False
        #return r.status_code == 201
        return True

    def edit_domain_IntentsComplex_UseOfBrackets(self, domain_id,intentname):
        intent_id = self.get_intents_id_by_domain_name(domain_id, intentname)
        # corpusid为原意图中语料的id
        corpusid = self.get_intentsOFCorpus_id(domain_id, intent_id)
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intent_id)
        # datas = {"id": int(intent_id), "domainid": int(domain_id), "agentid": self.agent_id, "intentname": intentname,
        #          "inputcontext": "", "outputcontext": "", "prompt": "UseOfVerticalLines", "action": "", "paramlist": [],
        #          "frontlist": [], "afterlist": [], "deleteexampleidlist": [], "unchangedexamplelist": [
        #         {"id": int(corpusid), "intentid": int(intent_id), "text": "[今天|明天|][大纲{}]很不错".format(intentname),
        #          "type": "complex", "agentid": self.agent_id, "domainid": int(domain_id),
        #          "labellist": [{"text": "[今天|明天|][大纲{}]很不错".format(intentname)}], "textIsEmpty": False}],
        #          "changedexamplelist": [], "addexamplelist": []}
        # datas = {"id": int(intent_id), "domainid": int(domain_id), "agentid": self.agent_id, "intentname": intentname, "inputcontext": "",
        #  "outputcontext": "OrderTicket", "prompt": "卧虎藏龙的电影票不够了", "action": "", "paramlist": [], "frontlist": [],
        #  "afterlist": [], "deleteexampleidlist": [], "unchangedexamplelist": [], "changedexamplelist": [
        #     {"id": int(corpusid), "intentid": int(intent_id), "text": "我{}要订一张[卧虎藏龙|泰坦尼克号]的电影票".format(intentname), "type": "complex",
        #      "agentid": self.agent_id, "domainid": int(domain_id), "labellist": [{"text": "我{}要订一张[卧虎藏龙|泰坦尼克号]的电影票".format(intentname)}],
        #      "textIsEmpty": False}], "addexamplelist": []}
        datas = {"id": int(intent_id), "domainid": int(domain_id), "agentid": self.agent_id, "intentname": intentname, "inputcontext": "",
         "outputcontext": "OrderTicket", "prompt": "卧虎藏龙的电影票不够了", "action": "", "paramlist": [], "frontlist": [],
         "afterlist": [], "deleteexampleidlist": [], "unchangedexamplelist": [
            {"id": int(corpusid), "intentid": int(intent_id), "text": "她{}要订一张[卧虎藏龙|泰坦尼克号]的电影票".format(intentname), "type": "complex",
             "agentid": self.agent_id, "domainid": int(domain_id), "labellist": [{"text": "她{}要订一张[卧虎藏龙|泰坦尼克号]的电影票".format(intentname)}],
             "textIsEmpty": False}], "changedexamplelist": [], "addexamplelist": []}
        jsons = json.dumps(datas)
        print('edit put ----json:',jsons)
        r = requests.put(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        print('return:', r)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204


    #自定义服务-意图-新建-
    def create_domain_IntentsComplex_UseOfVerticalLines(self, domain_id,intentname):
        url = "/v2/ux/agents/{}/domains/{}/intents/".format(self.agent_id,domain_id)
        #intentname = "intentnameautotest"+str(random.randint(10000,99999))+str(random.randint(10000,99999))
        #datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"inputcontext","outputcontext":"outputcontext","examplelist":[{"type":"quote","text":"how do you do?","labellist":[{"text":"how do you do?"}],"textIsEmpty":False}],"paramlist":[],"prompt":"prompt"}
        #datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"[算算]@sys.compute:compute[结果|是|得|等于|][多少|什么|几|]","labellist":[{"text":"[算算]"},{"paramname":"compute","entityname":"sys.compute","entityid":263,"text":"@sys.compute:compute"},{"text":"[结果|是|得|等于|][多少|什么|几|]"}],"textIsEmpty":False}],"paramlist":[{"paramname":"compute","entityname":"sys.compute","entityid":"263","required":False,"extendable":False,"prompt":"","isexistincorpus":True}],"prompt":""}
        #datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"[今天][天气]很不错","labellist":[{"text":"[今天][天气]很不错"}],"textIsEmpty":False}],"paramlist":[],"prompt":""}
        datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"[今天|明天|][大纲{}]很不错".format(intentname),"labellist":[{"text":"[今天|明天|][大纲{}]很不错".format(intentname)}],"textIsEmpty":False}],"paramlist":[],"prompt":"UseOfVerticalLines"}
        jsons = json.dumps(datas)
        print("创建的意图为：",jsons)
        r = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        if r.status_code != 201:
            #return r.text
            return False
        #return r.status_code == 201
        return True

    # 意图编辑，保存，编辑时不改变任何内容，只是用于提交一次，
    def domain_IntentsComplex_put_UseOfVerticalLines(self, domain_id, intentname):
        intent_id = self.get_intents_id_by_domain_name(domain_id, intentname)
        # corpusid为原意图中语料的id
        corpusid = self.get_intentsOFCorpus_id(domain_id, intent_id)
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intent_id)
        # datas = {"id":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"intentname":"intentstestone92495","inputcontext":"OrderTicket","outputcontext":"","prompt":"泰坦尼克号的电影票很充足","action":"","paramlist":[],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[],"changedexamplelist":[{"id":int(corpusid),"intentid":int(intent_id),"text":"泰坦尼克号呢","type":"complex","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"text":"泰坦尼克号呢"}],"textIsEmpty":False}],"addexamplelist":[]}
        datas = {"id":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"intentname":intentname,"inputcontext":"","outputcontext":"","prompt":"UseOfVerticalLines","action":"","paramlist":[],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":int(corpusid),"intentid":int(intent_id),"text":"[今天|明天|][大纲{}]很不错".format(intentname),"type":"complex","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"text":"[今天|明天|][大纲{}]很不错".format(intentname)}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[]}
        # jsons = json.dumps(datas)
        # print('json:',jsons)
        r = requests.put(constant.SERVER + url, headers=self.headers, json=datas, verify=False)
        print('return:', r)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204

    #自定义服务-意图-新建
    def create_domain_IntentsComplex_CallSystemVariableName(self, domain_id,intentname):
        url = "/v2/ux/agents/{}/domains/{}/intents/".format(self.agent_id,domain_id)
        sysentityid = self.intents_get_entity_id_by_entity_name("sys.entity.city")
        # datas = {"id": 0, "agentid": self.agent_id, "domainid": int(domain_id), "intentname": intentname,"inputcontext": "", "outputcontext": "", "examplelist": [{"type": "complex", "text": "", "labellist": [{"text": "[小邓][准备|计划]", "entityid": None},{"paramname": "ctname", "entityname": "sys.entity.city", "entityid": sysentityid, "text": "@sys.entity.city:ctname"},{"text": "[出国旅游呢]", "entityid": None}], "textIsEmpty": False}], "frontlist": [], "afterlist": [],"paramlist": [{"paramname": "ctname", "entityname": "sys.entity.city", "entityid": int(sysentityid), "required": True,"extendable": False, "prompt": "请问什么时候呀", "isexistincorpus": True}], "prompt": "嗯呐嗯呐，好好玩吧"}
        # datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"[小邓{}][准备|计划]@sys.entity.city:ctname[出国旅游呢]".format(intentname),"labellist":[{"text":"[小邓{}][准备|计划]".format(intentname),"entityid":None},{"paramname":"ctname","entityname":"sys.entity.city","entityid":int(sysentityid),"text":"@sys.entity.city:ctname"},{"text":"[出国旅游呢]","entityid":None}],"textIsEmpty":False}],"frontlist":[],"afterlist":[],"paramlist":[{"paramname":"ctname","entityname":"sys.entity.city","entityid":int(sysentityid),"required":True,"extendable":False,"prompt":"请问什么时候呀","isexistincorpus":True}],"prompt":"嗯呐嗯呐，好好玩吧"}
        datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"[小邓{}][准备|计划]@sys.entity.city:ctname[出国旅游呢]".format(intentname),"labellist":[{"text":"[小邓{}][准备|计划]".format(intentname),"entityid":None},{"paramname":"ctname","entityname":"sys.entity.city","entityid":int(sysentityid),"text":"@sys.entity.city:ctname"},{"text":"[出国旅游呢]","entityid":None}],"textIsEmpty":False}],"frontlist":[],"afterlist":[],"paramlist":[{"paramname":"ctname","entityname":"sys.entity.city","entityid":int(sysentityid),"required":True,"extendable":False,"prompt":"请问什么时候呀","isexistincorpus":True}],"prompt":"嗯呐嗯呐，好好玩吧!"}
        jsons = json.dumps(datas)
        print("创建的意图为：",jsons)
        r = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        if r.status_code != 201:
            #return r.text
            return False
        #return r.status_code == 201
        return True

    # 意图编辑，保存，编辑时不改变任何内容，只是用于提交一次，
    def domain_IntentsComplex_put_CallSystemVariableName(self, domain_id, intentname):
        intent_id = self.get_intents_id_by_domain_name(domain_id, intentname)
        # corpusid为原意图中语料的id
        corpusids = self.get_intentsOFids(domain_id, intent_id)
        print("----------",corpusids[0],corpusids[1],corpusids[2],corpusids[3])
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intent_id)
        # datas = {"id":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"intentname":intentname,"inputcontext":"","outputcontext":"","prompt":"嗯呐嗯呐，好好玩吧!","action":"","paramlist":[{"id":int(corpusids[2]),"intentid":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"entityname":"sys.entity.city","paramname":"ctname","required":True,"prompt":"请问什么时候呀","extendable":False,"isexistincorpus":True}],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":int(corpusids[0]),"intentid":int(intent_id),"text":"[小邓{}][准备|计划]@sys.entity.city:ctname[出国旅游呢]".format(intentname),"type":"complex","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"text":"[小邓{}][准备|计划]".format(intentname)},{"id":int(corpusids[1]),"intentid":int(intent_id),"exampleid":int(corpusids[0]),"entityid":int(corpusids[3]),"entityname":"sys.entity.city","text":"@sys.entity.city:ctname","paramname":"ctname"},{"text":"[出国旅游呢]"}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[]}
        datas = {"id":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"intentname":intentname,"inputcontext":"","outputcontext":"","prompt":"嗯呐嗯呐，好好玩吧!","action":"","paramlist":[{"id":int(corpusids[2]),"intentid":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"entityname":"sys.entity.city","paramname":"ctname","required":True,"prompt":"请问什么时候呀","extendable":False,"isexistincorpus":True}],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":int(corpusids[0]),"intentid":int(intent_id),"text":"[小邓{}][准备|计划]@sys.entity.city:ctname[出国旅游呢]".format(intentname),"type":"complex","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"text":"[小邓{}][准备|计划]".format(intentname)},{"id":int(corpusids[1]),"intentid":int(intent_id),"exampleid":int(corpusids[0]),"entityid":int(corpusids[3]),"entityname":"sys.entity.city","text":"@sys.entity.city:ctname","paramname":"ctname"},{"text":"[出国旅游呢]"}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[]}
        jsons = json.dumps(datas)
        # print("json put data:",jsons)
        print("put datas:",datas)
        r = requests.put(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        print('return:', r)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204

    #自定义服务-意图-获取意图中语料的id号
    def get_intentsOFids(self, domain_id,intents_id):
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intents_id)
        result = requests.get(constant.SERVER + url, headers=self.headers, verify=False)
        # json_data = json.loads(result.text)
        json_data = result.json()
        print("json-----------:",result.text)
        ret = jsonpath.jsonpath(json_data, expr='$.[examplelist].[id]')
        ret2 = jsonpath.jsonpath(json_data, expr='$.[paramlist].[id]')
        ret3 = jsonpath.jsonpath(json_data, expr='$.[examplelist].[labellist].[entityid]')
        print("--------:",ret[0],ret[2],ret2[0],ret3[0])
        return ret[0],ret[2],int(ret2[0]),ret3[0]#int(ret2[0])+2,即paramlist的id，每编辑一次，id自增一次，此意图取意图ID编辑一次，这次是第二次，所以加2


    #自定义服务-意图-新建-复杂预料
    def create_domain_IntentsComplex_CallSystemVariableName_NUMTWO(self, domain_id,intentname):
        url = "/v2/ux/agents/{}/domains/{}/intents/".format(self.agent_id,domain_id)
        sysentityid = self.intents_get_entity_id_by_entity_name("sys.compute")
        #intentname = "intentnameautotest"+str(random.randint(10000,99999))+str(random.randint(10000,99999))
        #datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"inputcontext","outputcontext":"outputcontext","examplelist":[{"type":"quote","text":"how do you do?","labellist":[{"text":"how do you do?"}],"textIsEmpty":False}],"paramlist":[],"prompt":"prompt"}
        #datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"[算算]@sys.compute:compute[结果|是|得|等于|][多少|什么|几|]","labellist":[{"text":"[算算]"},{"paramname":"compute","entityname":"sys.compute","entityid":263,"text":"@sys.compute:compute"},{"text":"[结果|是|得|等于|][多少|什么|几|]"}],"textIsEmpty":False}],"paramlist":[{"paramname":"compute","entityname":"sys.compute","entityid":"263","required":False,"extendable":False,"prompt":"","isexistincorpus":True}],"prompt":""}
        #datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"[今天][天气]很不错","labellist":[{"text":"[今天][天气]很不错"}],"textIsEmpty":False}],"paramlist":[],"prompt":""}
        #datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"[我在]@sys.city","labellist":[{"text":"[我在]"},{"text":"@sys.city"}],"textIsEmpty":False}],"paramlist":[],"prompt":"CallSystemVariableName"}
        datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"@sys.compute:compute[等于几]","labellist":[{"text":""},{"paramname":"compute","entityname":"sys.compute","entityid":sysentityid,"text":"@sys.compute:compute"},{"text":"[等于几]"}],"textIsEmpty":False}],"paramlist":[{"paramname":"compute","entityname":"sys.compute","entityid":str(sysentityid),"required":False,"extendable":False,"prompt":"","isexistincorpus":True}],"prompt":""}
        jsons = json.dumps(datas)
        print("创建的意图为：",jsons)
        r = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        if r.status_code != 201:
            #return r.text
            return False
        #return r.status_code == 201
        return True


    #自定义服务-意图-新建-复杂预料-自定义实体调用
    def create_domain_IntentsComplex_CustomEntityVariableName(self, domain_id,intentname,entityname,entityid):
        url = "/v2/ux/agents/{}/domains/{}/intents/".format(self.agent_id,domain_id)
        datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"@{}:shijianduan[好][{}]".format(entityname,intentname),"labellist":[{"paramname":"shijianduan","entityname":entityname,"entityid":entityid,"text":"@{}:shijianduan".format(entityname)},{"text":"[好][{}]".format(intentname)}],"textIsEmpty":False}],"paramlist":[{"paramname":"shijianduan","entityname":entityname,"entityid":str(entityid),"required":False,"extendable":False,"prompt":"","isexistincorpus":True}],"prompt":"CustomEntityVariableName"}
        jsons = json.dumps(datas)
        print("创建的意图为：",jsons)
        r = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        if r.status_code != 201:
            #return r.text
            return False
        #return r.status_code == 201
        return True

    # 意图编辑，保存，编辑时不改变任何内容，只是用于提交一次，
    def domain_IntentsComplex_put_CustomEntityVariableName(self, domain_id, intentname):
        intent_id = self.get_intents_id_by_domain_name(domain_id, intentname)
        # corpusid为原意图中语料的id
        corpusids = self.get_intentsOFids_CustomEntityVariableName(domain_id, intent_id)
        print("----------",corpusids[0],corpusids[1],corpusids[2],corpusids[3])
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intent_id)
        # datas = {"id":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"intentname":intentname,"inputcontext":"","outputcontext":"","prompt":"CustomEntityVariableName","action":"","paramlist":[{"id":int(corpusids[2]),"intentid":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"entityname":corpusids[4],"paramname":"shijianduan","required":False,"prompt":"","extendable":False,"isexistincorpus":True}],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":int(corpusids[0]),"intentid":int(intent_id),"text":"@{}:shijianduan[好]".format(corpusids[4]),"type":"complex","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"id":int(corpusids[1]),"intentid":int(intent_id),"exampleid":int(corpusids[0]),"entityid":int(corpusids[3]),"entityname":corpusids[4],"text":"@{}:shijianduan".format(corpusids[4]),"paramname":"shijianduan"},{"text":"[好]"}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[]}
        datas = {"id":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"intentname":intentname,"inputcontext":"","outputcontext":"","prompt":"CustomEntityVariableName","action":"","paramlist":[{"id":int(corpusids[2]),"intentid":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"entityname":corpusids[4],"paramname":"shijianduan","required":False,"prompt":"","extendable":False,"isexistincorpus":True}],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":int(corpusids[0]),"intentid":int(intent_id),"text":"@{}:shijianduan[好][{}]".format(corpusids[4],intentname),"type":"complex","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"id":int(corpusids[1]),"intentid":int(intent_id),"exampleid":int(corpusids[0]),"entityid":int(corpusids[3]),"entityname":corpusids[4],"text":"@{}:shijianduan".format(corpusids[4]),"paramname":"shijianduan"},{"text":"[好][{}]".format(intentname)}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[]}
        jsons = json.dumps(datas)
        print("json put data:",jsons)
        print("put data:",datas)
        r = requests.put(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        print('return:', r)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204

    #自定义服务-意图-获取意图中语料的id号
    def get_intentsOFids_CustomEntityVariableName(self, domain_id,intents_id):
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intents_id)
        result = requests.get(constant.SERVER + url, headers=self.headers, verify=False)
        # json_data = json.loads(result.text)
        json_data = result.json()
        print("json-----------:",result.text)
        ret = jsonpath.jsonpath(json_data, expr='$.[examplelist].[id]')
        ret2 = jsonpath.jsonpath(json_data, expr='$.[paramlist].[id]')
        ret3 = jsonpath.jsonpath(json_data, expr='$.[examplelist].[labellist].[entityid]')
        ret4 = jsonpath.jsonpath(json_data, expr='$.[examplelist].[labellist].[entityname]')
        print("--------:",ret[0],ret[2],ret2[0],ret3[0],ret4[0])
        return ret[0],ret[1],int(ret2[0]),ret3[0],ret4[0]#int(ret2[0])+2,即paramlist的id，每编辑一次，id自增一次，此意图取意图ID编辑一次，这次是第二次，所以加2







    #自定义服务-意图-新建-复杂预料-自定义实体调用
    def create_domain_NaturalCorpus(self, domain_id,intentname):
        url = "/v2/ux/agents/{}/domains/{}/intents/".format(self.agent_id,domain_id)
        datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"quote","text":"你叔叔{}会骑自行车吗".format(intentname),"labellist":[{"text":"你叔叔{}会骑自行车吗".format(intentname)}],"textIsEmpty":False}],"paramlist":[],"prompt":"NaturalCorpus"}
        jsons = json.dumps(datas)
        print("创建的自定义为：",jsons)
        r = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        if r.status_code != 201:
            #return r.text
            return False
        #return r.status_code == 201
        return True

    # 意图编辑，保存，编辑时不改变任何内容，只是用于提交一次，
    def domain_IntentsComplex_put_NaturalCorpus(self, domain_id, intentname):
        intent_id = self.get_intents_id_by_domain_name(domain_id, intentname)
        # corpusid为原意图中语料的id
        corpusids = self.get_intentsOFids_NaturalCorpus(domain_id, intent_id)
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intent_id)
        datas = {"id":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"intentname":intentname,"inputcontext":"","outputcontext":"","prompt":"NaturalCorpus","action":"","paramlist":[],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":int(corpusids),"intentid":int(intent_id),"text":"你叔叔{}会骑自行车吗".format(intentname),"type":"quote","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"text":"你叔叔{}会骑自行车吗".format(intentname)}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[]}
        jsons = json.dumps(datas)
        print("json put data:", jsons)
        print("put data:", datas)
        r = requests.put(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        print('return:', r)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204

        # 自定义服务-意图-获取意图中语料的id号

    def get_intentsOFids_NaturalCorpus(self, domain_id, intents_id):
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intents_id)
        result = requests.get(constant.SERVER + url, headers=self.headers, verify=False)
        # json_data = json.loads(result.text)
        json_data = result.json()
        print("json-----------:", result.text)
        ret = jsonpath.jsonpath(json_data, expr='$.[examplelist].[0].[id]')
        print("--------:", ret[0])
        return ret[0]


    #自定义服务-意图-新建-简单模板
    def create_domain_SimpleTemplate(self, domain_id,intentname,entityname,entityid):
        url = "/v2/ux/agents/{}/domains/{}/intents/".format(self.agent_id,domain_id)
        # datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"quote","text":"@冰花好","labellist":[{"paramname":entityname,"entityname":entityname,"entityid":entityid,"text":"@冰花好"}],"textIsEmpty":False}],"paramlist":[{"paramname":entityname,"entityname":entityname,"entityid":str(entityid),"required":False,"extendable":False,"prompt":"","isexistincorpus":True}],"prompt":"SimpleTemplate"}
        # datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"@{}:daname[好]".format(entityname),"labellist":[{"paramname":"daname","entityname":entityname,"entityid":entityid,"text":"@{}:daname".format(entityname)},{"text":"[好]","entityid":None}],"textIsEmpty":False}],"frontlist":[],"afterlist":[],"paramlist":[{"paramname":"daname","entityname":entityname,"entityid":entityid,"required":False,"extendable":False,"prompt":"","isexistincorpus":True}],"prompt":"SimpleTemplate"}
        datas ={"id": 0, "agentid": self.agent_id, "domainid": int(domain_id), "intentname": intentname, "inputcontext": "",
         "outputcontext": "", "examplelist": [{"type": "complex", "text": "@{}:ddname[{}][好]".format(entityname,intentname), "labellist": [
            {"paramname": "ddname", "entityname": entityname, "entityid": entityid, "text": "@{}:ddname".format(entityname)},
            {"text": "[{}][好]".format(intentname), "entityid": None}], "textIsEmpty": False}], "frontlist": [], "afterlist": [], "paramlist": [
            {"paramname": "ddname", "entityname": entityname, "entityid": entityid, "required": False, "extendable": False,
             "prompt": "", "isexistincorpus": True}], "prompt": "SimpleTemplate"}
        jsons = json.dumps(datas)
        print("创建的意图：",jsons)
        r = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        if r.status_code != 201:
            #return r.text
            return False
        #return r.status_code == 201
        return True

    # 意图编辑，保存，编辑时不改变任何内容，只是用于提交一次，
    def domain_IntentsComplex_put_SimpleTemplate(self, domain_id, intentname):
        intent_id = self.get_intents_id_by_domain_name(domain_id, intentname)
        # corpusid为原意图中语料的id
        corpusids = self.get_intentsOFids_SimpleTemplate(domain_id, intent_id)
        print("----------",corpusids[0],corpusids[1],corpusids[2],corpusids[3])
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intent_id)
        # datas = {"id":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"intentname":intentname,"inputcontext":"","outputcontext":"","prompt":"CustomEntityVariableName","action":"","paramlist":[{"id":int(corpusids[2]),"intentid":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"entityname":corpusids[4],"paramname":"shijianduan","required":False,"prompt":"","extendable":False,"isexistincorpus":True}],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":int(corpusids[0]),"intentid":int(intent_id),"text":"@{}:shijianduan[好]".format(corpusids[4]),"type":"complex","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"id":int(corpusids[1]),"intentid":int(intent_id),"exampleid":int(corpusids[0]),"entityid":int(corpusids[3]),"entityname":corpusids[4],"text":"@{}:shijianduan".format(corpusids[4]),"paramname":"shijianduan"},{"text":"[好]"}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[]}
        # datas = {"id":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"intentname":intentname,"inputcontext":"","outputcontext":"","prompt":"SimpleTemplate","action":"","paramlist":[{"id":int(corpusids[2]),"intentid":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"entityname":corpusids[4],"paramname":corpusids[4],"required":False,"prompt":"","extendable":False,"isexistincorpus":True}],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":int(corpusids[0]),"intentid":int(intent_id),"text":"@冰花好","type":"quote","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"id":int(corpusids[1]),"intentid":int(intent_id),"exampleid":int(corpusids[0]),"entityid":int(corpusids[3]),"entityname":corpusids[4],"text":"@冰花好","paramname":corpusids[4]}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[]}
        # datas = {"id":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"intentname":intentname,"inputcontext":"","outputcontext":"","prompt":"SimpleTemplate","action":"","paramlist":[{"id":int(corpusids[2]),"intentid":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"entityname":corpusids[4],"paramname":"daname","required":False,"prompt":"","extendable":False,"isexistincorpus":True}],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":int(corpusids[0]),"intentid":int(intent_id),"text":"@{}:daname[好]".format(corpusids[4]),"type":"complex","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"id":int(corpusids[1]),"intentid":int(intent_id),"exampleid":int(corpusids[0]),"entityid":int(corpusids[3]),"entityname":corpusids[4],"text":"@{}:daname".format(corpusids[4]),"paramname":"daname"},{"text":"[好]"}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[]}
        datas = {"id":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"intentname":intentname,"inputcontext":"","outputcontext":"","prompt":"SimpleTemplate","action":"","paramlist":[{"id":int(corpusids[2]),"intentid":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"entityname":corpusids[4],"paramname":"ddname","required":False,"prompt":"","extendable":False,"isexistincorpus":True}],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":int(corpusids[0]),"intentid":int(intent_id),"text":"@{}:ddname[{}][好]".format(corpusids[4],intentname),"type":"complex","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"id":int(corpusids[1]),"intentid":int(intent_id),"exampleid":int(corpusids[0]),"entityid":int(corpusids[3]),"entityname":corpusids[4],"text":"@{}:ddname".format(corpusids[4]),"paramname":"ddname"},{"text":"[{}][好]".format(intentname)}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[]}
        jsons = json.dumps(datas)
        # jsons = datas.json()
        print("json put data:",jsons)
        # print("put data:",datas)
        r = requests.put(constant.SERVER + url, headers=self.headers, json=datas, verify=False)
        print('return:', r)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204

    #自定义服务-意图-获取意图中语料的id号
    def get_intentsOFids_SimpleTemplate(self, domain_id,intents_id):
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intents_id)
        result = requests.get(constant.SERVER + url, headers=self.headers, verify=False)
        # json_data = json.loads(result.text)
        json_data = result.json()
        print("json-----------:",result.text)
        ret = jsonpath.jsonpath(json_data, expr='$.[examplelist].[0].[id]')
        ret2 = jsonpath.jsonpath(json_data, expr='$.[paramlist].[0].[id]')
        ret3 = jsonpath.jsonpath(json_data, expr='$.[examplelist].[0].[entityid]')
        ret4 = jsonpath.jsonpath(json_data, expr='$.[paramlist].[0].[entityname]')
        print("--------:",ret[0],ret[3],ret2[0],ret3[0],ret4[0])
        return ret[0],ret[3],int(ret2[0]),ret3[0],ret4[0]#int(ret2[0])+2,即paramlist的id，每编辑一次，id自增一次，此意图取意图ID编辑一次，这次是第二次，所以加2






    #自定义服务-启用
    def enable_domain_by_DomainId(self, domain_id):
        url = "/v2/ux/agents/{}/domains/{}/enable".format(self.agent_id,domain_id)
        para = {"params": {'domainid': domain_id}}
        pattern = "$.[*]"
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret:
            return True
        else:
            return False

    #自定义服务问答
    def domain_question_test(self, question):
        '''
        应用界面下的问答测试
        :param question: 问答
        :return: response json
        '''
        #result = ""
        url = "/v2/ux/agents/{}/smartqa/query".format(self.agent_id)
        data = {'params':{'question': question}}
        print(self.headers)
        result = requests.get(constant.SERVER + url, headers=self.headers, json=data, verify=False)
        print(result.text)
        return result

        # authinfo = json.loads(self.authinfo)
        # url = '/v2/ux/agents/{}/smartqa/query'.format(authinfo['agentid'])
        # para = {'params': {'question': question}}
        # result = ""
        # try:
        #     result, _ = self.sv_request(url, 'GET', parameter=para, timeout=15)
        #     print(result)
        # except:
        #     pass
        # return result


    #问答测试验证-source
    def domain_qa_answer_verification_source(self, response_json, expected):
        '''
        验证qa问题返回结果
        :param response_json:
        :param expected: 期望结果,用&&隔开,有1个计算pass
        :return:
        '''
        # data = json.loads(response_json['answer'])
        # print('回答内容:', data)
        # sourcevalue = jsonpath.jsonpath(data, expr="$.['source']")
        # if expected == sourcevalue:
        # #
        js = json.loads(response_json['answer'])
        print('回答内容:', js,expected,js['source'])
        if expected in js['source']:
            #如果输入为source判断
            return True
        # tts = js['tts'] #判断tts内容
        # for e in expected.split("&&"):
        #     if e in str(tts):
        #         return True
        return False

    #问答测试验证-source
    def domain_qa_answer_verification_source_notexpected(self, response_json, expected):
        '''
        验证qa问题返回结果
        :param response_json:
        :param expected: 期望结果,用&&隔开,有1个计算pass
        :return:
        '''
        # data = json.loads(response_json['answer'])
        # print('回答内容:', data)
        # sourcevalue = jsonpath.jsonpath(data, expr="$.['source']")
        # if expected == sourcevalue:
        # #
        js = json.loads(response_json['answer'])
        print('回答内容:', js,expected,js['source'])
        if expected not in js['source']:
            #如果输入为source判断
            return True
        # tts = js['tts'] #判断tts内容
        # for e in expected.split("&&"):
        #     if e in str(tts):
        #         return True
        return False
    #问答测试验证-验证命中的意图名称
    def domain_qa_answer_verification_operation_name(self, response_json, expected):
        '''
        验证qa问题返回结果
        :param response_json:
        :param expected: 期望结果,用&&隔开,有1个计算pass
        :return:
        '''
        # js = json.loads(response_json['answer'])
        # print('回答内容:', js)
        # if expected in js['operation']['name']:
        #     return True
        # return False
        js = json.loads(response_json['answer'])
        print('回答内容:', js,expected,js['hitlog']['intent'])
        if expected in js['hitlog']['intent']:
            #
            # data = json.loads(response_json['answer'])
            # print('回答内容:', data)
            # computervalue = jsonpath.jsonpath(data, expr="$.['operation']['params']['compute']")
            # if expected == computervalue:
            return True
        # tts = js['tts'] #判断tts内容
        # for e in expected.split("&&"):
        #     if e in str(tts):
        #         return True
        return False

    #问答测试验证-params
    def domain_qa_answer_verification_operation_computer(self, response_json, expected):
        '''
        验证qa问题返回结果
        :param response_json:
        :param expected: 期望结果,用&&隔开,有1个计算pass
        :return:
        '''
        js = json.loads(response_json['answer'])
        print('回答内容:', js,expected,js['hitlog']['parameters']['compute'])
        if expected in js['hitlog']['parameters']['compute']:
        #
        # data = json.loads(response_json['answer'])
        # print('回答内容:', data)
        # computervalue = jsonpath.jsonpath(data, expr="$.['operation']['params']['compute']")
        # if expected == computervalue:
            return True
        # tts = js['tts'] #判断tts内容
        # for e in expected.split("&&"):
        #     if e in str(tts):
        #         return True
        return False

    def domain_qa_answer_verification_operation_intents(self,response_json, expected):
        '''
                验证qa问题返回结果
                :param response_json:
                :param expected: 期望结果,用&&隔开,有1个计算pass
                :return:
                '''
        js = json.loads(response_json['answer'])
        print('回答内容:', js,expected,js['hitlog']['intent'])
        if expected in js['hitlog']['intent']:
            #
            # data = json.loads(response_json['answer'])
            # print('回答内容:', data)
            # computervalue = jsonpath.jsonpath(data, expr="$.['operation']['params']['compute']")
            # if expected == computervalue:
            return True
        # tts = js['tts'] #判断tts内容
        # for e in expected.split("&&"):
        #     if e in str(tts):
        #         return True
        return False

    # 问答测试验证-operation-ttx-text
    def domain_qa_answer_verification_operation_tts_text(self, response_json, expected):
        '''
        验证qa问题返回结果
        :param response_json:
        :param expected: 期望结果,用&&隔开,有1个计算pass
        :return:
        '''
        js = json.loads(response_json['answer'])
        # print('回答内容:', js,expected,js['tts'][0]['text'])
        tts = js['tts']  # 判断tts内容
        if tts:
            print('回答内容:', js, expected, js['tts'][0]['text'])
            if expected in js['tts'][0]['text']:
                return True
            else:
                return False
        else:
            print("tts内容为空！")
            return False

    # 问答测试验证-operation-subtree_state-template
    def domain_qa_answer_verification_operation_tree_currentstate(self, response_json, expected):
        '''
        验证qa问题返回结果-上下文
        :param response_json:
        :param expected: 期望结果,用&&隔开,有1个计算pass
        :return:
        '''
        # js = json.loads(response_json['answer'])
        # print('回答内容:', js)
        # tree = js['tree']  # 判断tts内容
        # if tree:
        #     if expected in js['tree']['currentstate']:
        #         return True
        #     else:
        #         return False
        # else:
        #     print("currentstate内容为空！")
        #     return False
        js = json.loads(response_json['answer'])
        print('回答内容:', js)
        tree = js['tree']  # 判断tts内容
        if tree:
            if expected in js['hitlog']['outcontext']:
                return True
            else:
                print("outcontext内容为空！")
                return False
        else:
            print("TTS内容为空！")
            return False

    # 问答测试验证-operation-subtree_state-template
    def domain_qa_answer_verification_operation_tree_template(self, response_json, expected):
        '''
        验证qa问题返回结果-上下文
        :param response_json:
        :param expected: 期望结果,用&&隔开,有1个计算pass
        :return:
        # js = json.loads(response_json['answer'])
        # print('回答内容:', js)
        # tree = js['tree']  # 判断tts内容
        # if tree:
        #     if expected in js['tree']['subtree'][0]['template']:
        #         return True
        #     else:
        #         return False
        # else:
        #     print("template内容为空！")
        #     return False
        '''
        js = json.loads(response_json['answer'])
        print('回答内容:', js)
        tree = js['tree']  # 判断tts内容
        if tree:
            if expected in js['hitlog']['incontext']:
                return True
            else:
                print("incontext内容为空！")
                return False
        else:
            print("TTS内容为空！")
            return False

    #自定义服务-意图-获取意图ID
    def get_intents_id_by_domain_name(self, domain_id,intents_name):
        url = "/v2/ux/agents/{}/domains/{}/intents".format(self.agent_id,domain_id)
        para = {"params": {'page': 1, 'pagesize': 10}}
        pattern = "$..data[?(@.intentname=='{}')].id".format(intents_name)
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret:
            return ret[0][0]
        return -1

    #自定义服务-意图-删除
    def delete_domain_intents(self, domain_id,intents_id):
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id,domain_id,intents_id)
        r = requests.delete(constant.SERVER + url, headers=self.headers, verify=False)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204

    # 自定义服务-意图-编辑
    def edit_intents(self,domain_id,intents_id,intentnamem="",inputcontextm="",outputcontextm="",promptm="",corpustextm="",addcorpustextm=""):
        #domain_id为将要编辑的服务id，intents_id为将要编辑的意图id，intentnamem为意图名称，inputcontextm为输入语境，outputcontextm为输出语境，promptm为意图回复，corpustextm为原始语料，addcorpustextm为添加的语料
        #corpusid为原意图中语料的id
        corpusid = self.get_intentsOFCorpus_id(domain_id,intents_id)
        #intentnamem为意图名称
        intentname = self.get_intentsOFinstentsname(domain_id,intents_id)
        if intentnamem=="":
            domainnames=intentname
        else:
            domainnames=intentnamem
        #inputcontextm为输入语境，
        inputcontext = self.get_intentsOFinputcontext(domain_id,intents_id)
        if inputcontextm=="":
            inputcontexts=inputcontext
        else:
            inputcontexts=inputcontextm
        #outputcontextm为输出语境，
        outputcontext = self.get_intentsOFoutputcontext(domain_id,intents_id)
        if outputcontextm=="":
            outputcontexts=outputcontext
        else:
            outputcontexts=outputcontextm
        #promptm为意图回复，
        prompt = self.get_intentsOFprompt(domain_id,intents_id)
        if promptm=="":
            prompts=prompt
        else:
            prompts=promptm
        #corpustextm为原始语料，
        corpustext = self.get_intentsOFCorpus_test(domain_id,intents_id)
        if corpustextm=="":
            corpustexts=corpustext
        else:
            corpustexts=corpustextm
        #addcorpustextm为添加的语料
        if addcorpustextm=="":
            addcorpustexts=r"how?"
        else:
            addcorpustexts=addcorpustextm

        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id,domain_id,intents_id)
        datas = {"id":int(intents_id),"domainid":int(domain_id),"agentid":self.agent_id,"intentname":domainnames,"inputcontext":inputcontexts,"outputcontext":outputcontexts,"prompt":prompts,"action":"","paramlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":int(corpusid),"intentid":int(intents_id),"text":corpustexts,"type":"quote","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"text":corpustexts}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[{"type":"quote","text":addcorpustexts,"labellist":[{"text":addcorpustexts}],"textIsEmpty":False}]}
        #jsons = json.dumps(datas)
        #print('json:',jsons)
        r = requests.put(constant.SERVER + url, headers=self.headers, json=datas, verify=False)
        print('return:',r)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204

    #自定义服务-意图-获取意图中各个参数获取的id号
    def get_intentsOFCorpus_ParameterIds(self, domain_id,intents_id):
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id,domain_id,intents_id)
        para = {"params": ""}
        pattern = "$.paramlist.[*].id"
        paramlistid = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        para = {"params": ""}
        pattern = "$.examplelist.[*].id"
        examplelistid = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        para = {"params": ""}
        pattern = "$.examplelist.[?(@.paramname=='compute')].id"
        syscomputeid = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if paramlistid:
            return paramlistid[0][0],examplelistid[0][0],syscomputeid[0][0]
        return -1
    #编辑复杂语料中的参数
    def create_domain_IntentsComplex_EditInfo(self,domain_id,intentnamem):
        #获取意图ID
        intents_id = self.get_intents_id_by_domain_name(domain_id,intentnamem)
        parperids = self.get_intentsOFCorpus_ParameterIds(domain_id,intents_id)
        sysentityid = self.intents_get_entity_id_by_entity_name("sys.compute")
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id,domain_id,intents_id)
        datas = {"id":intents_id,"domainid":int(domain_id),"agentid":self.agent_id,"intentname":intentnamem,"inputcontext":"","outputcontext":"","prompt":"","action":"","paramlist":[{"id":parperids[0],"intentid":intents_id,"domainid":int(domain_id),"agentid":self.agent_id,"entityname":"sys.compute","paramname":"compute","required":False,"prompt":"","extendable":False,"isexistincorpus":True}],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":parperids[1],"intentid":intents_id,"text":"[算算]@sys.compute:compute[结果|是|得|等于|][多少|什么|几|]","type":"complex","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"text":"[算算]"},{"id":parperids[2],"intentid":intents_id,"exampleid":parperids[1],"entityid":sysentityid,"entityname":"sys.compute","text":"@sys.compute:compute","paramname":"compute"},{"text":"[结果|是|得|等于|][多少|什么|几|]"}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[]}
        r = requests.put(constant.SERVER + url, headers=self.headers, json=datas, verify=False)
        print('return:',r)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204


    #自定义服务-意图-获取意图中语料的id号
    def get_intentsOFCorpus_id(self, domain_id,intents_id):
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id,domain_id,intents_id)
        # para = {"params": ""}
        # pattern = "$.[examplelist].[0].[id]"
        # ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        # print("----------",ret[0])
        # if ret:
        #     return ret[0][0]
        # return -1
        result = requests.get(constant.SERVER + url, headers=self.headers, verify=False)
        json_data = result.json()
        print("json-----------:",result.text)
        ret = jsonpath.jsonpath(json_data, expr='$.[examplelist].[id]')
        return ret[0]


    # 自定义服务-意图-获取意图中语料内容
    def get_intentsOFCorpus_test(self, domain_id, intents_id):
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intents_id)
        para = {"params": ""}
        pattern = "$.[examplelist].[0].[text]"
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret:
            return ret[0][0]
        return -1

    #自定义服务-意图-获取意图中意图名称
    def get_intentsOFinstentsname(self, domain_id,intents_id):
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id,domain_id,intents_id)
        para = {"params": ""}
        pattern = "$.[intentname]"
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret:
            return ret[0][0]
        return -1

    #自定义服务-意图-获取意图中输入语境
    def get_intentsOFinputcontext(self, domain_id,intents_id):
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id,domain_id,intents_id)
        para = {"params": ""}
        pattern = "$.[inputcontext]"
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret:
            return ret[0][0]
        return -1

    #自定义服务-意图-获取意图中输出语境
    def get_intentsOFoutputcontext(self, domain_id,intents_id):
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id,domain_id,intents_id)
        para = {"params": ""}
        pattern = "$.[outputcontext]"
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret:
            return ret[0][0]
        return -1

    #自定义服务-意图-获取意图中意图回复
    def get_intentsOFprompt(self, domain_id,intents_id):
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id,domain_id,intents_id)
        para = {"params": ""}
        pattern = "$.[prompt]"
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ret:
            return ret[0][0]
        return -1

    # 自定义服务-获取服务总数，服务id列表，默认agent_id=549，返回所有服务的id列表
    def get_domain_itemtotalcountlist(self):
        domainidlist = []
        url = "/v2/ux/agents/{}/domains/".format(self.agent_id)
        para = {"params": {'page': 1, 'pagesize': 10}}
        pattern = "$..[pagecount]"#服务列表总页数
        PageTotalCount = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        pattern = "$..[itemcount]"  # 服务列表服务总数
        DomainTotalCount = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        url = "/v2/ux/agents/{}/domains/".format(self.agent_id)
        for i in range(1,PageTotalCount[0][0]+1):
            para = {"params": {'page': i, 'pagesize': 10}}
            pattern = "$..[id]"
            result = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
            domainidlist.extend(result[0])
        return domainidlist

    # 自定义服务-获取意图总数，默认agent_id=549，返回所有服务的意图总数
    def get_intents_itemtotalcount(self):
        domainids = self.get_domain_itemtotalcountlist()
        domaincount = len(domainids)
        intentscount = 0
        for i in range(0, domaincount):
            url = "/v2/ux/agents/{}/domains/{}/intents?page=1&pagesize=10".format(self.agent_id, domainids[i])
            para = {"params": {'page': 1, 'pagesize': 10}}
            pattern = "$..[itemcount]"
            result = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
            intentscount = intentscount + result[0][0]
        return intentscount


    # 自定义服务-获取服务总数（itemcount），服务列表页数（pagecount），首页服务数量(id)，默认agent_id=549
    def get_domain_ItemcountPagecountIdCount(self):
        domainidlist = []
        url = "/v2/ux/agents/{}/domains/".format(self.agent_id)
        para = {"params": {'page': 1, 'pagesize': 10}}
        pattern = "$..[pagecount]"#服务列表总页数
        PageTotalCount = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if PageTotalCount:
            pagecount = PageTotalCount[0][0]
        else:
            return -1
        pattern = "$..[itemcount]"  # 服务列表服务总数
        ItemTotalCount = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        if ItemTotalCount:
            itemcount = ItemTotalCount[0][0]
        else:
            return -1
        pattern = "$..[id]"  # 首页服务id数
        IdTotalCount = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        print(IdTotalCount)
        if IdTotalCount:
            idcount = len(IdTotalCount[0])
        else:
            return -1
        return itemcount,pagecount,idcount

    # admin登录
    def test_logininfo_admin(self):
        logger.info("login process")
        headers = {'Connection': 'keep-alive',
                   'Content-Type': 'application/json',
                   'Accept': 'application/json, text/plain, */*'}
        url = '/v2/ux/user/login'
        # data ={"username":constant.SV_ADMIN,"password":constant.SV_ADMIN_PWD}
        data = {"username": 'admin@cloudminds', "password": 'Smartvoice1506'}
        result = requests.post(constant.SERVER + url, headers=headers, json=data, timeout=15, verify=False)
        data = json.loads(result.text)
        userid = jsonpath.jsonpath(data, expr='$.[userid]')
        agentid = jsonpath.jsonpath(data, expr='$.[agentid]')
        sessionid = jsonpath.jsonpath(data, expr='$.[sessionid]')
        authtoken = jsonpath.jsonpath(data, expr='$.[authtoken]')
        if agentid[0] == 1:
            return userid[0], agentid[0], sessionid[0], authtoken[0]
        else:
            print("admin login failed!")
            return False

    # admin，创建服务
    def admin_create_domain(self, domainname, domaininfo):
        info = self.test_logininfo_admin()
        authinfo = {"userid": info[0], "authtoken": info[3], "sessionid": info[2], "agentid": info[1],
                    "manualsel": True, "userName": "admin@cloudminds", "role": "master", "isadmin": True,
                    "masteruserid": 1, "lang": "zh-CN"}
        self.auinfo = json.dumps(authinfo)
        headers = {'Connection': 'keep-alive',
                   'Content-Type': 'application/json',
                   'Accept': 'application/json, text/plain, */*', 'authinfo': self.auinfo}
        url = '/v2/ux/agents/1/domains/'
        data = {"domainname":domainname,"domaininfo":domaininfo,"type":"自建","status":"可用","url":"adddd","release":1}
        result = requests.post(constant.SERVER + url, headers=headers, json=data, timeout=15, verify=False)
        if result.status_code == 201:
            return True
        else:
            return False

    # admin 获取服务的id号
    def admin_get_domain_id_by_domain_name(self, domain_name):
        info = self.test_logininfo_admin()
        authinfo = {"userid": info[0], "authtoken": info[3], "sessionid": info[2], "agentid": info[1],
                    "manualsel": True, "userName": "admin@cloudminds", "role": "master", "isadmin": True,
                    "masteruserid": 1, "lang": "zh-CN"}
        self.auinfo = json.dumps(authinfo)
        headers = {'Connection': 'keep-alive',
                   'Content-Type': 'application/json',
                   'Accept': 'application/json, text/plain, */*', 'authinfo': self.auinfo}
        url = "/v2/ux/agents/1/domains/?page=1&pagesize=10"
        pattern = "$..data[?(@.domainname== '{}')].id".format(domain_name)
        result = requests.get(constant.SERVER + url, headers=headers, timeout=15, verify=False)
        datas = json.loads(result.text)
        domianid = jsonpath.jsonpath(datas,expr=pattern)
        if result:
            #return domianid[0]
            return domianid[0]
        else:
            return False



    #admin 删除服务-domain_id
    def admin_delete_domain_by_domain_id(self, domain_id):
        info = self.test_logininfo_admin()
        authinfo = {"userid": info[0], "authtoken": info[3], "sessionid": info[2], "agentid": info[1],
                    "manualsel": True, "userName": "admin@cloudminds", "role": "master", "isadmin": True,
                    "masteruserid": 1, "lang": "zh-CN"}
        self.auinfo = json.dumps(authinfo)
        headers = {'Connection': 'keep-alive',
                   'Content-Type': 'application/json',
                   'Accept': 'application/json, text/plain, */*', 'authinfo': self.auinfo}
        url = "/v2/ux/agents/1/domains/{}".format(domain_id)
        r = requests.delete(constant.SERVER + url, headers=headers, verify=False)
        #if r.status_code == 204:
        if r.status_code == 204:
            #return True
            return True
        else:
            return False


    #自定义服务-创建实体
    def create_entity(self, entity_name):
        """
        通过entity_name创建实体
        :param ：entity_name
        :return:
        Status Code: 201 Created
        return  ture
        """
        url = "/v2/ux/agents/{}/entities/add".format(self.agent_id)
        data = {"entityname":entity_name}
        r = requests.post(constant.SERVER + url, headers=self.headers, json=data, verify=False)
        if r.status_code != 201:
            return r.text
        return r.status_code == 201

    #获取实体的id号
    def get_entity_id_by_entity_name(self, entity_name):
        """
        通过entity_name，获取该实体的id
        :param entity_name（必填）
        :return:
        531
        """
        url = "/v2/ux/agents/{}/entities/search".format(self.agent_id)
        para = {"params": {'page': 1, 'pagesize': 10,'keyword':''}}
        pattern = "$.data[?(@.entityname=='{}')].id".format(entity_name)
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        print(ret[0][0])
        if ret:
            return ret[0][0]
        return False

    #删除实体-entity_id
    def delete_entity_by_entity_id(self, entity_id):
        """
            通过entity_id，删除实体
            :param entity_id（必填）
            :return:
             """
        url = "/v2/ux/agents/{}/entities/{}".format(self.agent_id,entity_id)
        r = requests.delete(constant.SERVER + url, headers=self.headers, verify=False)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204

    #自定义服务-创建实例
    def create_entityItems(self,entity_id,item_name):
        """
        通过实体及实例名创建实例
        :param :
        :return:
        Status Code: 201 Created
        return  ture
        """
        url = "/v2/ux/agents/{}/entities/{}/entityitems/".format(self.agent_id,entity_id)
        data = {"entityid":entity_id,"entityitemname":item_name,"synonyms":item_name,"source":""}
        print("创建的自定义实体为：",data)
        r = requests.post(constant.SERVER + url, headers=self.headers, json=data, verify=False)
        print(r.text)
        if r.status_code != 201:
            return False
        return True

    # 自定义服务-意图-新建-复杂预料-语料实体重复
    def create_domain_IntentsComplex_DoubleCorps(self, domain_id, intentname):
        url = "/v2/ux/agents/{}/domains/{}/intents/".format(self.agent_id, domain_id)
        sysentityid = self.intents_get_entity_id_by_entity_name("sys.compute")
        datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"[小兴][算算]@sys.compute:compute[结果|是|得|等于|][多少|什么|几|]","labellist":[{"text":"[小兴][算算]"},{"paramname":"compute","entityname":"sys.compute","entityid":sysentityid,"text":"@sys.compute:compute"},{"text":"[结果|是|得|等于|][多少|什么|几|]"}],"textIsEmpty":False},{"type":"complex","text":"[小兴][算算]@sys.compute:compute[结果|是|得|等于|][多少|什么|几|]","labellist":[{"text":"[小兴][算算]"},{"paramname":"compute","entityname":"sys.compute","entityid":sysentityid,"text":"@sys.compute:compute"},{"text":"[结果|是|得|等于|][多少|什么|几|]"}],"textIsEmpty":False}],"paramlist":[{"paramname":"compute","entityname":"sys.compute","entityid":str(sysentityid),"required":False,"extendable":False,"prompt":"","isexistincorpus":True}],"prompt":""}
        jsons = json.dumps(datas)
        r = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        if r.status_code != 201:
            return False
        return True


    #自定义服务-意图-新建-复杂预料
    def create_domain_IntentsComplex_QuestioningInformation(self, domain_id,intentname):
        url = "/v2/ux/agents/{}/domains/{}/intents/".format(self.agent_id,domain_id)
        # sysentityid = self.intents_get_entity_id_by_entity_name("sys.compute")
        sysentityid = self.intents_get_entity_id_by_entity_name("sys.entity.city")
        # datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"[点点][告诉我]@sys.entity.city:ctname[怎么样]","labellist":[{"text":"[点点][告诉我]","entityid":None},{"paramname":"ctname","entityname":"sys.entity.city","entityid":sysentityid,"text":"@sys.entity.city:ctname"},{"text":"[怎么样]","entityid":None}],"textIsEmpty":False}],"frontlist":[],"afterlist":[],"paramlist":[{"paramname":"ctname","entityname":"sys.entity.city","entityid":sysentityid,"required":True,"extendable":False,"prompt":"请问是什么呀","isexistincorpus":True}],"prompt":"南京，10朝古都，历史文化名称，我爱南京哟"}
        datas = {"id":0,"agentid":self.agent_id,"domainid":int(domain_id),"intentname":intentname,"inputcontext":"","outputcontext":"","examplelist":[{"type":"complex","text":"[点点{}][告诉我]@sys.entity.city:ctname[怎么样]".format(intentname),"labellist":[{"text":"[点点{}][告诉我]".format(intentname),"entityid":None},{"paramname":"ctname","entityname":"sys.entity.city","entityid":sysentityid,"text":"@sys.entity.city:ctname"},{"text":"[怎么样]","entityid":None}],"textIsEmpty":False},{"type":"complex","text":"[点点{}][告诉我][怎么样]".format(intentname),"labellist":[{"text":"[点点{}][告诉我][怎么样]".format(intentname),"entityid":None}],"textIsEmpty":False}],"frontlist":[],"afterlist":[],"paramlist":[{"paramname":"ctname","entityname":"sys.entity.city","entityid":sysentityid,"required":True,"extendable":False,"prompt":"请问是什么呀","isexistincorpus":True}],"prompt":"南京，10朝古都，历史文化名称，我爱南京哟"}
        jsons = json.dumps(datas)
        print("创建的自定义意图为：",jsons)
        r = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        if r.status_code != 201:
            #return r.text
            return False
        #return r.status_code == 201
        return True

    # 意图编辑，保存，编辑时不改变任何内容，只是用于提交一次，
    def domain_IntentsComplex_put_QuestioningInformation(self, domain_id, intentname):
        intent_id = self.get_intents_id_by_domain_name(domain_id, intentname)
        # corpusid为原意图中语料的id
        corpusids = self.get_intentsOFids_QuestioningInformation(domain_id, intent_id)
        print("----------",corpusids[0],corpusids[1],corpusids[2],corpusids[3])
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intent_id)
        # datas = {"id":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"intentname":intentname,"inputcontext":"","outputcontext":"","prompt":"嗯呐嗯呐，好好玩吧!","action":"","paramlist":[{"id":int(corpusids[2]),"intentid":int(intent_id),"domainid":int(domain_id),"agentid":self.agent_id,"entityname":"sys.entity.city","paramname":"ctname","required":True,"prompt":"请问什么时候呀","extendable":False,"isexistincorpus":True}],"frontlist":[],"afterlist":[],"deleteexampleidlist":[],"unchangedexamplelist":[{"id":int(corpusids[0]),"intentid":int(intent_id),"text":"[小邓][准备|计划]@sys.date:daname[出国旅游呢]","type":"complex","agentid":self.agent_id,"domainid":int(domain_id),"labellist":[{"text":"[小邓][准备|计划]"},{"id":int(corpusids[1]),"intentid":int(intent_id),"exampleid":int(corpusids[0]),"entityid":int(corpusids[3]),"entityname":"sys.entity.city","text":"@sys.entity.city:ctname","paramname":"ctname"},{"text":"[出国旅游呢]"}],"textIsEmpty":False}],"changedexamplelist":[],"addexamplelist":[]}
        # datas = {"id": int(intent_id), "domainid": int(domain_id), "agentid": self.agent_id, "intentname": intentname, "inputcontext": "",
        #  "outputcontext": "", "prompt": "南京，10朝古都，历史文化名称，我爱南京哟", "action": "", "paramlist": [
        #     {"id": int(corpusids[2]), "intentid": int(intent_id), "domainid": int(domain_id), "agentid": self.agent_id, "entityname": "sys.entity.city",
        #      "paramname": "ctname", "required": True, "prompt": "请问是什么呀", "extendable": False,
        #      "isexistincorpus": True}], "frontlist": [], "afterlist": [], "deleteexampleidlist": [],
        #  "unchangedexamplelist": [
        #      {"id": int(corpusids[0]), "intentid": int(intent_id), "text": "[点点][告诉我]@sys.entity.city:ctname[怎么样]", "type": "complex",
        #       "agentid": self.agent_id, "domainid": int(domain_id), "labellist": [{"text": "[点点][告诉我]"},
        #                                                        {"id": int(corpusids[1]), "intentid": int(intent_id), "exampleid": int(corpusids[0]),
        #                                                         "entityid": int(corpusids[3]), "entityname": "sys.entity.city",
        #                                                         "text": "@sys.entity.city:ctname",
        #                                                         "paramname": "ctname"}, {"text": "[怎么样]"}],
        #       "textIsEmpty": False}], "changedexamplelist": [], "addexamplelist": []}
        datas = {"id": int(intent_id), "domainid": int(domain_id), "agentid": self.agent_id, "intentname": intentname, "inputcontext": "",
         "outputcontext": "", "prompt": "南京，10朝古都，历史文化名称，我爱南京哟", "action": "", "paramlist": [
            {"id": int(corpusids[3]), "intentid": int(intent_id), "domainid": int(domain_id), "agentid": self.agent_id, "entityname": "sys.entity.city",
             "paramname": "ctname", "required": True, "prompt": "请问是什么呀", "extendable": False,
             "isexistincorpus": True}], "frontlist": [], "afterlist": [], "deleteexampleidlist": [],
         "unchangedexamplelist": [
             {"id": int(corpusids[0]), "intentid": int(intent_id), "text": "[点点{}][告诉我][怎么样]".format(intentname), "type": "complex", "agentid": self.agent_id,
              "domainid": int(domain_id), "labellist": [{"text": "[点点{}][告诉我][怎么样]".format(intentname)}], "textIsEmpty": False},
             {"id": int(corpusids[1]), "intentid": int(intent_id), "text": "[点点{}][告诉我]@sys.entity.city:ctname[怎么样]".format(intentname), "type": "complex",
              "agentid": self.agent_id, "domainid": int(domain_id), "labellist": [{"text": "[点点{}][告诉我]".format(intentname)},
                                                               {"id": int(corpusids[2]), "intentid": int(intent_id), "exampleid": int(corpusids[1]),
                                                                "entityid": int(corpusids[4]), "entityname": "sys.entity.city",
                                                                "text": "@sys.entity.city:ctname",
                                                                "paramname": "ctname"}, {"text": "[怎么样]"}],
              "textIsEmpty": False}], "changedexamplelist": [], "addexamplelist": []}
        jsons = json.dumps(datas)
        print("json put data:",jsons)
        print("put data:",datas)
        r = requests.put(constant.SERVER + url, headers=self.headers, json=jsons, verify=False)
        print('return:', r)
        if r.status_code != 204:
            return r.text
        return r.status_code == 204

    #自定义服务-意图-获取意图中语料的id号
    def get_intentsOFids_QuestioningInformation(self, domain_id,intents_id):
        url = "/v2/ux/agents/{}/domains/{}/intents/{}".format(self.agent_id, domain_id, intents_id)
        result = requests.get(constant.SERVER + url, headers=self.headers, verify=False)
        # json_data = json.loads(result.text)
        json_data = result.json()
        print("json-----------:",result.text)
        ret = jsonpath.jsonpath(json_data, expr='$.[examplelist].[id]')
        ret2 = jsonpath.jsonpath(json_data, expr='$.[paramlist].[0].[id]')
        ret3 = jsonpath.jsonpath(json_data, expr='$.[examplelist].[entityid]')
        print("--------:",ret[0],ret[2],ret2[0],ret3[0])
        return ret[0],ret[2],ret[4],int(ret2[0]),ret3[0]



    #创建意图，返回的实体列表筛选
    def intents_get_entity_id_by_entity_name(self, entity_name):
        """
        通过entity_name，获取该实体的id
        :param entity_name（必填）
        :return:
        531
        """
        url = "/v2/ux/agents/{}/entities/".format(self.agent_id)
        para = {"params": ""}
        pattern = "$.[?(@.entityname=='{}')].id".format(entity_name)
        ret = self.sv_request(url, 'GET', parameter=para, pattern=pattern)
        print(ret[0][0])
        if ret:
            return ret[0][0]
        return False



    def download_file(self, file_name):
        try:
            url = '/v2/ux/manual/'
            headers = self.headers
            headers['Content-Description'] = 'File Transfer'
            headers['Content-Type'] = 'application/octet-stream'
            headers['Content-Disposition'] = 'attachment'
            file_path = os.path.dirname(os.path.abspath(__file__))
            file_parent = os.path.dirname(file_path)
            real_file_parent = os.path.dirname(file_parent)
            file_real_path = real_file_parent + os.sep + 'testdata' + os.sep
            file_value = os.path.join(file_real_path, file_name)
            response = requests.get(constant.SERVER + url, headers=headers, verify=False)
            fp = open(file_value, "wb")
            fp.write(response.content)
            fp.close()
            if response.status_code ==200:
                print('下载文件成功', response.status_code)
                return True
            else:
                print('下载失败',response.text)
                return False
        except Exception as e:
            print(e)



    def get_domain_id_by_name(self, domain_type, domain_name):
        url = "/v2/ux/agents/services"
        para = {"params": {'agentid': self.agent_id, 'domaintype': domain_type}}
        pattern = "$..[?(@.name == '{}')].id".format(domain_name)
        ret = self.sv_request_with_authinfo(url, 'GET', parameter=para, pattern=pattern)
        if ret:
            return ret[0][0]
        return -1

    def get_domain_status_by_name(self, domain_type, domain_name):
        url = "/v2/ux/agents/services"
        para = {"params": {'agentid': self.agent_id, 'domaintype': domain_type}}
        pattern = "$..[?(@.name == '{}')].enabled".format(domain_name)
        ret = self.sv_request_with_authinfo(url, 'GET', parameter=para, pattern=pattern)
        if ret:
            # false true
            return ret[0][0]
        return -1

    def enable_domain_by_name(self, domain_type, domain_name):
        url = "/v2/ux/agents/{}/domains/{}/enable".format(self.agent_id, self.get_domain_id_by_name(domain_type, domain_name))
        r = requests.get(constant.SERVER + url, headers=self.headers, params={'domainid': 45}, verify=False)
        return r.status_code == 200

    def disenable_domain_by_name(self, domain_type, domain_name):
        url = "/v2/ux/agents/{}/domains/{}/disable".format(self.agent_id, self.get_domain_id_by_name(domain_type, domain_name))
        data = {'domainid': 45}
        r = requests.post(constant.SERVER + url, headers=self.headers, json=data, verify=False)
        return r.status_code == 200


if __name__ =="__main__":
    # print(Base("pepper@cloudminds.com","pepper1113").login())
    t = CustomService("pepper@cloudminds.com","pepper1113")
    #domain_id = t.edit_intents(525,3349,"editgroupdssssss121212")
    #domain_id = t.create_domain_intents(525)
    #domain_id = t.question_test("ertret")
    #domain_id = t.create_domain("wewewe","etretret")
    #omain_id = t.get_domain_id_by_domain_name("uiououo")
    domain_id = t.download_file("SmartVoice-Manual-zh-CN.pptx")
    print(domain_id)

    # status = t.get_domain_status_by_name('0', 'weather')
    # if status:
    #     t.disenable_domain_by_name('0', 'weather')
    #
    # status = t.get_domain_status_by_name('0', 'weather')
    # print(status)


