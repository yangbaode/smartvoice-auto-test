# !/usr/bin/env python
# -*- coding: utf-8 -*-
from lib.utils.logger import logger
from lib.utils import constant
from lib.modules.Base import Base
import requests
import json
import jsonpath


class LoginMenu(Base):
    def __init__(self, user, password, agent_id=None):
        Base.__init__(self, user, password)
        self.get_sv_authinfo(agent_id=agent_id)

    def is_complete(self):
        headers = {'Connection': 'keep-alive',
         'Content-Type':'application/json',
         'Accept':'application/json, text/plain, */*',
         'authinfo': self.authinfo}
        url = '/v2/ux/user/info/iscomplete'
        r = requests.get(constant.SERVER +url, headers=headers, verify=False)
        print(r.text)
        return r.json()['iscomplete']

    def statistics_hittimes_agent(self, para, pattern=None):
        url = "/v2/ux/statistics/hittimes/agent"
        return self.sv_request(url, 'GET', parameter=para, pattern=pattern)

    def statistics_hittimes_domain(self, para, pattern=None):
        url = "/v2/ux/statistics/hittimes/domain"
        return self.sv_request(url, 'GET', parameter=para, pattern=pattern)

    def get_agent_num(self):
        url = "/v2/ux/statistics/totalagent"
        return self.sv_request(url, 'GET')[0]['total']

    #admin登录
    def test_logininfo_admin(self):
        logger.info("login process")
        headers = {'Connection': 'keep-alive',
         'Content-Type':'application/json',
         'Accept':'application/json, text/plain, */*'}
        url = '/v2/ux/user/login'
        data = {"username": constant.SV_ADMIN, "password": constant.SV_ADMIN_PWD}
        result = requests.post(constant.SERVER +url, headers=headers, json=data, timeout=15, verify=False)
        data = json.loads(result.text)
        #提取信息，用于封装表头
        userid = jsonpath.jsonpath(data, expr='$.[userid]')
        agentid = jsonpath.jsonpath(data, expr='$.[agentid]')
        sessionid = jsonpath.jsonpath(data, expr='$.[sessionid]')
        authtoken = jsonpath.jsonpath(data, expr='$.[authtoken]')
        if agentid[0] == 1:
            return userid[0],agentid[0],sessionid[0],authtoken[0]
        else:
            print("admin login failed!")
            return False

    #admin，创建分组信息
    def test_admin_create_groups(self,groupname,groupinfo):
        info = self.test_logininfo_admin()
        authinfo = {"userid":info[0],"authtoken":info[3],"sessionid":info[2],"agentid":info[1],"manualsel":False,"userName":"admin@cloudminds","role":"master","isadmin":True,"masteruserid":1,"lang":"zh-CN"}
        self.auinfo = json.dumps(authinfo)
        headers = {'Connection': 'keep-alive',
         'Content-Type':'application/json',
         'Accept':'application/json, text/plain, */*','authinfo':self.auinfo}
        url = '/v2/ux/groups/'
        data = {"agentid":info[1],"group":{"info":groupinfo,"name":groupname},"authority":{"customdomain":True,"domainmanage":True,"qatype":True,"qamark":True,"faqmanage":True,"faq":True,"chitchat":True,"train":True}}
        result = requests.post(constant.SERVER +url, headers=headers, json=data, timeout=15, verify=False)
        if result.status_code == 201:
            return groupname
        else:
            return False

    # admin，创建分组信息权限信息-slave
    def test_admin_create_slavegroups(self, groupname, groupinfo):
        info = self.test_logininfo_admin()
        authinfo = {"userid": info[0], "authtoken": info[3], "sessionid": info[2], "agentid": info[1],
                    "manualsel": False, "userName": constant.SV_ADMIN, "role": "master", "isadmin": True,
                    "masteruserid": 1, "lang": "zh-CN"}
        self.auinfo = json.dumps(authinfo)
        headers = {'Connection': 'keep-alive',
                   'Content-Type': 'application/json',
                   'Accept': 'application/json, text/plain, */*', 'authinfo': self.auinfo}
        url = '/v2/ux/groups/'
        data = {"agentid": info[1], "group": {"info": groupinfo, "name": groupname},
                "authority": {"customdomain": True, "domainmanage": False, "qatype": False, "qamark": False,
                              "faqmanage": True, "faq": False, "chitchat": False, "train": False}}
        result = requests.post(constant.SERVER + url, headers=headers, json=data, timeout=15, verify=False)
        if result.status_code == 201:
            return groupname
        else:
            return False

    #admin,获取添加分组的id
    def test_admin_get_groupsid(self,groupname):
        info = self.test_logininfo_admin()
        authinfo = {"userid":info[0],"authtoken":info[3],"sessionid":info[2],"agentid":info[1],"manualsel":False,"userName":"admin@cloudminds","role":"master","isadmin":True,"masteruserid":1,"lang":"zh-CN"}
        self.auinfo = json.dumps(authinfo)
        headers = {'Connection': 'keep-alive',
         'Content-Type':'application/json',
         'Accept':'application/json, text/plain, */*','authinfo':self.auinfo}
        url = '/v2/ux/groups/?page=1&pagesize=10&keyword='
        result = requests.get(constant.SERVER +url, headers=headers, timeout=15, verify=False)
        datas = json.loads(result.text)
        parame = '$..[?(@.name=="{}")].id'.format(groupname)
        groupid = jsonpath.jsonpath(datas, expr=parame)
        return groupid[0]

    #admin，删除分组信息
    def test_admin_dalete_group(self,groupid):
        info = self.test_logininfo_admin()
        authinfo = {"userid": info[0], "authtoken": info[3], "sessionid": info[2], "agentid": info[1],
                    "manualsel": False, "userName": constant.SV_ADMIN, "role": "master", "isadmin": True,
                    "masteruserid": 1, "lang": "zh-CN"}
        self.auinfo = json.dumps(authinfo)
        headers = {'Connection': 'keep-alive',
                   'Content-Type': 'application/json',
                   'Accept': 'application/json, text/plain, */*', 'authinfo': self.auinfo}
        url = '/v2/ux/groups/{}'.format(groupid)
        result = requests.delete(constant.SERVER + url, headers=headers, timeout=15, verify=False)
        if result.status_code == 204:
            return True
        else:
            return False

    #admin,创建子账号
    def test_admin_create_master(self,username,password,groupname):
        groupid = self.test_admin_get_groupsid(groupname)
        info = self.test_logininfo_admin()
        authinfo = {"userid": info[0], "authtoken": info[3], "sessionid": info[2], "agentid": info[1],
                    "manualsel": False, "userName": constant.SV_ADMIN, "role": "master", "isadmin": True,
                    "masteruserid": 1, "lang": "zh-CN"}
        self.auinfo = json.dumps(authinfo)
        headers = {'Connection': 'keep-alive',
                   'Content-Type': 'application/json',
                   'Accept': 'application/json, text/plain, */*', 'authinfo': self.auinfo}
        url = '/v2/ux/slaves/'
        data = {"groupids":[groupid],"user":{"mail":"autotest@cloudminds.com","password":password,"realname":"autotestname","telephone":"13910392086","username":username,"role":"operator"}}
        result = requests.post(constant.SERVER + url, headers=headers, json=data, timeout=15, verify=False)
        print(result.text)
        if result.status_code == 201:
            return True
        else:
            return False

    #admin,创建slave账号
    def test_admin_create_slavemaster(self,username,password,groupname):
        groupid = self.test_admin_get_groupsid(groupname)
        info = self.test_logininfo_admin()
        authinfo = {"userid": info[0], "authtoken": info[3], "sessionid": info[2], "agentid": info[1],
                    "manualsel": False, "userName": constant.SV_ADMIN, "role": "master", "isadmin": True,
                    "masteruserid": 1, "lang": "zh-CN"}
        self.auinfo = json.dumps(authinfo)
        headers = {'Connection': 'keep-alive',
                   'Content-Type': 'application/json',
                   'Accept': 'application/json, text/plain, */*', 'authinfo': self.auinfo}
        url = '/v2/ux/slaves/'
        data = {"groupids":[groupid],"user":{"mail":"autotest@cloudminds.com","password":password,"realname":"autotestname","telephone":"13910392086","username":username,"role":"slave"}}
        result = requests.post(constant.SERVER + url, headers=headers, json=data, timeout=15, verify=False)
        print(result.text)
        if result.status_code == 201:
            return True
        else:
            return False

   #admin,获取添加账号的id
    def test_admin_get_accountid(self,username):
        info = self.test_logininfo_admin()
        authinfo = {"userid":info[0],"authtoken":info[3],"sessionid":info[2],"agentid":info[1],"manualsel":False,"userName":"admin@cloudminds","role":"master","isadmin":True,"masteruserid":1,"lang":"zh-CN"}
        self.auinfo = json.dumps(authinfo)
        headers = {'Connection': 'keep-alive',
         'Content-Type':'application/json',
         'Accept':'application/json, text/plain, */*','authinfo':self.auinfo}
        url = '/v2/ux/slaves/?page=1&pagesize=10&keyword='
        result = requests.get(constant.SERVER +url, headers=headers, timeout=15, verify=False)
        datas = json.loads(result.text)
        #parame = "$..[?(@.username=='{}')].id".format(username)#注意，不能使用username进行检索，因为账号username中含有@.，这两个符号创建时要求必须含有，但在jsonpath却不能含有
        parame = "$..[?(@.realname=='{}')].id".format("autotestname")
        accountid = jsonpath.jsonpath(datas, expr=parame)
        return accountid[0]

    #admin，删除分组信息
    def test_admin_dalete_account(self,accountid):
        info = self.test_logininfo_admin()
        authinfo = {"userid": info[0], "authtoken": info[3], "sessionid": info[2], "agentid": info[1],
                    "manualsel": False, "userName": constant.SV_ADMIN, "role": "master", "isadmin": True,
                    "masteruserid": 1, "lang": "zh-CN"}
        self.auinfo = json.dumps(authinfo)
        headers = {'Connection': 'keep-alive',
                   'Content-Type': 'application/json',
                   'Accept': 'application/json, text/plain, */*', 'authinfo': self.auinfo}
        url = '/v2/ux/slaves/{}'.format(accountid)
        result = requests.delete(constant.SERVER + url, headers=headers, timeout=15, verify=False)
        if result.status_code == 204:
            return True
        else:
            return False

    #账号信息修改
    def user_edit(self, realname, mail,telephone=""):
        url = "/v2/ux/user/info"
        print(telephone)
        data = {"realname":realname,"mail":mail,"telephone":telephone}
        print(self.headers)
        r = requests.patch(constant.SERVER + url, headers=self.headers, json=data, verify=False)
        print(r.text)
        if r.status_code != 204:
            return False
        return True

    #账号详情
    def user_info(self):
        url = "/v2/ux/user/info"
        result = requests.get(constant.SERVER + url, headers=self.headers,  verify=False)
        datas = json.loads(result.text)
        parame = "$.realname"
        realname = jsonpath.jsonpath(datas, expr=parame)
        parame = "$.mail"
        mail = jsonpath.jsonpath(datas, expr=parame)
        parame = "$.telephone"
        telephone = jsonpath.jsonpath(datas, expr=parame)
        if result:
            return realname,mail,telephone
        return False

    #operator登录
    def test_logininfo_AddedOperator(self,Username,Password):
        logger.info("login process")
        headers = {'Connection': 'keep-alive',
         'Content-Type':'application/json',
         'Accept':'application/json, text/plain, */*'}
        url = '/v2/ux/user/login'
        #data ={"username":constant.SV_ADMIN,"password":constant.SV_ADMIN_PWD}
        data = {"username": Username, "password": Password}
        result = requests.post(constant.SERVER +url, headers=headers, json=data, timeout=15, verify=False)
        data = json.loads(result.text)
        #提取信息，用于封装表头
        if "error" not in data:
            userid = jsonpath.jsonpath(data, expr='$.[userid]')
            agentid = jsonpath.jsonpath(data, expr='$.[agentid]')
            sessionid = jsonpath.jsonpath(data, expr='$.[sessionid]')
            authtoken = jsonpath.jsonpath(data, expr='$.[authtoken]')
            return userid[0],agentid[0],sessionid[0],authtoken[0]
        else:
            print("operator login failed!")
            return False
    #修改密码
    def uaer_ChangePassword(self,username,password):
        info = self.test_logininfo_AddedOperator(username,password)
        authinfo = {"userid":info[0],"authtoken":info[3],"sessionid":info[2],"agentid":info[1],"manualsel":False,"userName":"operator@cloudminds.com","role":"master","isadmin":False,"masteruserid":1,"lang":"zh-CN"}
        self.auinfo = json.dumps(authinfo)
        headers = {'Connection': 'keep-alive',
         'Content-Type':'application/json',
         'Accept':'application/json, text/plain, */*','authinfo':self.auinfo}
        url = '/v2/ux/user/password'
        data = {"originalpassword":"Cloudminds123","password":"Cloudminds12356","repassword":"Cloudminds12356"}
        result = requests.put(constant.SERVER +url, headers=headers, json=data, timeout=15, verify=False)
        if result.status_code == 204:
            return "Cloudminds12356"
        else:
            return False


    #退出
    def uaer_logout(self,username,password):
        info = self.test_logininfo_AddedOperator(username,password)
        authinfo = {"userid":info[0],"authtoken":info[3],"sessionid":info[2],"agentid":info[1],"manualsel":False,"userName":"operator@cloudminds.com","role":"master","isadmin":False,"masteruserid":1,"lang":"zh-CN"}
        self.auinfo = json.dumps(authinfo)
        headers = {'Connection': 'keep-alive',
         'Content-Type':'application/json',
         'Accept':'application/json, text/plain, */*','authinfo':self.auinfo}
        url = '/v2/ux/user/logout'
        result = requests.post(constant.SERVER +url, headers=headers, timeout=15, verify=False)
        if result.status_code == 200:
            return True
        else:
            return False