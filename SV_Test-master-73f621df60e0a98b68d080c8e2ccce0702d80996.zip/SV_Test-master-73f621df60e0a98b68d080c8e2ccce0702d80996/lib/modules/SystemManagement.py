# !/usr/bin/env python
# -*- coding: utf-8 -*-
from lib.utils.logger import logger
from lib.utils import constant
from lib.modules.Base import Base
import requests
import time


class SystemManagement(Base):
    """
    使用admin登录,系统管理: 对应需求5.4.1客户账号管理
    用于管理客户管理员账号
    """

    def __init__(self, user, password):
        Base.__init__(self, user, password)
        self.get_sv_authinfo()

    def list_all_customer_admin_account(self, keyword="", page=1, pagesize=10, pattern="$..username"):
        url = "/v2/ux/masters"
        para = {'params': {'page': page, 'pagesize': pagesize, 'keyword': keyword}}
        ret = self.sv_request(url, 'GET', parameter=para, timeout=15, pattern=pattern)
        #print('======', ret)
        return ret

    def add_account(self, username, password="Hello123", confirmpassword="Hello123",
                    mail="auto.customer@cloudminds.com", realname='automation', telephone="13910574432"):
        url = '/v2/ux/masters/'

        payload = {"confirmpassword": confirmpassword, "mail": mail, "password": password,
                   "realname": realname, "telephone": telephone, "username": username}

        r = self.sv_request(url, 'POST', parameter={'json': payload}, timeout=15)
        return r[0]

    def get_account_by_username(self, username):
        """
        通过username获取账号信息
        :param username: 
        :return: 
        {
            "id": 219,
            "username": "monitor@cloudminds.com",
            "telephone": "13522040607",
            "mail": "monitor@cloudminds.com",
            "realname": "monitor",
            "active": 1
        }
        """
        name_list = self.list_all_customer_admin_account(pattern='$..[?(@.username)]')
        for account in name_list[0]:
            if account['username'] == username:
                print('current accoutn is:::', account)
                return account

    def modify_account(self, username, modifies):
        """
        修改账号, username和id是不能修改的, 
        :param username: 
        :param modifies: modifies是个字典: 可以包含: realname, password,confirmpassword,mail,telephone
        :return: 
        """
        account = self.get_account_by_username(username)
        account_id = account['id']
        url = "/v2/ux/masters/{}".format(account_id)
        account.pop('active')

        if 'realname' in modifies.keys():
            account['realname'] = modifies['realname']
        if 'confirmpassword' in modifies.keys():
            account['confirmpassword'] = modifies['confirmpassword']
        else:
            account['confirmpassword'] = ""
        if 'mail' in modifies.keys():
            account['mail'] = modifies['mail']
        if 'password' in modifies.keys():
            account['password'] = modifies['password']
        else:
            account['password'] = ""
        if 'telephone' in modifies.keys():
            account['telephone'] = modifies['telephone']
        print('account:::', account)
        r = requests.patch(constant.SERVER+url, json=account, headers=self.headers, timeout=15)
        return r.status_code, r.content

    def set_account_active_status(self, username, active):
        """
        设置account的状态
        :param active:  1为enable, 0为disable
        :return: 
        """
        account = self.get_account_by_username(username)
        account_id = account['id']
        status = account['active']
        print(status)
        if status == active:
            print('already in {} status'.format(active))
            return True
        url = ''
        if active == 0:
            print('try to disable')
            url = "/v2/ux/masters/{}/disable".format(account_id)
        elif active == 1:
            print('try to enable')
            url = "/v2/ux/masters/{}/enable".format(account_id)
        else:
            print('active should be in 0/1')
            return False
        r = requests.post(constant.SERVER+url, headers=self.headers, timeout=10)
        print(r.status_code, r.content)
        time.sleep(1)
        status = self.get_account_by_username(username)['active']
        print('After status:', status)
        return status

