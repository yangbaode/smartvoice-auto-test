#!/usr/bin/python
# -*- coding: UTF-8 -*-

'''
Created on Jun 10, 2019

@author: chendianmo
'''

# from lib.modules.Base import Base
from lib.modules.Base import Base   
from lib.utils import constant
import time, os
from lib.utils.logger import logger
import requests
import jsonpath,json
from requests_toolbelt import MultipartEncoder
import xlrd,xlwt,xlutils


file_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) + os.sep + 'testdata' + os.sep

class ApplicationQAInterFace(Base):
    def __init__(self, user, password, agent_id=None):
        Base.__init__(self, user, password)
        auth_info = self.get_sv_authinfo(agent_id=agent_id)
        self.agent_id = json.loads(auth_info)['agentid']
        print(self.agent_id)

    def get_agentID_info(self):
        try:
            url = '/v2/ux/agents/?keyword={}&page=1&pagesize=10'.format(self.agent_id)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            # print('response text: ', response.text, '\n')
            content = response.text
            dict_response = json.loads(content)
            print('dict_response: ', dict_response, '\n', type(dict_response))
            data = dict_response['data']
            # print('data: ', data)
            if data:
                agent_value_info = jsonpath.jsonpath(dict_response, expr='$..data[?(@.id=={})]'.format(self.agent_id))
                print('agent_value_info:', agent_value_info, '\n', type(agent_value_info))
                id_value = agent_value_info[0]['id']
                userID_value = agent_value_info[0]['userid']
                agentName_value = agent_value_info[0]['agentname']
                accessToken_value = agent_value_info[0]['accesstoken']
                writeToken_value = agent_value_info[0]['writetoken']
                expaccessToken_value = agent_value_info[0]['expaccesstoken']
                exptimeaccessToken_value = agent_value_info[0]['exptimeaccesstoken']
                exptimewriteToken_value = agent_value_info[0]['exptimewritetoken']
                description = agent_value_info[0]['description']
                print('id_value:', id_value, '\n', 'userID_value:', userID_value, '\n', 'agentName_value:',
                      agentName_value, '\n',
                      'accessToken_value:', accessToken_value, '\n', 'writeToken_value:', writeToken_value, '\n',
                      'expaccessToken_value:', expaccessToken_value, '\n',
                      'exptimeaccessToken_value:', exptimeaccessToken_value, '\n', 'exptimewriteToken_value:',
                      exptimewriteToken_value, '\n', 'description:', description)
                args = [id_value, userID_value, agentName_value, accessToken_value, writeToken_value,
                        expaccessToken_value, exptimeaccessToken_value, exptimewriteToken_value, description]
                return args
            else:
                print('common on ')
        except Exception as e:
            print(e)

    def get_agentID_name_Value(self):
        try:
            agent_info = self.get_agentID_info()
            if agent_info:
                agentName_value = agent_info[2]
                print('找到并且打印 == agentName_value: ', agentName_value)
                return agentName_value
            else:
                print('不存在该agent')
                return False
        except Exception as e:
            print(e)

    def get_agent_PID(self):
        try:
            url = '/v2/ux/agents/{}/qa/types/list'.format(self.agent_id)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            # print('response text: ', response.text, '\n')
            if "The agent don't belongs to this user" in response.text:
                print('不存在该agent id 在这个用户下面', response.text)
                return False
            else:
                dict_response = response.json()
                # print('dict_response:', dict_response, '\n', type(dict_response))
                PID = dict_response[0]['id']
                print('Agent PID: ', PID)
                return PID
        except Exception as e:
            print(e)

    def get_agent_QA_dirName_types(self, dirName_type_value):
        try:
            typeid = self.get_agent_PID()
            url = '/v2/ux/agents/{}/qa/types/getsubtype?typeid={}'.format(self.agent_id, typeid)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            dict_response = response.json()
            for i in range(len(dict_response)):
                name = dict_response[i]['name']
                typeID = dict_response[i]['id']
                print(name, ':', typeID)
                if str(dirName_type_value) == str(name):
                    print('打印该目录类的ID，及目录名称：', name, ':=:', typeID)
                    return typeID
                else:
                    print('继续寻找......  ')
            return False
        except Exception as e:
            print(e)

    def get_all_dirName_PID(self):
        try:
            typeid = self.get_agent_PID()
            url = '/v2/ux/agents/{}/qa/types/getsubtype?typeid={}'.format(self.agent_id, typeid)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            dict_response = response.json()
            all_pid = jsonpath.jsonpath(dict_response,expr='$..id')
            all_dir_name = jsonpath.jsonpath(dict_response, expr='$..name')
            print('所有目录的PID: ',all_pid, ', \n目录名称:', all_dir_name)
            return all_pid
        except Exception as e:
            print(e)
    def add_tag(self, tagName):
        url = '/v2/ux/agents/{}/qa/tag/'.format(self.agent_id)
        data = {"tagname":tagName}
        response = requests.post(constant.SERVER + url, headers=self.headers, json=data, timeout=10, verify=False)

    def delete_teg(self,tagName):
        url = '/v2/ux/agents/{}/qa/tag/{}'.format(self.agent_id,tagName)
        response = requests.delete(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)


    def get_tag_INFO(self):
        try:
            url= '/v2/ux/agents/{}/qa/tag/?page=1&pagesize=10'.format(self.agent_id)
            response = requests.get(constant.SERVER+url, headers=self.headers, timeout=10, verify=False)
            dict_response = response.json()
            return dict_response
        except Exception as e:
            print(e)

    def get_tag_ID(self, tagName):
        try:
            tag_info = self.get_tag_INFO()
            if tag_info:
                tag_id = jsonpath.jsonpath(tag_info, expr='$.data[?(@.tag==\'{}\')].id'.format(tagName))
                print('tag_id: ', tag_id)
                return tag_id[0]
            else:
                print('不存在该标签', tag_info)
                return False
        except Exception as e:
            print(e)

    # 添加标签
    def tag_add(self, tagname="默认标签"):
        url = '/v2/ux/agents/{}/qa/tag/'.format(self.agent_id)
        data = {"tagname": "{}".format(tagname)}
        response = requests.post(constant.SERVER + url, headers=self.headers, json=data, timeout=10, verify=False)
        if response.text == '' and response.status_code == 201:
            print('添加TAG成功，')
            return True
        else:
            print('添加TAG失败，', response.text)
            return False
    def add_qa(self, dirName, question, answer, question1='', answer1='', keywords= '', tag1='', tag2=''):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            print('dirName_value: ', dirName_value)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/'.format(self.agent_id, dirName_value)
            # {"tagids": [], "typeid": 3491, "questions": [{"question": "你今年多大了", "keyword": ["今年多大"]}],
             # "answers": ["我今年30了", "我今年三十了呢"], "emoji": "", "language": "", "groupname": "", "payload": ""}
            data = {"tagids": [],"typeid": dirName_value, "questions": [{"question": question, "keyword": [keywords]}],
                    "answers": [answer], "emoji": "", "language": "", "groupname": "", "payload": ""}
            tag_value = []
            if tag1:
                tag_ID1 = self.get_tag_ID(tag1)
                tag_value = [tag_ID1]
                data['tagids'] = tag_value
                print('data tag:', data['tagids'] )
            if tag2:
                tag_ID2 = self.get_tag_ID(tag2)
                tag_value.append(tag_ID2)
                data['tagids'] = tag_value
                print('data tag:', data['tagids'])
            print('data tag id:', data['tagids'] )
            question_list = [{"question": question}]
            answers_list = [answer]
            if keywords:
                question_list = [{"question": question, "keyword": [keywords]}]
            if question1:
                question_list.append({"question": question1})
                data['questions'] = question_list
            if answer1:
                answers_list.append(answer1)
                data['answers'] = answers_list
            else:
                data['answers'] = [answer]
            print('data: ', data)
            jsons = json.dumps(data)
            print('data: ', jsons)
            response = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, timeout=10, verify=False)
            if response.text == '' and response.status_code == 201:
                print('添加QA成功，')
                return True
            else:
                print('添加失败，', response.text)
                return False
        except Exception as e:
            print(e)

    def add_qa_lots(self, dirName, question, answer, question1, answer1,):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            print('dirName_value: ', dirName_value)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/'.format(self.agent_id, dirName_value)
            data= {"tagids":[],"typeid":dirName_value,"questions":[{"question":question,"keyword":[]},{"question":question1,"keyword":[]}],
                    "answers":[answer,answer1],"emoji":"","language":"","groupname":""}
            print('data: ', data)
            response = requests.post(constant.SERVER + url, headers=self.headers, json=data, timeout=10, verify=False)
            if response.text == '' and response.status_code == 201:
                print('添加QA成功，')
                return True
            else:
                print('添加失败，', response.text)
                return False
        except Exception as e:
            print(e)

    def get_qa_info(self,dirName, question, answer):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            print('dirName_value: ', dirName_value)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/?page=1&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agent_id,
                                                                                                      dirName_value,
                                                                                                      dirName_value)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            dict_response = response.json()
            total_pages = dict_response['pagination']['pagecount']
            total_items = dict_response['pagination']['itemcount']
            print('total_pages: ', total_pages, '\n', 'total_items: ', total_items)
            url1 = ['/v2/ux/agents/{}/qa/{}/qgroup/?page={}&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agent_id,
                                                                                                         dirName_value,
                                                                                                         page,
                                                                                                         dirName_value)
                    for page in range(1, total_pages + 1)]
            for ul in range(len(url1)):
                print(url1[ul])
                response1 = requests.get(constant.SERVER + url1[ul], headers=self.headers, timeout=10, verify=False)
                dict_response1 = response1.json()
                print('=== 开始Python处理JSON数据 ===')
                data1 = dict_response1['data']
                for i in range(len(data1)):
                    question_value = data1[i]['questions'][0]['question']
                    uuid_value = data1[i]['uuid']
                    for a in range(len(data1[i]['answers'])):
                        print(data1[i]['answers'][a])
                        answer_value = data1[i]['answers'][a]['answer']
                        print('问题：', question_value, ', 答案：', answer_value, ', uuid:', uuid_value)
                        if question_value == question and answer_value == answer:
                            print('找到正确答案，', data1[i])
                            print('data[i]: ', data1[i], '\n', type(data1[i]), '\n', len(data1[i]))
                            return data1[i]
                        else:
                            print('没有找到，继续寻找... ... ')
            return False
        except Exception as e:
            print(e)

    def get_all_qa_uuid(self, dirName):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            print('dirName_value: ', dirName_value)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/?page=1&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agent_id,
                                                                                                      dirName_value,
                                                                                                      dirName_value)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            dict_response = response.json()
            total_pages = dict_response['pagination']['pagecount']
            total_items = dict_response['pagination']['itemcount']
            print('total_pages: ', total_pages, '\n', 'total_items: ', total_items)
            url1 = ['/v2/ux/agents/{}/qa/{}/qgroup/?page={}&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agent_id,
                                                                                                         dirName_value,
                                                                                                         page,
                                                                                                         dirName_value)
                    for page in range(1, total_pages + 1)]
            all_uuid = []
            for ul in range(len(url1)):
                print(url1[ul])
                response1 = requests.get(constant.SERVER + url1[ul], headers=self.headers, timeout=10, verify=False)
                dict_response1 = response1.json()
                print('=== 开始Python处理JSON数据 ===')
                data1 = dict_response1['data']
                uuid = jsonpath.jsonpath(data1, expr='$..uuid')
                print(uuid)
                all_uuid.extend(uuid)
            print('all_uuid: ', all_uuid, '\n', len(all_uuid))
            return all_uuid
        except Exception as e:
            print(e)
    def checkin_agentid(self):
        url = '/v2/ux/agents/{}/logs/?page=1&pagesize=10&agentid={}&type=&starttime=&endtime=&traceid=&questionid=&lowestcost=&highestcost='.format(483,483)
        response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
        responsejsons = json.loads(response.text)
        print("agentid info :", responsejsons)
    #查看组是否存在
    def sort_user_group(self):
        # url = '/v2/ux/groups/?page=1&pagesize=10&keyword='
        # response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
        # print("response---",response.text)
        # responsejsons = json.loads(response.text)
        # print("response-json---", responsejsons)
        # itemcount = responsejsons['pagination']['itemcount']
        # print("itemcount---",itemcount)
        # if itemcount != 0:
        #     groupname = jsonpath.jsonpath(responsejsons, expr='$.data[0].group.name')
        #     # if groupname[0] == 'diangroup':
        #     if 'diangroup' in groupname:
        #         print("********")
        #         return True
        #     else:
        #         return False
        # else:
        #     return False
        idlist = []
        url = '/v2/ux/groups/?page=1&pagesize=10&keyword='
        response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
        responsejsons = json.loads(response.text)
        print(responsejsons)
        # Total=responsejsons['pagination']['itemcount']#总记录数
        # TotalPages=responsejsons['pagination']['pagecount']#总页数
        if responsejsons['pagination']['itemcount']:
            TotalPages = responsejsons['pagination']['pagecount']  # 总页数
            USL = constant.SERVER + '/v2/ux/groups/?page='
            urls = [USL + '{}&pagesize=10&keyword='.format(i) for i in range(1, TotalPages + 1)]
            for ur in urls:
                result = requests.get(ur, headers=self.headers, verify=False)
                data = json.loads(result.text)
                ids = jsonpath.jsonpath(data, expr='$.data[*].group.name')
                idlist.extend(ids)
            if constant.GroupUsername in idlist:
                print("********，group exit!!")
                return True
            else:
                return False
        else:
            return  False

    def get_group_id(self,groupname):
        namelist = []
        groupidlist = []
        url = '/v2/ux/groups/?page=1&pagesize=10&keyword='
        response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
        responsejsons = json.loads(response.text)
        Total = responsejsons['pagination']['itemcount']  # 总记录数
        TotalPages = responsejsons['pagination']['pagecount']  # 总页数
        USL = constant.SERVER + '/v2/ux/groups/?page='
        urls = [USL + '{}&pagesize=10&keyword='.format(i) for i in range(1, TotalPages + 1)]
        for ur in urls:
            result = requests.get(ur, headers=self.headers, verify=False)
            data = json.loads(result.text)
            names = jsonpath.jsonpath(data, expr='$.data[*].group.name')
            namelist.extend(names)
            idss = jsonpath.jsonpath(data, expr='$.data[*].group.id')
            groupidlist.extend(idss)
        return groupidlist[namelist.index(groupname)]


    def add_user_group(self):
        info = self.sort_user_group()
        print("in---:",info)
        if info :
            groupid = self.get_group_id(constant.GroupUsername)
            self.group_bangdingUser(groupid)
            print("绑定成功！！")
        else:
            groupId = self.group_add_bangding()
            result = self.group_bangdingUser(groupId)
            if result:
                return True
            else:
                return False
    #添加组
    def group_add_bangding(self):
        url = '/v2/ux/groups/'
        data = {"agentid":constant.agent_id,"group":{"info":"diandian","name":constant.GroupUsername},"authority":{"customdomain":True,"domainmanage":True,"qatype":True,"qamark":True,"faqmanage":True,"faq":False,"chitchat":False,"train":True}}
        jsons = json.dumps(data)
        response = requests.post(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        if response.status_code != 201:
            print("fail-----:",response.text)
        else:
            url = '/v2/ux/groups/?page=1&pagesize=10&keyword='
            response = requests.get(constant.SERVER + url, headers=self.headers, verify=False)
            responsejsons = json.loads(response.text)
            print("rrr",responsejsons)
            groupid = jsonpath.jsonpath(responsejsons, expr='$.data[0].group.id')
            print("groupid---:",groupid)
            return groupid[0]
    #绑定组
    def group_bangdingUser(self,groupId):
        null = ''
        url = '/v2/ux/slaves/{}'.format(constant.GroupUsernameID) #272为"dian@cloudminds.com"的ID号
        data = {"groupids":[groupId],"user":{"id":constant.GroupUsernameID,"mail":constant.GroupUsername,"password":"","realname":"dian","username":null}}
        jsons = json.dumps(data)
        response = requests.patch(constant.SERVER + url, headers=self.headers, data=jsons, verify=False)
        if response.status_code != 204:
            print("Bangding fail-----:",response.text)
            return False
        else:
            return True

    def del_all_qa(self, dirName):
        try:
            all_uuid = self.get_all_qa_uuid(dirName)
            if all_uuid:
                dirName_value = self.get_agent_QA_dirName_types(dirName)
                url = ['/v2/ux/agents/{}/qa/{}/qgroup/{}'.format(self.agent_id, dirName_value, all_uuid[i]) for i in range(len(all_uuid))]
                for ul in range(len(url)):
                    print(url[ul])
                    response = requests.delete(constant.SERVER + url[ul], headers=self.headers, timeout=10, verify=False)
                    time.sleep(1)
                    if response.text == '' and response.status_code == 204:
                        print('删除QA成功，')
                    else:
                        print('删除失败，')
                        return False
            else:
                print('不存在QA问答对: ', all_uuid)
            return True
        except Exception as e:
            print(e)

    def get_qa_uuid(self,dirName, question, answer):
        try:
            qa_info = self.get_qa_info(dirName, question, answer)
            if qa_info:
                print('qa_info:', qa_info)
                uuid = qa_info['uuid']
                print('打印uuid： ', uuid)
                return uuid
            else:
                print('没有找到这个QA，', qa_info)
                return False
        except Exception as e:
            print(e)

    def get_qa_groupId(self,dirName, question, answer):
        try:
            qa_info = self.get_qa_info(dirName, question, answer)
            if qa_info:
                print('qa_info:', qa_info)
                group_id = qa_info['groupid']
                print('打印 groupid： ', group_id)
                return group_id
            else:
                print('没有找到这个QA，', qa_info)
                return False
        except Exception as e:
            print(e)

    def get_qa_keywords(self,dirName, question, answer):
        try:
            qa_info = self.get_qa_info(dirName, question, answer)
            if qa_info:
                print('qa_info:', qa_info)
                keywords = qa_info['keywords'][0][0]
                if keywords:
                    print('打印 keywords： ', keywords)
                    return keywords
                else:
                    print('这个QA没有关键字，', qa_info)
                    return False
            else:
                print('没有找到这个QA，', qa_info)
                return False
        except Exception as e:
            print(e)

    def del_qa(self,dirName, question, answer):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            print('dirName_value: ', dirName_value)
            qa_uid = self.get_qa_uuid(dirName, question, answer)
            print('qa_uid: ', qa_uid)
            if qa_uid:
                url = '/v2/ux/agents/{}/qa/{}/qgroup/{}'.format(self.agent_id, dirName_value, qa_uid)
                print('url: ', url)
                response = requests.delete(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
                if response.text == '' and response.status_code == 204:
                    print('删除QA成功，')
                    return True
                else:
                    print('删除失败，', response.text)
                    return False
            else:
                print('已经不存在该QA了，', qa_uid)
                return False
        except Exception as e:
            print(e)

    def del_qa_batch(self, dirName, q1,a1, q2='',a2='',q3='',a3='',q4='',a4=''):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/delete/batch'.format(self.agent_id, dirName_value)
            qa_uid = self.get_qa_uuid(dirName, q1, a1)
            data = {"qgroupids":[],"typeid":dirName_value}
            group_id = [qa_uid]
            if q2:
                qa_uid2 = self.get_qa_uuid(dirName, q2, a2)
                group_id.append(qa_uid2)
            if q3:
                qa_uid3 = self.get_qa_uuid(dirName, q3, a3)
                group_id.append(qa_uid3)
            if q4:
                qa_uid4 = self.get_qa_uuid(dirName, q4, a4)
                group_id.append(qa_uid4)
            data["qgroupids"] = group_id
            data["typeid"] = dirName_value
            print('data: ', data, '\n', type(data))
            response = requests.patch(constant.SERVER + url, headers=self.headers, json=data, timeout=10, verify=False)
            if response.status_code ==204:
                print('批量删除成功')
                return True
            else:
                print('删除失败，：',response.text)
                return False
        except Exception as e:
            print(e)

    def send_qa(self, question, answer):
        '''
        返回 question， answer 与及 source_value
        '''
        try:
            url = '/v2/ux/agents/{}/smartqa/query?question={}&hariVersion=v3'.format(self.agent_id, question)
            print('url: ', url)
            if url:
                response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
                print('response text: ', response.text)
                dict_response = response.json()
                a = dict_response['answer']
                print('a: ', a, '\n', type(a))
                b = json.loads(a)
                question_text = b['asr']['text']
                print('question_text:', question_text)
                answer_text = b['tts'][0]['text']
                source_value = b['source']
                print('source_value:', source_value)
                print('answer_text:', answer_text)
                print('answer numbers:', len(b['tts']))
                return question_text, answer_text, source_value
        except Exception as e:
            print(e)

    def edit_qa(self, dirName, question, answer, new_question, new_answer):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/'.format(self.agent_id, dirName_value)
            print('url: ', url)
            qa_uid = self.get_qa_uuid(dirName, question, answer)
            data = {"qgroupid": qa_uid,
                    "questions": [{"question": new_question}],
                    "answers": [new_answer]}
            print('data:', data, '\n', type(data))
            response = requests.patch(constant.SERVER + url, headers=self.headers, data=json.dumps(data), timeout=10, verify=False)
            if response.text == '' and response.status_code == 204:
                print('修改QA成功，')
                return True
            else:
                print('修改失败', response.text)
                return False
        except Exception as e:
            print(e)

    def edit_qa_lots(self, dirName, question, answer, new_question1, new_answer1, new_question2='', new_answer2= '', keywords= ''):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/'.format(self.agent_id, dirName_value)
            print('url: ', url)
            qa_uid = self.get_qa_uuid(dirName, question, answer)
            data = {"qgroupid":qa_uid,"questions":[{"question":new_question1}],
                    "answers":[new_answer1]}
            question_list = [{"question":new_question1}]
            answers_list = [new_answer1]
            if keywords:
                question_list = [{"question": question, "keyword": [keywords]}]
                data['questions'] = question_list
                print('keywords, 存在, question_list: ', question_list)
            if new_question2:
                question_list.append({"question":new_question2})
                data['questions'] = question_list
            if new_answer2:
                answers_list.append(new_answer2)
                data['answers'] = answers_list
            print('data:', data, '\n', type(data))
            response = requests.patch(constant.SERVER + url, headers=self.headers, data=json.dumps(data), timeout=10, verify=False)
            if response.text == '' and response.status_code == 204:
                print('修改QA成功，')
                return True
            else:
                print('修改失败', response.text)
                return False
        except Exception as e:
            print(e)

    def get_all_search_qa_dirName(self, dirName, keywords):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            url = '/v2/ux/agents/{}/qa/types/qgroup/search?keyword={}&typeid={}&page=1&pagesize=10&tagid=&audit=1'.format(
                self.agent_id, keywords, dirName_value)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            dict_response = response.json()
            question_all = jsonpath.jsonpath(dict_response, expr='$..data..question')
            answer_all = jsonpath.jsonpath(dict_response, expr='$..data..answer')
            print('question_all: ', question_all, '\n', 'answer_all: ', answer_all)
            zipped = zip(question_all, answer_all)
            a = list(zipped)
            print('返回一个问答对list: ',a)
            return a
        except Exception as e:
            print(e)

    def get_all_search_qa_python_dirName(self, dirName, keywords):
        ##后续在写
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            url = '/v2/ux/agents/{}/qa/types/qgroup/search?keyword={}&typeid={}&page=1&pagesize=10&tagid=&audit=1'.format(
                self.agent_id, keywords, dirName_value)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            dict_response = response.json()
            page_count = dict_response['pagination']['pagecount']
            print('page_count: ', page_count)
            url1 = ['/v2/ux/agents/{}/qa/types/qgroup/search?keyword={}&typeid={}&page=1&pagesize=10&tagid=&audit=1'.format(self.agent_id,keywords,dirName_value,page) for page in range(1, page_count + 1)]
            print('url1, :', url1)
            for ur in range(len(url1)):
                print('ur: ', url1[ur])
                response1 = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
                dict_response1 = response1.json()
                data = dict_response1['data']
                print('data:', data, '\n', type(data), len((data)))
                question_list = []
                answer_list = []
                for i in range(len(data)):
                    c = []
                    d = []
                    print('hello', data[i], '\n', len(data[i]['questions']))
                    for qu in range(len(data[i]['questions'])):
                        print(data[i]['questions'][qu]['question'])
                        c.append(data[i]['questions'][qu]['question'])
                    for an in range(len(data[i]['answers'])):
                        print(data[i]['answers'][an]['answer'])
                        d.append(data[i]['answers'][an]['answer'])
                    question_list.append(c)
                    answer_list.append(d)
                print(question_list, '\n', answer_list)
        except Exception as e:
            print(e)

    def verify_search_Q_inList(self, dirName, keywords):
        try:
            search_qa_list = self.get_all_search_qa_dirName(dirName, keywords)
            for i in range(len(search_qa_list)):
                b = search_qa_list[i][0]
                c = search_qa_list[i][1]
                print('b,c: ', b, c)
                if keywords in b or keywords in c:
                    print('%s 在搜索的关键字里面: || ' % keywords, b, '||==||', c)
                else:
                    print('搜索的关键字都不在QA里面，返回失败: ', b, c)
                    return False
            return True
        except Exception as e:
            print(e)

    def verify_search_QA_inList(self, dirName, keywords, question, answer):
        ##后续在写
        try:
            search_qa_list = self.get_all_search_qa_python_dirName(dirName, keywords)
            for i in range(len(search_qa_list)):
                b = search_qa_list[i][0]
                c = search_qa_list[i][1]
                print('b,c: ', b, '||',c)
                if b == question and c == answer:
                    print('找到正确的问答对，', b ,c)
                    return True
                else:
                    print('继续寻找......')
            return False
        except Exception as e:
            print(e)

    def qa_move(self, dirName, dirName2, q1, a1, q2='',a2='',q3='',a3=''):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            dirName2_value = self.get_agent_QA_dirName_types(dirName2)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/move/batch'.format(self.agent_id, dirName_value)
            qa_pid = self.get_qa_uuid(dirName, q1, a1)
            print('qa_pid:',type(qa_pid))
            data = {"qgroupids":[],"typeid":dirName2_value}
            all_id = [qa_pid]
            if q2:
                qa_pid2 = self.get_qa_uuid(dirName, q2, a2)
                all_id.append(qa_pid2)
                if q3:
                    qa_pid3 = self.get_qa_uuid(dirName, q3, a3)
                    all_id.append(qa_pid3)
            data['qgroupids'] = all_id
            print('data: ', data, '\n',type(data))
            time.sleep(2)
            response = requests.patch(constant.SERVER + url, headers=self.headers, json=data, timeout=10, verify=False)
            if response.text == '' and response.status_code==204:
                print('批量移动成功，')
                return True
            else:
                print('批量移动失败', response.text)
                return False
        except Exception as e:
            print(e)

    def qa_move_one(self, dirName, dirName2, q1, a1):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            dirName2_value = self.get_agent_QA_dirName_types(dirName2)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/move'.format(self.agent_id, dirName_value)
            qa_pid = self.get_qa_uuid(dirName, q1, a1)
            data = {"qgroupid": qa_pid, "typeid": dirName2_value}
            print('data: ', data, '\n',type(data))
            time.sleep(2)
            response = requests.patch(constant.SERVER + url, headers=self.headers, json=data, timeout=10, verify=False)
            if response.text == '' and response.status_code==204:
                print('移动成功，')
                return True
            else:
                print('移动失败', response.text)
                return False
        except Exception as e:
            print(e)

    def answer_move_one(self, dirName, dirName2, answer):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            dirName2_value = self.get_agent_QA_dirName_types(dirName2)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/move'.format(self.agent_id, dirName_value)
            qa_pid = self.get_welcome_repeat_default_words_uuid(dirName, answer)
            data = {"qgroupid": qa_pid, "typeid": dirName2_value}
            print('data: ', data, '\n',type(data))
            time.sleep(2)
            response = requests.patch(constant.SERVER + url, headers=self.headers, json=data, timeout=10, verify=False)
            if response.text == '' and response.status_code==204:
                print('移动成功，')
                return True
            else:
                print('移动失败', response.text)
                return False
        except Exception as e:
            print(e)

    def qa_move_one_NoPATG(self, dirName, dirName2, q1, a1):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            dirName2_value = self.get_agent_QA_dirName_types(dirName2)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/move'.format(self.agent_id, dirName_value)
            qa_pid = self.get_qa_uuid(dirName, q1, a1)
            data = {"qgroupid": qa_pid, "typeid": None}
            print('data: ', data, '\n',type(data))
            time.sleep(2)
            response = requests.patch(constant.SERVER + url, headers=self.headers, json=data, timeout=10, verify=False)
            if response.text == '' and response.status_code==204:
                print('移动成功，')
                return True
            else:
                print('移动失败', response.text)
                return False
        except Exception as e:
            print(e)

    def get_tag_search_qa_INFO(self, dirName, tagName):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            tag_id = self.get_tag_ID(tagName)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/?page=1&pagesize=10&typeid={}&tagid={}&audit=1'.format(self.agent_id, dirName_value, dirName_value
                                                                                                          , tag_id)
            print('url: ', url)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            dict_response = response.json()
            return dict_response
        except Exception as e:
            print(e)

    def get_tag_qa_verify_tag(self, dirName, tagName):
        try:
            dict_response = self.get_tag_search_qa_INFO(dirName, tagName)
            tag_info = jsonpath.jsonpath(dict_response,expr='$.data[*].tags')
            print('tag_info: ', tag_info, '\n', type(tag_info), '==长度个数： ',len(tag_info))
            for i in range(len(tag_info)):
                print(tag_info[i])
                tag_name_temp = []
                for h in range(len(tag_info[i])):
                    tag_Name = tag_info[i][h]['tag']
                    print('tag_Name: ', tag_Name)
                    tag_name_temp.append(tag_Name)
                print('tag_name_temp: ', tag_name_temp)
                if tagName in tag_name_temp:
                    print('所有的QA均带有带标签，', tag_name_temp)
                else:
                    print('存在QA不带有该标签', tag_name_temp)
                    return False
            return True
        except Exception as e:
            print(e)

    def get_all_qa_info(self, dirName):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            print('dirName_value: ', dirName_value)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/?page=1&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agent_id,dirName_value,dirName_value)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            dict_response = response.json()
            a = dict_response['pagination']
            print('a: ', a, type(a))
            if ('pagecount' in a.keys()):
                total_pages = dict_response['pagination']['pagecount']
                total_items = dict_response['pagination']['itemcount']
                print('total_pages: ', total_pages, '\n', 'total_items: ', total_items)
                url1 = ['/v2/ux/agents/{}/qa/{}/qgroup/?page={}&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agent_id,dirName_value,page,dirName_value)
                        for page in range(1, total_pages + 1)]
                print('url: ', url1)
                all_response = []
                for ul in range(len(url1)):
                    print('url list: ',url1[ul])
                    response1 = requests.get(constant.SERVER + url1[ul], headers=self.headers, timeout=10, verify=False)
                    dict_response1 = response1.json()
                    print('=== 加入到列表 ===')
                    all_response.append(dict_response1)
                print('all_response 长度: ', type(all_response), '||', len(all_response))
                return all_response
            else:
                print('该 %s 目录不存在问答对' % dirName)
                return False
        except Exception as e:
            print(e)

    def get_all_question_answer_dirName(self, dirName):
        try:
            all_qa_info = self.get_all_qa_info(dirName)
            if all_qa_info:
                print('all_qa_info: ', all_qa_info, '\n', 'all_qa_info_len:', len(all_qa_info), ',||, type: ', type(all_qa_info))
                all_questions = []
                all_answers = []
                for i in range(len(all_qa_info)):
                    data = all_qa_info[i]['data']
                    print('data:', data, '\n', 'data len:', len(data), type(data))
                    for a in range(len(data)):
                        questions = jsonpath.jsonpath(data, expr='$.[{}].questions..question'.format(a))
                        tuple_questions = tuple(questions)
                        print('questions: ', tuple_questions)
                        all_questions.append(tuple_questions)
                    for b in range(len(data)):
                        answers = jsonpath.jsonpath(data, expr='$.[{}].answers..answer'.format(b))
                        tuple_answers = tuple(answers)
                        print('answers: ', tuple_answers)
                        all_answers.append(tuple_answers)
                print(all_questions, '\n','问题个数： ', len(all_questions), '\n',all_answers, '\n', '答案个数： ', len(all_answers))
                return all_questions, all_answers
            else:
                print('该目录不存在问答对')
                return False
        except Exception as e:
            print(e)

    def verify_qa_display_UI(self, dirName, question, answer):
        try:
            all_qa = self.get_all_question_answer_dirName(dirName)
            if all_qa:
                for i in range(len(all_qa[0])):
                    if question in all_qa[0][i]:
                        print('找到问题，继续找答案', all_qa[0][i], i)
                        answer_value = all_qa[1][i]
                        if answer in answer_value:
                            print('找到正确答案，', all_qa[1][i])
                            return True
                    else:
                        print('继续寻找......')
                return False
            else:
                print('该目录不存在问答对')
                return False
        except Exception as e:
            print(e)

    def get_all_qa_tag(self, dirName):
        #需要解决 一个QA多个TAG的 个数问题，后续函数解决，其他函数已经解决，函数目的不一样.
        try:
            all_qa_info = self.get_all_qa_info(dirName)
            if all_qa_info:
                all_tag = jsonpath.jsonpath(all_qa_info, expr='$.[*].tags.[*].tag')
                all_qa_numbers = len(jsonpath.jsonpath(all_qa_info, expr='$..groupid'))
                print('all_tag: ', all_tag, '\n','all_qa_numbers: ', all_qa_numbers)
                return all_tag, all_qa_numbers
            else:
                print('其他错误：', all_qa_info)
                return False
        except Exception as e:
            print(e)

    def switch_page_qa_numbers(self, dirName, Pagesize):
        try:
            dirName_id = self.get_agent_QA_dirName_types(dirName)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/?page=1&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agent_id, dirName_id, dirName_id)
            print('url: ', url)
            response = requests.get(constant.SERVER+url, headers=self.headers, timeout=10, verify=False)
            dict_response = response.json()
            page_count = dict_response['pagination']['pagecount']
            item_count = dict_response['pagination']['itemcount']
            page_size = dict_response['pagination']['pagesize']
            print('total page count: ', page_count, '\n', 'total QA count: ', item_count, '\n', 'Everyone page display: ', page_size)
            if Pagesize == 20:
                if page_count <2:
                    url20 = '/v2/ux/agents/{}/qa/{}/qgroup/?page=1&pagesize=20&typeid={}&tagid=&audit=1'.format(
                        self.agent_id, dirName_id, dirName_id)
                    response20 = requests.get(constant.SERVER + url20, headers=self.headers, timeout=10, verify=False)
                    dict_response20 = response20.json()
                    page_count20 = dict_response20['pagination']['pagecount']
                    item_count20 = dict_response20['pagination']['itemcount']
                    if page_count20 == page_count and item_count20 == item_count:
                        print('正确，')
                        return True
                    else:
                        return False
                if page_count >=2:
                    print('page count >=2')
                    url20 = '/v2/ux/agents/{}/qa/{}/qgroup/?page=1&pagesize=20&typeid={}&tagid=&audit=1'.format(
                        self.agent_id, dirName_id, dirName_id)
                    print('url: ', url20)
                    response20 = requests.get(constant.SERVER + url20, headers=self.headers, timeout=10, verify=False)
                    dict_response20 = response20.json()
                    page_count20 = dict_response20['pagination']['pagecount']
                    item_count20 = dict_response20['pagination']['itemcount']
                    page_size20 = dict_response20['pagination']['pagesize']
                    print('info')
                    print(page_count20, item_count20, page_size20)
                    a = item_count // 20
                    print(a)
                    real_page_count = a+1
                    print('real_item_count, item_count20: ',real_page_count, item_count20)
                    if real_page_count == page_count20 and page_size20 == Pagesize and  item_count==item_count20 :
                        print('正确')
                        return True
                    else:
                        return False
            if Pagesize == 30:
                if page_count <2:
                    url20 = '/v2/ux/agents/{}/qa/{}/qgroup/?page=1&pagesize=20&typeid={}&tagid=&audit=1'.format(
                        self.agent_id, dirName_id, dirName_id)
                    print('url: ', url)
                    response20 = requests.get(constant.SERVER + url20, headers=self.headers, timeout=10, verify=False)
                    dict_response20 = response20.json()
                    page_count20 = dict_response20['pagination']['pagecount']
                    item_count20 = dict_response20['pagination']['itemcount']
                    if page_count20 == page_count and item_count20 == item_count:
                        print('正确，')
                        return True
                    else:
                        return False
                if page_count >=2:
                    print('page count >=2')
                    url30 = '/v2/ux/agents/{}/qa/{}/qgroup/?page=1&pagesize=30&typeid={}&tagid=&audit=1'.format(
                        self.agent_id, dirName_id, dirName_id)
                    print('url: ', url30)
                    response30 = requests.get(constant.SERVER + url30, headers=self.headers, timeout=10, verify=False)
                    dict_response30 = response30.json()
                    page_count30 = dict_response30['pagination']['pagecount']
                    item_count30 = dict_response30['pagination']['itemcount']
                    page_size30 = dict_response30['pagination']['pagesize']
                    print('info')
                    print(page_count30, item_count30, page_size30)
                    a = item_count // 30
                    print(a)
                    real_page_count = a+1
                    print('real_item_count, item_count20: ',real_page_count, item_count30)
                    if real_page_count == page_count30 and page_size30 == Pagesize and  item_count==item_count30 :
                        print('正确')
                        return True
                    else:
                        return False
            return False
        except Exception as e:
            print(e)

    def add_welcome_repeat_default_words(self, dirName, answer, answer1='',tag1='',tag2='', payload=''):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            print('dirName_value: ', dirName_value)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/'.format(self.agent_id, dirName_value)
            data = {"tagids":[],"typeid":dirName_value,"answers":[answer],"questions":[],"emoji":"😉",
                    "language":"","groupname":"","payload":payload}
            if answer1:
                data['answers'] = [answer, answer1]
            tag = []
            if tag1:
                tag_ID1 = self.get_tag_ID(tag1)
                tag.append(tag_ID1)
            if tag2:
                tag_ID2 = self.get_tag_ID(tag2)
                tag.append(tag_ID2)
            data['tagids'] = tag
            if payload:
                data['payload'] = payload
            print('data: ', data)
            response = requests.post(constant.SERVER + url, headers=self.headers, json=data, timeout=10, verify=False)
            if response.text == '' and response.status_code ==201:
                print('新增 %s 回答， 成功，' % dirName, response.text)
                return True
            else:
                print('增加失败', response.text)
                return False
        except Exception as e:
            print(e)

    def get_welcome_repeat_default_words_uuid(self, dirName, answer):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            print('dirName_value: ', dirName_value)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/?page=1&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agent_id,
                                                                                                      dirName_value,
                                                                                                      dirName_value)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            dict_response = response.json()
            total_pages = dict_response['pagination']['pagecount']
            total_items = dict_response['pagination']['itemcount']
            print('total_pages: ', total_pages, '\n', 'total_items: ', total_items)
            url1 = ['/v2/ux/agents/{}/qa/{}/qgroup/?page={}&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agent_id,
                                                                                                         dirName_value,
                                                                                                         page,
                                                                                                         dirName_value)
                    for page in range(1, total_pages + 1)]
            print('url: ', url1)
            for ul in range(len(url1)):
                print(url1[ul])
                response1 = requests.get(constant.SERVER + url1[ul], headers=self.headers, timeout=10, verify=False)
                dict_response1 = response1.json()
                print('=== 开始Python处理JSON数据 ===')
                data1 = dict_response1['data']
                print('data1: ', data1, '\n', type(data1), len(data1))
                for i in range(len(data1)):
                    print(data1[i])
                    answer_value = data1[i]['answers'][0]['answer']
                    uuid = data1[i]['uuid']
                    if answer == answer_value:
                        print('找到 %s, ' % dirName , answer_value, '\n', uuid)
                        return uuid
                    else:
                        print('继续寻找...')
                return False
            return False
        except Exception as e:
            print(e)

    def edit_welcome_repeat_default_words(self, dirName, old_answer, answer, answer1='',tag1='',tag2='', payload=''):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            print('dirName_value: ', dirName_value)
            uid = self.get_welcome_repeat_default_words_uuid(dirName, old_answer)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/'.format(self.agent_id, dirName_value)
            data = {"qgroupid":uid, "tagids":[],"typeid":dirName_value,"answers":[answer],"questions":[],"emoji":"😉",
                    "language":"","groupname":"","payload":payload}
            if answer1:
                data['answers'] = [answer, answer1]
            tag = []
            if tag1:
                tag_ID1 = self.get_tag_ID(tag1)
                tag.append(tag_ID1)
            if tag2:
                tag_ID2 = self.get_tag_ID(tag2)
                tag.append(tag_ID2)
            data['tagids'] = tag
            if payload:
                data['payload'] = payload
            print('data: ', data)
            response = requests.patch(constant.SERVER + url, headers=self.headers, json=data, timeout=10, verify=False)
            if response.text == '' and response.status_code ==204:
                print('编辑 %s 成功，' % dirName, response.text)
                return True
            else:
                print('编辑失败', response.text)
                return False
        except Exception as e:
            print(e)

    def del_welcome_repeat_default_words(self, dirName, answer):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            print('dirName_value: ', dirName_value)
            uid = self.get_welcome_repeat_default_words_uuid(dirName, answer)
            if uid:
                url = '/v2/ux/agents/{}/qa/{}/qgroup/{}'.format(self.agent_id,dirName_value,uid)
                response = requests.delete(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
                if response.text == '' and response.status_code ==204:
                    print('删除成功，', response.text)
                    return True
                else:
                    print('删除失败', response.text)
                    return False
            else:
                print('不存在该 %s' % dirName, uid)
                return False
        except Exception as e:
            print(e)

    def get_all_welcome_repeat_default_words_info(self, dirName):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            print('dirName_value: ', dirName_value)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/?page=1&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agent_id, dirName_value, dirName_value)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            dict_response = response.json()
            a = dict_response['pagination']
            print('a: ', a, type(a))
            if ('pagecount' in a.keys()):
                total_pages = dict_response['pagination']['pagecount']
                total_items = dict_response['pagination']['itemcount']
                print('total_pages: ', total_pages, '\n', 'total_items: ', total_items)
                url1 = ['/v2/ux/agents/{}/qa/{}/qgroup/?page={}&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agent_id,
                                                                                                             dirName_value,
                                                                                                             page,
                                                                                                             dirName_value)
                        for page in range(1, total_pages + 1)]
                print('url: ', url1)
                all_answer = []
                all_id = []
                for ul in range(len(url1)):
                    print(url1[ul])
                    response1 = requests.get(constant.SERVER + url1[ul], headers=self.headers, timeout=10, verify=False)
                    dict_response1 = response1.json()
                    data = dict_response1['data']
                    print('data: ', data, '\n', 'data 长度： ',len(data))
                    for i in range(len(data)):
                        answers = jsonpath.jsonpath(data, expr='$.[{}].answers..answer'.format(i))
                        print(answers)
                        all_answer.append(answers)
                    id = jsonpath.jsonpath(data,expr='$..uuid')
                    all_id.extend(id)
                print('所有 %s UUID: ' % dirName , all_id, '\n', '所有 %s 答案：' % dirName ,all_answer)
                return all_id, all_answer
            else:
                print('不存在 %s 答案' % dirName)
                return False
        except Exception as e:
            print(e)

    def verify_answer_exist(self, dirName, answer):
        #验证 welcome, default, 重复提问，开机语， 迎宾语等
        try:
            answer_info = self.get_all_welcome_repeat_default_words_info(dirName)
            if answer_info:
                for i in range(len(answer_info[1])):
                    if answer in answer_info[1][i]:
                        print('存在答案在 %s 目录：' % dirName, '|| 寻到答案：',answer_info[1][i])
                        return True
                    else:
                        print('继续寻找.....')
                print('不存在该答案在 %s 目录' % dirName)
                return False
            else:
                print('已经在该 %s 目录下不存在答案 ' %dirName)
                return False
        except Exception as e:
            print(e)

    def del_all_welcome_repeat_default_words(self, dirName):
        try:
            all_id, all_answer = self.get_all_welcome_repeat_default_words_info(dirName)
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            print('dirName_value: ', dirName_value)
            for i in all_id:
                print(i)
                url = '/v2/ux/agents/{}/qa/{}/qgroup/{}'.format(self.agent_id, dirName_value, i)
                print(url)
                response = requests.delete(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
                if response.text == '' and response.status_code == 204:
                    print('删除成功，')
                else:
                    print('删除失败', response.text)
                    return False
            return True
        except Exception as e:
            print(e)

    def upload_file(self, dirName, fileName):
        try:
            file_value = os.path.join(file_path, fileName)
            print('picture_value: ', file_value)
            file = os.path.exists(file_value)
            print('file: ', file)
            if file:
                dirName_value = self.get_agent_QA_dirName_types(dirName)
                url = '/v2/ux/agents/{}/qa/types/{}/import/'.format(self.agent_id, dirName_value)
                headers = self.headers
                file_payload = {'file': (fileName, open(file_value, 'rb'))}
                print('file_payload: ', file_payload)
                m = MultipartEncoder(file_payload)
                headers['Content-Type'] = m.content_type
                print("headers----:",headers)
                print("m----:", m)
                response = requests.post(constant.SERVER + url, headers=headers, data=m, verify=False)
                print('response text: ', response.text, '\n', response.status_code)
                if response.text == '' and response.status_code == 204:
                    print('上传成功，')
                    return True
                else:
                    print('导入失败', response.text)
                    return False
        except Exception as e:
            print(e)

    def get_all_dirName_info(self):
        try:
            agent_pid = self.get_agent_PID()
            url = '/v2/ux/agents/{}/qa/types/getsubtype?typeid={}'.format(self.agent_id, agent_pid)
            response = requests.get(constant.SERVER + url, headers=self.headers, verify=False)
            dict_response = response.json()
            return dict_response
        except Exception as e:
            print(e)

    def get_agent_all_dirName_name(self):
        try:
            agent_dirName_info = self.get_all_dirName_info()
            if agent_dirName_info:
                all_name = jsonpath.jsonpath(agent_dirName_info, expr='$..name')
                print('all name: ', all_name)
                return all_name
            else:
                print('不存在目录', agent_dirName_info)
                return False
        except Exception as e:
            print(e)

    def verify_dirName_exist(self, dirName):
        try:
            all_dirName = self.get_agent_all_dirName_name()
            if dirName in all_dirName:
                print('存在该目录 %s' % dirName, ',||,所有目录名单： ',all_dirName)
                return True
            else:
                print('不存在该目录 %s' % dirName, ',||,所有目录名单： ',all_dirName)
                return False
        except Exception as e:
            print(e)

    def add_dirName(self, dirName):
        try:
            agent_pid = self.get_agent_PID()
            exist_dirName = self.get_agent_all_dirName_name()
            if dirName in exist_dirName:
                print('已经存在该目录， 请重新输入')
                return False
            else:
                url='/v2/ux/agents/{}/qa/types/'.format(self.agent_id)
                data = {"typename":dirName,"parentid":agent_pid}
                response = requests.post(constant.SERVER + url, headers=self.headers, json=data, verify=False)
                print('response text: ', response.text, '\n', response.status_code)
                if response.status_code == 201:
                    print('新增目录成功：', response.status_code)
                    return True
                else:
                    print('新增目录失败', response.text)
                    return False
        except Exception as e:
            print(e)

    def del_dir_name(self, dirName):
        try:
            dirName_ID = self.get_agent_QA_dirName_types(dirName)
            if dirName_ID:
                url = '/v2/ux/agents/{}/qa/types/{}'.format(self.agent_id,dirName_ID)
                response = requests.delete(constant.SERVER+url, headers=self.headers, verify=False)
                if response.status_code == 204:
                    print('删除目录成功：', response.status_code)
                    return True
            else:
                print('不存在该目录：', dirName_ID)
                return False
        except Exception as e:
            print(e)

    def del_all_dirName(self):
        try:
            all_dirName_id = self.get_all_dirName_PID()
            if all_dirName_id:
                for i in range(len(all_dirName_id)):
                    url = '/v2/ux/agents/{}/qa/types/{}'.format(self.agent_id,all_dirName_id[i])
                    print(url, '\n', i)
                    if i > 3:
                        response = requests.delete(constant.SERVER+url, headers=self.headers, verify=False)
                        print('response text: ', response.text, '\n', response.status_code)
                        if response.status_code == 204:
                            print('删除目录成功：', response.status_code)
                        else:
                            print('删除失败', response.text)
                            return False
                    else:
                        print('前面4个为默认，不允许删除: ',i)
                return True
            else:
                print('不存在该目录：', all_dirName_id)
                return False
        except Exception as e:
            print(e)

    def edit_dir_name(self, dirName, new_Name):
        try:
            dirName_ID = self.get_agent_QA_dirName_types(dirName)
            if dirName_ID:
                url = '/v2/ux/agents/{}/qa/types/rename'.format(self.agent_id)
                data = {"typename":new_Name,"typeid":dirName_ID}
                response = requests.patch(constant.SERVER+url, headers=self.headers, json=data, verify=False)
                if response.status_code == 204:
                    print('编辑成功：')
                    return True
                else:
                    print('编辑失败：', response.text)
                    return False
            else:
                print('不存在该目录：', dirName_ID)
                return False
        except Exception as e:
            print(e)

    def add_child_next_dir_name(self, dirName, next_Name):
        try:
            dirName_ID = self.get_agent_QA_dirName_types(dirName)
            print('dirName_ID: ',dirName_ID)
            if dirName_ID:
                url = '/v2/ux/agents/{}/qa/types/'.format(self.agent_id)
                data = {"typename":next_Name,"parentid":dirName_ID}
                response = requests.post(constant.SERVER + url, headers=self.headers, json=data, verify=False)
                if response.status_code == 201:
                    print('新增子目录成功：', response.status_code)
                    return True
                else:
                    print('新增子目录失败', response.text)
                    return False
            else:
                print('不存在该目录：', dirName_ID)
                return False
        except Exception as e:
            print(e)

    def get_child_dirName_info(self, dirName):
        try:
            dirName_ID = self.get_agent_QA_dirName_types(dirName)
            print('dirName_ID: ',dirName_ID)
            if dirName_ID:
                url = '/v2/ux/agents/{}/qa/types/getsubtype?typeid={}'.format(self.agent_id, dirName_ID)
                response = requests.get(constant.SERVER + url, headers=self.headers, verify=False)
                dict_response = response.json()
                return dict_response
            else:
                print('不存在该目录：', dirName_ID)
                return False
        except Exception as e:
            print(e)

    def get_child_dirName_name_id_info(self, dirName):
        try:
            parent_dirName_info = self.get_child_dirName_info(dirName)
            if parent_dirName_info:
                all_name = jsonpath.jsonpath(parent_dirName_info,expr='$..name')
                all_id = jsonpath.jsonpath(parent_dirName_info,expr='$..id')
                print('所在父目录 %s 子目录名称： ' % dirName ,all_name, '\n','所在父目录 %s 子目录ID： ' % dirName ,all_id)
                return all_name, all_id
            else:
                print('不存在该子目录啊', parent_dirName_info)
                return False
        except Exception as e:
            print(e)

    def del_child_dirName_name(self, dirName, name):
        try:
            all_name, all_id = self.get_child_dirName_name_id_info(dirName)
            if all_name:
                print(all_name)
                for i in range(len(all_name)):
                    print('all_name[i]: ', all_name[i])
                    if name == all_name[i]:
                        print('找到子目录：', all_name[i])
                        print('打印该目录的ID：', all_id[i])
                        url = '/v2/ux/agents/{}/qa/types/{}'.format(self.agent_id, all_id[i])
                        print('url: ', url)
                        response = requests.delete(constant.SERVER + url, headers=self.headers, verify=False)
                        print(response.status_code)
                        if response.status_code == 204:
                            print('删除成功', response.status_code)
                            return True
                        else:
                            print('删除失败: ', response.text)
                    else:
                        print('继续寻找......')
            else:
                print('不存在子目录', all_name)
                return False
            return False
        except Exception as e:
            print(e)

    def get_child_dirName_name_ID(self, dirName, child_name):
        try:
            all_name, all_id = self.get_child_dirName_name_id_info(dirName)
            for i in range(len(all_name)):
                print(all_name[i])
                if child_name == all_name[i]:
                    print('找到子目录名称, 打印该ID：', all_name[i], all_id[i] )
                    return all_id[i]
                else:
                    print('继续寻找')
            print('没有找到父目录 %s 子目录的子目录 %s' % dirName, child_name)
            return False
        except Exception as e:
            print(e)

    def del_all_child_dirName_name(self, dirName):
        try:
            all_name, all_id = self.get_child_dirName_name_id_info(dirName)
            if all_id:
                print(all_id)
                for i in range(len(all_id)):
                    url = '/v2/ux/agents/{}/qa/types/{}'.format(self.agent_id, all_id[i])
                    print('url: ', url)
                    response = requests.delete(constant.SERVER + url, headers=self.headers, verify=False)
                    print(response.status_code)
                    if response.status_code == 204:
                        print('删除成功', response.status_code)
                    else:
                        print('删除失败: ', response.text)
                        return False
                else:
                    print('继续寻找......')
            else:
                print('不存在子目录', all_name)
                return False
            return True
        except Exception as e:
            print(e)

    def add_child_dirName_qa(self, dirName, childName, question, answer, question1='', answer1='', keywords= '', tag1='', tag2=''):
        try:
            childName_ID = self.get_child_dirName_name_ID(dirName, childName)
            print('childName_ID: ', childName_ID)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/'.format(self.agent_id, childName_ID)
            data = {"tagids": [],"typeid": childName_ID, "questions": [{"question": question, "keyword": [keywords]}],
                    "answers": [answer], "emoji": "", "language": "", "groupname": ""}
            tag_value = []
            if tag1:
                tag_ID1 = self.get_tag_ID(tag1)
                tag_value = [tag_ID1]
                data['tagids'] = tag_value
                print('data tag:', data['tagids'] )
            if tag2:
                tag_ID2 = self.get_tag_ID(tag2)
                tag_value.append(tag_ID2)
                data['tagids'] = tag_value
                print('data tag:', data['tagids'])
            print('data tag id:', data['tagids'] )
            question_list = [{"question": question}]
            answers_list = [answer]
            if keywords:
                question_list = [{"question": question, "keyword": [keywords]}]
            if question1:
                question_list.append({"question": question1})
                data['questions'] = question_list
            if answer1:
                answers_list.append(answer1)
                data['answers'] = answers_list
            else:
                data['answers'] = [answer]
            print('data: ', data)
            response = requests.post(constant.SERVER + url, headers=self.headers, json=data, timeout=10, verify=False)
            if response.text == '' and response.status_code == 201:
                print('添加QA成功，')
                return True
            else:
                print('添加失败，', response.text)
                return False
        except Exception as e:
            print(e)

    def get_all_child_qa_info(self, dirName, childName):
        try:
            childName_ID = self.get_child_dirName_name_ID(dirName, childName)
            print('childName_ID: ', childName_ID)
            url = '/v2/ux/agents/{}/qa/{}/qgroup/?page=1&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agent_id,childName_ID,childName_ID)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            dict_response = response.json()
            total_pages = dict_response['pagination']['pagecount']
            total_items = dict_response['pagination']['itemcount']
            print('total_pages: ', total_pages, '\n', 'total_items: ', total_items)
            url1 = ['/v2/ux/agents/{}/qa/{}/qgroup/?page={}&pagesize=10&typeid={}&tagid=&audit=1'.format(self.agent_id,childName_ID,page,childName_ID)
                    for page in range(1, total_pages + 1)]
            print('url: ', url1)
            all_response = []
            for ul in range(len(url1)):
                print('url list: ',url1[ul])
                response1 = requests.get(constant.SERVER + url1[ul], headers=self.headers, timeout=10, verify=False)
                dict_response1 = response1.json()
                print('=== 加入到列表 ===')
                all_response.append(dict_response1)
            print('all_response 信息: ', type(all_response), '||', len(all_response))
            return all_response
        except Exception as e:
            print(e)

    def get_all_child_question_answer_dirName(self, dirName, childName):
        try:
            all_qa_info = self.get_all_child_qa_info(dirName, childName)
            print('all_qa_info_len:', len(all_qa_info), ',||, type: ', type(all_qa_info))
            all_questions = []
            all_answers = []
            for i in range(len(all_qa_info)):
                data = all_qa_info[i]['data']
                print('data:', data, '\n', 'data len:', len(data))
                for a in range(len(data)):
                    questions = jsonpath.jsonpath(data, expr='$.[{}].questions..question'.format(a))
                    tuple_questions = tuple(questions)
                    print('questions: ', tuple_questions)
                    all_questions.append(tuple_questions)
                for b in range(len(data)):
                    answers = jsonpath.jsonpath(data, expr='$.[{}].answers..answer'.format(b))
                    tuple_answers = tuple(answers)
                    print('answers: ', tuple_answers)
                    all_answers.append(tuple_answers)
            print(all_questions, '\n','问题个数： ', len(all_questions), '\n',all_answers, '\n', '答案个数： ', len(all_answers))
            return all_questions, all_answers
        except Exception as e:
            print(e)

    def verify_child_qa_display_UI(self, dirName, childName, question, answer):
        try:
            all_questions, all_answers = self.get_all_child_question_answer_dirName(dirName, childName)
            for i in range(len(all_questions)):
                if question in all_questions[i]:
                    print('找到问题，继续找答案', all_questions[i], i)
                    answer_value = all_answers[i]
                    if answer in answer_value:
                        print('找到正确答案，', all_answers[i])
                        return True
                else:
                    print('继续寻找......')
            return False
        except Exception as e:
            print(e)

    def download_file(self, dirName, file_name):
        try:
            dirName_value = self.get_agent_QA_dirName_types(dirName)
            url = '/v2/ux/agents/{}/qa/types/export/{}'.format(self.agent_id, dirName_value)
            headers = self.headers
            headers['Content-Description'] = 'File Transfer'
            headers['Content-Type'] = 'application/octet-stream'
            headers['Content-Disposition'] = 'attachment'
            print(headers)
            file_value = os.path.join(file_path, file_name)
            print('picture_value: ', file_value)
            response = requests.get(constant.SERVER + url, headers=headers, verify=False)
            fp = open(file_value, "wb")
            fp.write(response.content)
            fp.close()
            if response.status_code ==200:
                print('下载文件成功', response.status_code)
                return True
            else:
                print('下载失败',response.text)
                return False
        except Exception as e:
            print(e)

    def download_file_template(self):
        try:
            url = '/v2/ux/agents/{}/qa/types/filetemplate'.format(self.agent_id)
            headers = self.headers
            headers['Content-Description'] = 'File Transfer'
            headers['Content-Type'] = 'application/octet-stream'
            headers['Content-Disposition'] = 'attachment'
            print(headers)
            file_value = os.path.join(file_path, 'file_template.xlsx')
            print('picture_value: ', file_value)
            response = requests.get(constant.SERVER + url, headers=headers, verify=False)
            fp = open(file_value, "wb")
            fp.write(response.content)
            fp.close()
            if response.status_code ==200:
                print('下载文件成功', response.status_code)
                return True
            else:
                print('下载失败',response.text)
                return False
        except Exception as e:
            print(e)

    def get_excel_data(self, file_Name):
        try:
            file_value = os.path.join(file_path, file_Name)
            print('file_value: ', file_value)
            book = xlrd.open_workbook(file_value)
            sheet = book.sheet_by_name('Sheet1')
            rows = sheet.nrows  # 获取行数
            cols = sheet.ncols  # 获取列数
            print(rows, cols)
            all_rows = []
            for r in range(rows):  # 读取每一行的数据
                r_values = sheet.row_values(r)
                print(r_values)
                all_rows.append(r_values)
            print('all_rows: ',all_rows, '\n', len(all_rows))
            return all_rows
        except Exception as e:
            print(e)

    def verify_data_In_excel(self, file_Name, question='', answer=''):
        try:
            excel_data = self.get_excel_data(file_Name)
            print('excel_data: ', excel_data)
            for i in range(len(excel_data)):
                print(excel_data[i])
                if question:
                    print('数据： ', excel_data[i][0], ',||,',excel_data[i][1])
                    if question == excel_data[i][0] and answer == excel_data[i][1]:
                        print('问答对在EXCEL里面：', excel_data[i])
                        return True
                    else:
                        print('继续寻找......')
                else:
                    if excel_data[i][0] == '' and answer == excel_data[i][1]:
                        print('答案在EXCEL里面：', excel_data[i])
                        return True
                    else:
                        print('继续寻找......')
            print('不能在excel找到问答对')
            return False
        except Exception as e:
            print(e)

    def fqa_enable(self):
        try:
            url = '/v2/ux/agents/{}/faq/manage/types/1/off?typeid=1'.format(self.agent_id)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            if response.text == '' and response.status_code == 200:
                print('FQA关闭成功，')
                return True
            else:
                print('FQA关闭失败，', response.text)
                return False
        except Exception as e:
            print(e)

    def fqa_able(self):
        try:
            url = '/v2/ux/agents/{}/faq/manage/types/1/on?typeid=1'.format(self.agent_id)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            if response.text == '' and response.status_code == 200:
                print('FQ打开成功，')
                return True
            else:
                print('FQA打开失败，', response.text)
                return False
        except Exception as e:
            print(e)

# if __name__ == "__main__":

#     print(ApplicationQAInterFace(constant.SV_USER, constant.SV_PWD, agent_id=544).get_excel_data('temp_test.xlsx'))
# # #     # print(ApplicationQAInterFace(constant.SV_USER, constant.SV_PWD, agent_id=544).del_qa('自定义问答','你今年多大了','我今年30岁了'))
#     a = ApplicationQAInterFace(constant.SV_USER, constant.SV_PWD, agent_id=545)

# #      print(ApplicationQAInterFace(constant.SV_USER, constant.SV_PWD, agent_id=544).del_all_dirName())
# # #     # print(ApplicationQAInterFace(constant.SV_USER, constant.SV_PWD, agent_id=544).del_qa('自定义问答','你今年多大了','我今年30岁了'))
#     aa = ApplicationQAInterFace(constant.SV_USER, constant.SV_PWD, agent_id=483)
#     a = aa.add_user_group()
