#!/usr/bin/python
# -*- coding: UTF-8 -*-

'''
Created on Jun 10, 2019

@author: chendianmo
'''

# from lib.modules.Base import Base
from lib.modules.Base import Base
from lib.utils import constant
import requests
import jsonpath,json



class InitializeSV(Base):
    def __init__(self, user, password, agent_id=None):
        Base.__init__(self, user, password)
        auth_info = self.get_sv_authinfo(agent_id=agent_id)
        self.agent_id = json.loads(auth_info)['agentid']
        print('打印操作的 SmartVoice 的 agentID: ', self.agent_id)

    def get_sv_agent_info(self, agentName):
        '''
        通过ID，获取 该agent 的信息...
        :param agentID:
        :return:
        '''
        url = '/v2/ux/agents/?keyword={}&page=1&pagesize=10'.format(agentName)
        response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
        dict_response = response.json()
        total_items = dict_response['pagination']['itemcount']
        if total_items >=1:
            print('存在该 agent, 继续操作... ')
            total_pages = dict_response['pagination']['pagecount']
            print('通过 agentName 搜索得到的包含该 agentName 的页数 total_pages: ', total_pages, ', 总共得到包含该 agentName的 个数 total_items: ', total_items)
            url_all = ['/v2/ux/agents/?keyword={}&page={}&pagesize=10'.format(agentName, page) for page in range(1, total_pages+1)]
            all_response = []
            for ul in url_all:
                response_list = requests.get(constant.SERVER + ul, headers=self.headers, timeout=10, verify=False)
                all_response.append(response_list.json())
            return all_response
        else:
            print('不存在该agent , 打印失败原因... ', response.text)

    def get_agent_id(self, agentName):
        '''
        通过ID，获取 该agent的 name .
        :return:
        '''
        agent_info = self.get_sv_agent_info(agentName)
        if agent_info:
            print('存在包含该 agentName: %s, 继续操作 ... '% agentName)
            agent_name = jsonpath.jsonpath(agent_info, expr='$..data[?(@.agentname==\'{}\')].id'.format(agentName))
            if agent_name:
                print('存在该 agent , 打印 name: ', agent_name)
                return agent_name[0]
            else:
                print('不存在该 agent name , 打印失败原因:', agent_info)
                return False
        else:
            print('不存在该 agent name , 打印失败原因: ', agent_info)
            return False

    def get_agent_accessToken(self, agentName):
        '''
        通过ID，获取 该agent的 name 返回字典.
        :return:
        '''
        agent_info = self.get_sv_agent_info(agentName)
        if agent_info:
            print('存在包含该 agent: %s, 继续操作 ... ' % agentName)
            access_Token = jsonpath.jsonpath(agent_info, expr='$..data[?(@.agentname==\'{}\')].accesstoken'.format(agentName))
            if access_Token:
                print('存在该 agent , 打印 accesstoken: ', access_Token)
                return access_Token[0]
            else:
                print('不存在该 agent name , 打印失败原因:', agent_info)
                return False
        else:
            print('不存在该 agent name , 打印失败原因: ', agent_info)
            return False

    def get_agent_systemService_info(self, agentName, systemService_name):
        '''
        获取 服务管理 的 技能ID, 技能类别 和 状态...，
        :param agentName:
        :return: 某个系统服务的 名称， id, 和 开启状态 ...
        '''
        agent_id = self.get_agent_id(agentName)
        if agent_id:
            print('存在该 agent id， ，继续操作... ')
            url = '/v2/ux/agents/services?agentid={}&domaintype=0'.format(agent_id)
            response = requests.get(constant.SERVER + url, headers=self.headers, timeout=10, verify=False)
            for systemService in response.json():
                systemService_dict = {}
                chinese_name = systemService['info']
                if chinese_name == systemService_name:
                    print('该 agentName 名称: %s 存在该系统服务: %s, 继续操作...' % (agentName, systemService_name))
                    if 'name' in systemService.keys():
                        en_name = systemService['name']
                        print('存在技能英文名称，继续操作...')
                        if 'id' in systemService.keys():
                            id_value = systemService['id']
                            print('存在技能 id， 继续操作...')
                            if 'enabled' in systemService.keys():
                                status = systemService['enabled']
                                print('存在技能 状态值， 继续操作... ')
                                systemService_dict['系统服务名称'] = chinese_name
                                systemService_dict['系统服务英文名'] = en_name
                                systemService_dict['系统服务id'] = id_value
                                systemService_dict['系统服务开启状态'] = status
                                print('打印 该 系统服务信息: ')
                                return systemService_dict
                            else:
                                print('不存在技能 状态值， ', systemService)
                                return False
                        else:
                            print('不存在技能 ID, ', systemService)
                            return False
                    else:
                        print('不存在技能英文名称， ', systemService)
                        return False
            else:
                print('该 agentName 名称: %s 不存在该系统服务: %s, 返回False' % (agentName, systemService_name))
                return False
        else:
            print('不存在该 agent name , 打印失败原因: ', agent_id)
            return False

    def get_agent_systemService_id(self, agentName, systemService_name):
        agent_domainType_info = self.get_agent_systemService_info(agentName, systemService_name)
        if agent_domainType_info:
            print('该 agentName 名称: %s 存在该系统服务: %s, 继续操作...' % (agentName, systemService_name))
            domainType_id = agent_domainType_info['系统服务id']
            if domainType_id:
                print('存在 系统服务 id, 打印: ')
                return domainType_id
            else:
                print('不存在该技能服务...', agent_domainType_info)
                return False
        else:
            print('不存在该 agent name 或者 存在该agent但是不存在 该系统服务..., 打印失败原因: ', agent_domainType_info)
            return False

    def get_agent_systemService_status(self, agentName, systemService_name):
        '''
        True = 服务开启状态，False= 服务关闭状态
        :param agentName:
        :param systemService_name:
        :return:
        '''
        agent_domainType_info = self.get_agent_systemService_info(agentName, systemService_name)
        if agent_domainType_info:
            print('该 agentName 名称: %s 存在该系统服务: %s, 继续操作...' % (agentName, systemService_name))
            domainType_status = agent_domainType_info['系统服务开启状态']
            print('存在 系统服务 status, 打印: ')
            return domainType_status
        else:
            print('不存在该 agent name 或者 存在该agent但是不存在 该系统服务..., 打印失败原因: ', agent_domainType_info)
            return False

    def operate_systemService_action(self, agentName, systemService_name, action_status):
        '''
        :param agentName:
        :param systemService_name:
        :param action_status: 开启，关闭.
        :return:
        '''
        if action_status == '开启' or action_status == '关闭':
            agent_id = self.get_agent_id(agentName)
            if agent_id:
                systemService_id = self.get_agent_systemService_id(agentName, systemService_name)
                if systemService_id:
                    url1 = '/v2/ux/agents/{}/domains/{}/enable?domainid={}'.format(agent_id, systemService_id, systemService_id)
                    url2= '/v2/ux/agents/{}/domains/{}/disable'.format(agent_id, systemService_id)
                    url_real = {
                        '开启': url1,
                        '关闭': url2
                    }
                    url = constant.SERVER + url_real[action_status]
                    print('开启或关闭系统服务 url: ', url)
                    if action_status == '开启':
                        response = requests.get(url, headers=self.headers, timeout=10, verify=False)
                        print('开启 info: : ', response.text, response.status_code)
                        if response.status_code == 200:
                            print('接口提示开启系统服务成功...')
                            return True
                        else:
                            print('接口提示开启系统服务失败...')
                            return False
                    if action_status == '关闭':
                        response = requests.post(url, headers=self.headers, timeout=10, verify=False)
                        print('关闭 info: ', response.text, response.status_code)
                        if response.status_code == 200:
                            print('接口提示关闭系统服务成功...')
                            return True
                        else:
                            print('接口提示关闭系统服务失败...')
                            return False
                else:
                    print('不存在该 agent name 或者 存在该agent但是不存在 该系统服务..., 打印失败原因: ', systemService_id)
                    return False
            else:
                print('不存在该 agent id , 打印失败原因: ', agent_id)
                return False
        else:
            print('action 操作值写错..., 打印出来报错... ', action_status)
            return False

    def add_sv_agent(self, agentName, language='zh-CN'):
        '''
        其他参数均为默认值...
        :param agentName:
        :return:
        '''

        url = '/v2/ux/agents/add'
        data = {"agentname":agentName,
                "language":language,
                "dflanguage":language,
                "timezone":"UTC",
                "longitude":"116",
                "latitude":"39",
                "gatewayurl":"",
                "description":""
                }

        agent_is_exist = self.get_agent_id(agentName)
        if agent_is_exist:
            print('这个 agent Name 已经存在 不需要创建... ', agent_is_exist)
            message = '这个agentName已经存在'
            return message
        else:
            print('这个 agent Name 不存在， 需要新建 ... ', agent_is_exist)
            self.headers['Content-Type'] = 'application/json'
            response = requests.post(constant.SERVER + url, headers=self.headers, json=data, timeout=10, verify=False)
            if response.status_code == 201:
                print('接口提示 agent 创建成功...', response.text)
                return True
            else:
                print('接口提示 agent 创建失败..., 打印失败原因，', response.text)
                return False



if __name__ == "__main__":
    # p = InitializeSV(constant.SV_USER, constant.SV_PWD)
    # print(p.add_sv_agent('cloudminds123'))

    pass



