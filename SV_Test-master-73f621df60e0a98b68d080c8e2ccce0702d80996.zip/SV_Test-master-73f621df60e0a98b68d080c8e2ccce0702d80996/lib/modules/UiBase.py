from lib.utils.logger import logger
from robot.libraries.BuiltIn import BuiltIn
import os
from time import sleep
import time
import SeleniumLibrary
from lib.utils import constant
from lib.uilocators import uilocators
from lib.utils.JiraTool import JiraTool
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
import traceback

class UiBase(object):
    def __init__(self):
        print('uibase init')
        self.selib = BuiltIn().get_library_instance('SeleniumLibrary')
        self.download_path = BuiltIn().get_variable_value("${EXECDIR}")

    def get_page_screenshot(self):
        # 截图
        try:
            self.selib.capture_page_screenshot()
        except:
            print('Screen shot failed')
            logger.error('Screen shot failed')

    #不会抛出AssertError
    def is_visible(self, locator):
        """Same than Element Should Be Visible but returns a boolean """
        old_wait = self.selib.get_selenium_implicit_wait()
        try:
            self.selib.set_selenium_implicit_wait(0.5)
            self.selib.element_should_be_visible(locator)
            self.selib.set_selenium_implicit_wait(old_wait)
            return True
        except Exception:
            self.selib.set_selenium_implicit_wait(old_wait)
            return False

    def wait_element_visible(self, locator, timeout=10):
        """等待element界面可见
        :param locator: locator
        :param timeout: 等待时间，默认10s
        :return  bool 可见为true,不可见为false
        """
        start = time.time()
        try:
            while time.time() - start < int(timeout):
                if self.is_visible(locator):
                    return True
                time.sleep(0.3)
            print("等待了{}秒,依然不可见".format(time.time()-start))
            logger.error("等待了{}秒,依然不可见".format(time.time()-start))
        except Exception:
            print(Exception.__cause__)
            traceback.print_exc()
            print("等待了{}秒,依然不可见,并发生了exception".format(time.time()-start))
            logger.error("等待了{}秒,依然不可见,并发生了exception".format(time.time()-start))

    #不会抛出AssertError
    def wait_element_present(self, locator, timeout=10):
        """等待element在document里面出现,不一定可见
        :param locator: locator
        :param timeout: 等待时间，默认10s
        :return     出现true,不出现false
        """
        old_wait = self.selib.get_selenium_implicit_wait()
        try:
            self.selib.set_selenium_implicit_wait(0.5)
            start = time.time()
            while time.time()- start < int(timeout):
                web_element = ""
                try:
                    web_element = self.selib.get_webelement(locator)
                except:
                    pass
                if web_element:
                    self.selib.set_selenium_implicit_wait(old_wait)
                    return True
                time.sleep(0.3)
            self.selib.set_selenium_implicit_wait(old_wait)
            return False
        except Exception as ex:
            print('wrong happens')
            logger.error("wrong happens")
            print(ex)
            self.selib.set_selenium_implicit_wait(old_wait)
            return False

    #不会抛出AssertError
    def wait_element_disapear(self, locator, timeout=10):
        """等待element消失
        :param locator: locator
        :param timeout: 等待时间，默认10s
        :return  bool返回,消失了true,超时还可见为false
        """
        try:
            start = time.time()
            while time.time() - start < int(timeout):
                web_element = self.selib.get_webelement(locator)
                if web_element:
                    time.sleep(0.3)
            return False
        except Exception:
            return True

    def is_element_present(self, locator):
        """Same than Page Should Contain Element but returns a boolean """
        try:
            self.selib.page_should_contain_element(locator)
            return True
        except Exception:
            logger.error('%s not present'%locator)
            return False

    #等同于Get WebElements这个关键字
    #http://robotframework.org/SeleniumLibrary/SeleniumLibrary.html#Get%20WebElements
    #为了不出现AssertError错误,用了Exception来捕获异常
    def get_elements(self, locator):
        """获取webelements
        :param  locator 参考robotframework规定"""
        try:
            web_items = self.selib.get_webelements(locator)
            return web_items
        except Exception:
            print('no list available')
            logger.error("%s no list available"%locator)
            return []

    def click_by_js(self, locator):
        try:
            element = self.selib.driver.find_element_by_xpath(locator)
            self.selib.driver.execute_script("arguments[0].click()", element)
        except AssertionError:
            print('error happen when click', locator)
            logger.error("error when click js %s"%locator)

    def click_by_text(self, text):
        try:
            element = self.selib.driver.find_element_by_xpath("//*[text()='{}']".format(text))
            self.selib.driver.execute_script("arguments[0].click()", element)
        except AssertionError:
            print('error happen when click', text)
            logger.error("error when click text by js %s" % text)

    def click_text_contains(self, text):
        try:
            element = self.selib.driver.find_element_by_xpath("//*[contains(text(), '{}')]".format(text))
            self.selib.driver.execute_script("arguments[0].click()", element)
        except AssertionError:
            print('error happen when click', text)
            logger.error("error when click text by js %s" % text)

    def get_value_by_js(self, xpath):
        try:
            element = self.selib.driver.find_element_by_xpath(xpath)
            return self.selib.driver.execute_script("return arguments[0].value", element)
        except AssertionError:
            print('error happen when get value', xpath)
            logger.error("error when click js %s" % xpath)

    def click_webelement_by_js(self, element):
        try:
            self.selib.driver.execute_script("arguments[0].click()", element)
        except AssertionError:
            print('error happen when click', element)
            logger.error("error when click js %s"%element)

    #从一堆里面点击第几个
    def click_index_from_webelements(self, locator, index):
        """点击第几个在获取的webelemnts中间
        :param  locator 参考robotframework规定
        """
        try:
            items = self.get_elements(locator)
            if items:
                items[int(index)].click()
            else:
                print('no items found ' + locator)
        except:
            self.get_page_screenshot()
            print('exception happens')


    #从locator获取innerText属性,如果无这个属性,请不要使用
    def get_text_from_webelements(self, locator):
        """从locator获取innerText属性,如果无这个属性,请不要使用
        :param  locator 参考robotframework规定
        """
        try:
            items = self.get_elements(locator)
            result = []
            if items:
                for item in items:
                    result.append(item.get_attribute('innerText'))
            else:
                print('no items found ' + locator)
                logger.debug('no items found ' + locator)
            return result
        except Exception as ex:
            print(ex)
            self.get_page_screenshot()
            print('get_text_from_webelements exception happens')
            logger.error('exception happens')

    def get_selenium_browser_log(self):
        """获取浏览器日志, 是个list字典
        """
        # 获取浏览器日志 Warn Error
        selib = BuiltIn().get_library_instance('SeleniumLibrary')
        return selib.driver.get_log('browser')

    def wait_and_click_element_at_coordinates_if_available(self, locator, x_offset=0, y_offset=0, timeout=3):
        """等待并点击该locator的坐标,若果存在
        :param locator"""
        try:
            if self.wait_element_present(locator, int(timeout)):
                self.selib.click_element_at_coordinates(locator, x_offset, y_offset)
        except Exception as ex:
            print(ex)
            logger.error('error when click '+locator)

    def wait_and_click_element_if_available(self, locator, timeout=3):
        '''
        等待并点击该locator,如果存在
        :param locator: 
        :param timeout: 
        :return: 
        '''

        try:
            slib = BuiltIn().get_library_instance('SeleniumLibrary')
            if self.wait_element_present(locator, int(timeout)):
                slib.click_element(locator)
        except Exception as ex:
            print(ex)
            logger.error('error when click '+locator)

    def wait_page_contains(self, text, timeout=10):
        '''
        等待网页中包含文本
        :param text: 检验的文本
        :param timeout: 等待超时时间
        :return: 
        '''
        try:
            start = time.time()
            while time.time()- start < int(timeout):
                try:
                    self.selib.page_should_contain(text)
                    return True
                except Exception:
                    pass
                time.sleep(0.5)
            return False
        except Exception as ex:
            print(ex)

    def wait_for_element_clickable(self, xpath, timeout=10):
        '''
        等待某个element可以点击
        :param xpath: xpath传入
        :param timeout: 
        :return: 
        '''
        try:
            WebDriverWait(self.selib.driver, 10).until(EC.element_to_be_clickable((By.XPATH, xpath)))
        except Exception as ex:
            print('****************')
            print(ex)

    def create_chrome_webdriver(self, url, wait_timeout=10,implicit_wait=3, headless=False, download_path="",speed=0.3):
        '''
        创建chrome浏览器的webdriver
        :param url: 需要打开的网页地址 
        :param wait_timeout:  selenium的wait时间
        :param implicit_wait: 元素的not found的等待时间
        :param headless: 是否无界面运行
        :param download_path: 下载目录,默认为运行目录
        :param speed: selenium运行速度,默认设为0.3秒
        :return: 
        '''
        try:
            from selenium import webdriver
            from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
            if not download_path:
                download_path = self.download_path
            options = webdriver.ChromeOptions()

            opts = ['no-sandbox', 'disable-dev-shm-usage', 'start-maximized', 'disable-infobars', 'disable-gpu',
                'test-type', 'disable-extensions', 'ignore-certificate-errors', 'disable-user-media-security']
            if headless:
                opts.append('headless')
            else:
                if os.getenv("USE_HEADLESS") == 'True':
                    opts.append('headless')
            for opt in opts:
                options.add_argument(opt)
            prefs = {'download.default_directory': download_path,
                'download.prompt_for_download': 'false'}
            options.add_experimental_option("prefs", prefs)
            capabilities = DesiredCapabilities.CHROME
            capabilities['loggingPrefs'] =  {"driver": "INFO", "server": "OFF", "browser": "ALL"}
            self.selib.create_webdriver('Chrome', desired_capabilities=capabilities, chrome_options=options)
            self.selib.go_to(url)
            self.selib.set_selenium_speed(speed)
            self.selib.set_selenium_implicit_wait(implicit_wait)
            self.selib.set_selenium_timeout(wait_timeout)
        except AssertionError:
            print("Error happens")
            logger.error('Error happens when create driver')

    def close_chrome_browser(self):
        '''
        关闭浏览器,内容加入了判断失败的内容,所以需要在teardown里面调用
        :return: 
        '''
        result = 'FAIL'
        case_id = 'None'
        try:
            result = BuiltIn().get_variable_value("${TEST STATUS}")
            case_id = BuiltIn().get_variable_value("${TEST NAME}")
            if 'FAIL' in result:
                self.get_page_screenshot()
                BuiltIn().log(self.get_selenium_browser_log())
        finally:
            print("put result to jira {} {}".format(result, case_id))
            self.put_result_to_jira()
            logger.info("put result to jira {} {}".format(result, case_id))
        try:
            selib = BuiltIn().get_library_instance('SeleniumLibrary')
            selib.close_all_browsers()
        except Exception as ex:
            print(ex)

    def login_smartvoice(self, user=constant.SV_USER, password=constant.SV_PWD):
        '''
        登录Smartvoice
        :return: 
        '''
        start = time.time()
        self.create_chrome_webdriver(constant.SERVER)
        self.wait_element_visible(uilocators.login_page_login_btn, timeout=20)
        self.selib.input_text(uilocators.login_page_user, user)
        self.selib.input_text(uilocators.login_page_password, password)
        self.wait_for_element_clickable(uilocators.login_page_login_btn)
        time.sleep(2)
        self.selib.click_element(uilocators.login_page_login_btn)
        ret = self.wait_element_present(uilocators.menu_user, timeout=15)
        assert ret, "Wait to login failed"
        print('login takes:', time.time()-start)
        logger.info('login takes: {:.2f} s'.format(time.time()-start))
    def login_smartvoice_admin(self):
        '''
        登录Smartvoice
        :return:
        '''
        start = time.time()
        self.create_chrome_webdriver(constant.SERVER)
        self.wait_element_visible(uilocators.login_page_login_btn, timeout=20)
        self.selib.input_text(uilocators.login_page_user, constant.SV_ADMIN)
        self.selib.input_text(uilocators.login_page_password, constant.SV_ADMIN_PWD)
        self.wait_for_element_clickable(uilocators.login_page_login_btn)
        time.sleep(2)
        self.selib.click_element(uilocators.login_page_login_btn)
        ret = self.wait_element_present(uilocators.menu_user, timeout=15)
        assert ret, "Wait to login failed"
        print('login takes:', time.time()-start)
        logger.info('login takes: {:.2f} s'.format(time.time()-start))
    def change_lang(self, lang):
        '''
        改变网页语言
        :param lang: {"中文简体": "[1]","中文繁體":"[2]", 'English': "[3]", '日本語': '[4]'}
        :return: 
        '''
        language = {"中文简体": "[1]","中文繁體":"[2]", 'English': "[3]", '日本語': '[4]'}
        if not self.wait_element_present(uilocators.menu_language, 15):
            print('Waiting for 15seconds, not loaded')
            logger.error('Waiting for 15seconds, not loaded')
            raise AssertionError
        self.click_by_js(uilocators.menu_language)
        time.sleep(1)
        self.click_by_js(uilocators.menu_select+language[lang])

    def click_locator(self, locator):
        '''
        点击网页元素
        :param locator: 网页元素
        :return: 
        '''
        self.selib.click_element(locator)

    def put_result_to_jira(self):
        """在jira打结果,必须是teardown里面调用,否则出错
        系统中必须首先声明如下系统变量
        export JIRA_USER='alex.qi'
        export JIRA_PASSWORD='mypassword'
        export TEST_VERSION=v2.0
        export CYCLE_NAME="v2.0 test suite"
        #Case标题格式:  CV-12923,CV-23434 场测试名称
        """
        try:
            if constant.test_version=="" and constant.testcycle_name=="":
                print('Please check test version testcycle_name is empty??')
                return False

            if constant.jira_user=="" and constant.jira_pwd=="":
                print('Please check Jira user/password is empty??')
                return False

            test_name = BuiltIn().get_variable_value("${TEST NAME}")
            test_key = test_name.split()[0]
            if '-' not in test_key:
                print('no key found in test_key', test_key)
                return False
            test_status = BuiltIn().get_variable_value("${TEST STATUS}")
            jira = JiraTool(constant.jira_user, constant.jira_pwd)
            jira.login()
            for key in test_key.split(','):
                jira.set_execution_status(key, test_status, constant.test_version, constant.testcycle_name)
        except Exception as ex:
            print(ex)
            print('failed excute: stutus')

    def enter_text(self, locator, text):
        """
        网页中键入文本
        :param locator: input元素
        :param text: 
        :return: 
        :param locator: 
        :param text: 
        :return: 
        """
        self.selib.input_text(locator, text)